# Mock user data
mock_user = {
   "username": "testuser",
   "email": "testuser@example.com",
   "password": "testpassword"
}