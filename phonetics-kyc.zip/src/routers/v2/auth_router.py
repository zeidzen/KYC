from fastapi import APIRouter, Request, Depends
from fastapi.responses import JSONResponse

from src.services.auth_services import Auth_Services
from src.utils import get_current_user
from src.schemas.authentication import Signup, Login, LoginResponse
from src.schemas.user import ChangePassword, UsersResponse, DefaultResponse


# Create an API router
AuthenticationRouter=APIRouter(prefix="/api/v2/auth", tags=["api_v2"])

@AuthenticationRouter.post('/signup/',response_model=DefaultResponse, tags=["Authentication"])
async def create_user(data:Signup, request:Request)-> JSONResponse:

    """ This Endpoint for Get All Users Have Access to phonetics system."""
    # Read Data and Create Connection
    obj_Operations=Auth_Services(endpoint="signup")
    # Apply Signup Procedure
    content, status_code=obj_Operations.signup_procedure(
                                                headers=dict(request.headers), 
                                                data=data.__dict__)
    # Create Response  
    return JSONResponse(status_code=status_code, content=content)


# route for login user in 
@AuthenticationRouter.post('/login', response_model=LoginResponse, tags=["Authentication"])
async def login(data:Login, request:Request)-> JSONResponse:
    
    # Read Data and Create Connection
    obj_Operations=Auth_Services(endpoint="login")
    # Apply Login Procedure
    content, status_code=obj_Operations.login_procedure(
                                            data=data.__dict__, 
                                            headers=dict(request.headers))

    # Create Response  
    return JSONResponse(status_code=status_code, content=content) 
   

@AuthenticationRouter.get('/users', tags=["User"], response_model=UsersResponse)
async def get_all_users(request:Request, current_user:str=Depends(get_current_user))-> JSONResponse:

    """ This Endpoint for Get All Users Have Access to phonetics system."""
    # 1.Read Data and Create Connection
    obj_Operations=Auth_Services(endpoint="users")
    # Apply Get All Users Procedure
    content, status_code=obj_Operations.get_all_users_procedure(
                                                    headers=dict(request.headers),
                                                    public_id=current_user)
    # Create Response
    return JSONResponse(content=content, status_code=status_code)
        

@AuthenticationRouter.post('/change_pass/', response_model=DefaultResponse, tags=["Authentication"])
async def change_password(data:ChangePassword, request:Request, current_user:str=Depends(get_current_user))-> JSONResponse:
    
    """ This Endpoint for Change Password to exists user have access to phonetics system."""
    # Read Data and Create Connection
    obj_Operations=Auth_Services(endpoint="change_pass")
    # Apply Change Password Procedure
    content, status_code=obj_Operations.change_password_procedure(
                                            headers=dict(request.headers),
                                            data=data.__dict__,current_user=current_user)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

