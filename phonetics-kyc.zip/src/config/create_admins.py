from werkzeug.security import generate_password_hash 
import uuid 
from src.services.base_services import Base_Services
from src.services.log_settings import Log_system
from . import config
from datetime import datetime
import re

current_datetime = datetime.now().strftime(config.DATE_FORMAT)

def password_is_valid(self, password):
    if len(password)>=8:
        return True
    else:
        return False
    
def email_is_valid(self, email):
    regex=re.compile(r'([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
    if re.fullmatch(regex, email):
        return True
    else:
        return False
    
def name_is_valid(self, name):
    if len(name)>=2:
        return True
    else:
        return False
    
def get_admin_information():
    
    name=input('Enter your Name:')
    while name_status:
        name=input('Please Enter Correct Name:')
        name_status=name_is_valid(name)
            
    email=input('Enter your Email:')
    while email_status:
        email=input('Please Enter Correct Email:')
        email_status=email_is_valid(email)                                                           
        
    password=input('Enter your Password:')
    while password_status:
        password=input('Please Enter Correct Password:')
        password_status=password_is_valid(password)
    
    user_obj=dict()
    user_obj['name']=name
    user_obj['email']=email
    user_obj['password']=generate_password_hash(password)
    user_obj['public_id']=str(uuid.uuid4())
    user_obj['is_admin']=True
    user_obj['created_at']=current_datetime    
    return user_obj
    
def create_admin():
    obj_Operations=Base_Services()
    obj_log_system=Log_system()
    
    user_obj=get_admin_information()
    
    status=input("Are you sure a new create Admin? enter y/n ").strip().lower()
    
    if status in ["y","yes","1"]:
        users=obj_Operations.users 
        if user_obj['email'] not in list(users['email']):
            obj_Operations.add_row(index=config.USERS_INDEX, _object=user_obj)
            obj_log_system.print_information("Admin is Created.")
        else:
            obj_log_system.print_information("User Already exists.")
    else:
        obj_log_system.print_information("The user is rejected try again.")
    obj_Operations.close_connection()
        