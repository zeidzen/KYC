from elasticsearch.exceptions import NotFoundError
from config.configuration import config
from src.database import *
from termcolor import colored
import time
from werkzeug.security import generate_password_hash 
import uuid 
from datetime import datetime

# Get the current date and time
current_date_time = datetime.now()

# Function to check if email exists in Elasticsearch index
def check_email_exists(index_name,email):
    query={
        "query":{
            "match":{
                "email":email  # Use keyword field for exact match
            }
        }
    }
    try:
        response=es_client.search(index=index_name, body=query)
        hits=response['hits']['hits']
        if hits:
            return True  # Email exists in index
        else:
            return False  # Email does not exist in index
    except NotFoundError:
        return False  # Index does not exist
    
# Create an Elasticsearch client
print(">> Create Connection. . .", end=" ")
es_client =create_connection()
print(colored("Done", 'green'))

# Index creation request
indexes_setup=[
  (config.USERS_INDEX, users_settings),
  (config.PARTIES_INDEX, parties_settings),
  (config.NAMES_INDEX, names_settings),
  (config.NATIONALITIES_INDEX, nationalities_settings),
  (config.PARTIES_COUNTRY_INDEX, parties_country_settings),
  (config.PREPROCESSING_INDEX, Preprocessing_settings),
  (config.LOG_INDEX, log_settings),
  (config.SETTINGS_INDEX, settings_index_settings),
    
]

print(">> Create Indexes . . .")
for index, setting in indexes_setup:
    try:
        print(index, ":", end=" ")
        response=es_client.indices.create(index=index, body=setting)
        print(colored("Done", 'green'))
    except:
        print(colored("The {} index already exists.".format(index), 'red'))

print("-----" * 10)




print(">> Setup Default Settings . . .")
# Default Settings
print(colored("Please wait, this process may take up to 2 minutes.", 'yellow'))
response=es_client.count(index=config.SETTINGS_INDEX)
is_empty=response['count'] ==0
if is_empty:
    for row_id, document in enumerate(default_settings):
        time.sleep(0.3)
        es_client.index(index=config.SETTINGS_INDEX, body=document)
        
    print("Default Settings:",colored("Done", 'green'))
else:
    print(colored(f"The index <{config.SETTINGS_INDEX}> is not empty.", 'red'))  
    
# Preprocessing
response = es_client.count(index=config.PREPROCESSING_INDEX)
is_empty=response['count'] ==0

if is_empty:
    for row_id, document in enumerate(default_preprocessing):
        time.sleep(0.5)
        es_client.index(index=config.PREPROCESSING_INDEX, body=document)
    print("Default Preprocessing:",colored("Done", 'green'))
else:
    print(colored(f"The index <{config.PREPROCESSING_INDEX}> is not empty.", 'red'))  
# ADMIN
# Get current date and time
current_datetime = datetime.now().strftime(config.DATE_FORMAT)
config.ADMIN["public_id"]=str(uuid.uuid4())
config.ADMIN['password']=generate_password_hash(config.ADMIN["password"])
config.ADMIN['created_at']=current_datetime
if not check_email_exists(index_name=config.USERS_INDEX, email=config.ADMIN["email"]):   
    es_client.index(index=config.USERS_INDEX, body=config.ADMIN)
    print("Default ADMIN:",colored("Done", 'green'))
else:
    print(colored("ADMIN Already exists.", 'red'))

print(">> Close Connection. . .", end=" ")
close_connection(es_client)
print(colored("Done".format(index), 'green'))