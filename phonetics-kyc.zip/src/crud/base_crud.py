from fastapi import status, HTTPException
from datetime import datetime
from src.database import create_connection
from src.services.log_settings import Log_system
from src.config import config
                            
class Base_Queries():

    def __init__(self,endpoint="",path=""):
        
        self.endpoint=endpoint
        self.org_path="q.bq.BQ."
        self.path=path + self.org_path
        #Create Log System
        self.obj_log_system=Log_system(endpoint=self.endpoint)
        # Create Connection
        self.es=create_connection()

        
    ################################################################################################################
    ######################################## Elasticsearch Operations  #############################################
    ################################################################################################################
    
    def get_all_data_from_index (self, index, size=10000):
        func_name="get_all_data_from_index"
        path=self.path+self.org_path+func_name
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Get All Data For Elasticsearch index
        data,query=list(),dict()
        if index =='log':
            query['query']={"range":dict()}
            query['query']['range'] ={"time_stamp":{ "gte":"now-1d/d"} }
        else:
            query['query']={"match_all":{}}
        query['size']=size
        result =self.es.search( index=index, body=query)['hits']['hits']
        for obj in result:
            obj['_source']["Id"] =obj['_id']  
            data.append(obj['_source'])
        self.obj_log_system.logger.debug(f"/ {func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return data

    def generate_query_based_keys (self, index:str, fields:dict)-> dict:
        func_name, path="generate_query_based_keys", self.path+self.org_path+"generate_query_based_keys"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # lists
        deterministic_must_list, query =list(), dict()
        query['query']=dict()
        query['query']['bool']={"must":[],"filter":[],"should":[],"must_not":[]}
        for key, value in fields.items():
            if value=='' or value==[]:
                continue 
            term={"match":dict()} 
            term ["match"][key] ={'query':value} 
            deterministic_must_list.append(term)
        # Deterministic List
        if deterministic_must_list !=[]:
            query['query']['bool']['must'].append({"bool":{"must":deterministic_must_list}})
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return query

    def add_row (self, index:str, _object:dict, created_at=datetime.now().strftime(config.DATE_FORMAT))-> str:
        func_name, path="add_row", self.path+self.org_path+"add_row"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        _object["created_at"]=created_at
        output = self.es.index( index=index, body=_object)
        output={'detail':'the process of adding done successfully'}
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output

    def update_row_using_elastic_id (self, index:str, Id:str, _object:dict):
        func_name="update_row_using_elastic_id"
        path=self.path+func_name
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        elastic_id=Id 
        self.es.update( index=index, id=elastic_id, body={ "doc":_object })            
        output={'status':True,'detail':'object is updated'}
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output

    def update_row (self, index:str, keys:dict, _object:dict):
        
        """ Update record in the database based on Keys of the index. """
        func_name, path="update_row", self.path+"update_row"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        query=self.generate_query_based_keys ( index=index ,fields=keys)
        result_search=self.es.search( index=index, body=query)['hits']['hits']
        if result_search ==[]:
            self.add_row(index=index, _object=_object)
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return { "status":True, 'detail':'the process of adding done successfully'}

        elastic_id=result_search[0]['_id']
        _object["updated_at"]
        result=self.es.update(index=index, id=elastic_id, body={"doc":_object})            
        output={"status":True,'detail':f'{index}:object is updated'}
        self.obj_log_system.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output

    def delete_row (self, index:str, Id:str ):
        func_name, path="delete_row", self.path+"delete_row"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        elastic_id=Id 
        try:
            self.es.delete(index=index,id=elastic_id)
            output={ "status":True,'detail':'the process of deleting successfully'}
            return output
        except:
            output={ "status":False,'detail':'Id is not found.'}
            self.obj_log_system.logger.warning(output["detail"],extra={"path":self.path+"delete_row","endpoint":self.endpoint})
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output

    def check_keys_is_found (self,index, keys):
        """ This function will Check if the record is exists or not based on Primer Keys
      (Party ID, Organization, Role, Source Country, and Sequence)
        """  
        func_name, path="check_keys_is_found", self.path+"check_keys_is_found"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        query=self.generate_query_based_keys(index=index ,fields=keys)
        result_search = self.es.search( index=index, body=query)['hits']['hits']
        if result_search ==[]:
            output=False 
        else:
            output=True 
            self.created_at=result_search[0]["_source"]["created_at"]
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output
            
    def search_individuals_names(self, index_name, source_object, parameters, size, _sort):
        query=self.generate_query_for_search ( 
                                        index =index_name,
                                        _object=source_object["object"]["names"],
                                        parameters=parameters,
                                        size=size,
                                        _sort=_sort
                                    )
        results=self.es.search(index=index_name, body=query)

                #search_by_primary_key
        if results["hits"]["hits"] ==[]:
            content={"detail":"The object does not have similar objects."}
            self.obj_log_system.logger.warning(content["detail"],extra={"path":self.path,"endpoint":self.endpoint})
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
    
        return results
    
    def Search_using_party_id (self, parameters:dict, system_type ="")-> list:
        
            func_name, path="Search_using_party_id",self.path+"Search_using_party_id"
            self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})

            if system_type=="corporate":
                indexes_list=["parties",'names','parties_country','nationalities']
            else:
                indexes_list=['names','parties_country','nationalities'] 

            data=dict()
            for index in indexes_list:
                if index =="parties":
                    fields={"party_id":parameters['party_id']}
                else:
                    fields=parameters
                query=self.generate_query_based_keys (index=config.INDEX_MAP[index], fields=fields)
                result=self.es.search(index=config.INDEX_MAP[index], body=query)
                items=dict()
                settings=self.settings_file[ (self.settings_file['index'] ==config.INDEX_MAP[index])& ( self.settings_file['keys']==False)]
                if  result["hits"]["hits"] !=list()and index !="nationalities":
                    for ind ,  row in settings.iterrows():
                        if row['field'] in result["hits"]["hits"][0]['_source'].keys()and row['field'] !="party_id" :
                            items[row['field']]=result["hits"]["hits"][0]['_source'][row['field']]
                    data[index]=items
                elif index =="nationalities":
                    nal=list()
                    for obj in result["hits"]["hits"]:
                        items=dict()
                        for ind ,  row in settings.iterrows():
                            if row['field'] in obj['_source'].keys()and row['field'] !="party_id" :
                                items[row['field']]=obj['_source'][row['field']]
                        nal.append(items)
                    data[index]=nal
                else:
                    data[index]=dict()
                    continue
            if data['names'] ==dict():
                detail="party id is not found in names index."
                self.obj_log_system.logger.warning(detail,extra={"path":path,"endpoint":self.endpoint})
                self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
                return None 
            
            else:
                self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
                return data 

    def get_source_data_based_on_parameters(self, parameters):
        
        """
        Get Data from Elasticsearch if case the request has all parameters information (search by party id)
        if the party id is found this function will be return source_obj['object'] with data  
        else will be return source_obj['object'] with None
        """
        source_obj=dict()
        for key, value in parameters.items():
            if parameters[key]  ==None:
                parameters[key]=''
        source_obj['keys']=parameters.copy()
        # del source_obj['keys']['party_id_not_in']
        if ( 
            parameters['party_id'] !='' and 
            parameters['role'] !='' and 
            parameters['sequence'] !='' and 
            parameters['source_country'] !='' and 
            parameters['organization'] !='' ):

            _object=self.Search_using_party_id(parameters)

            if _object ==None:
                content ={'detail':"Party ID does not found."}
                self.obj_log_system.logger.warning(content["detail"],extra={"path":self.path,"endpoint":self.endpoint})           
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
            
            source_obj['object']=_object
            output, status_code ={"status":True, 'data':source_obj}, status.HTTP_200_OK
        else:
            content ={'detail':'Party ID is not found in names.'}
            self.obj_log_system.logger.warning(content["detail"],extra={"path":self.path,"endpoint":self.endpoint})           
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
        return output, status_code
    
    def search_by_primary_key(self, index_name, primary_key):
        """
        Search for a document by a custom primary key field using a term query.
        :param index_name: Name of the index to search
        :param field_value: Value of the field to search for
        :return: The first matching document if found, otherwise None
        """
        try:
            # Perform a term query to find the document by the custom primary key
            response = self.es.search(
                index=index_name,
                body={
                    "query": {
                        "term": {
                            "primary_id": primary_key
                        }
                    }
                }
            )
            return response['hits']['hits']
        except Exception as e:
            print(f"An error occurred: {e}")
            return None