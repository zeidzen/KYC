from pydantic import BaseModel, Field, field_validator
from typing import Optional
from src.schemas.names import (
                    IndName, 
                    IndCompReqNameFields, 
                    IndResSearchNamesFields,
                    ChecksumNameObject
                    )
from src.schemas.nationalities import (
                            IndNationality, 
                            IndCompResNationalityFields, 
                            IndResultsSearchNationalityFields,
                            ChecksumNationalitiesObject
                            )
from src.schemas.parties_country import (
                            IndPartiesCountry, 
                            IndCompResPartiesCountryFields,
                            IndResultsSearchPartiesCountryFields,
                            ChecksumPartiesCountryObject
                            )
from src.schemas.base import CompareParameters, Search_by_object_Parameters

# Default Response
class DefaultResponse(BaseModel):
    detail:str 

class MainKeys(BaseModel):
    party_id:str
    role:str
    sequence:int
    source_country:str
    organization:str   

class IndividualObject(BaseModel):
    names:IndName
    nationalities:list[IndNationality]
    parties_country:IndPartiesCountry
    
        

# -------------------- Add --------------------
# Add Response
class AddParameters(BaseModel):
    party_id:str
    role:str 
    sequence:int
    source_country:str
    organization:str

class IndividualAdd(BaseModel):
    parameters:AddParameters
    object:IndividualObject
    
# -------------------- Update  --------------------
# Update Response
class UpdateParameters(BaseModel):
    role:str 
    sequence:int
    source_country:str
    organization:str
    is_searchable:bool=True
    is_deleted:bool=False
    
    @classmethod
    def convert_yes_no_to_bool(cls, data:dict):
        return cls(**{
            "is_searchable", True if data["is_searchable"].lower() =="y" else False,
            "is_deleted", True if data["is_deleted"].lower() =="y" else False,
                })
    
class IndividualUpdate(BaseModel):
    parameters:UpdateParameters
    object:IndividualObject
    
        
# -------------------- Compare --------------------    
class IndividualCompareObject(BaseModel):
    names:IndName
    nationalities:IndNationality
    parties_country:IndPartiesCountry

# Compare Request        
class IndividualCompare(BaseModel):
    parameters:CompareParameters
    object_one:IndividualCompareObject
    object_two:IndividualCompareObject

# Compare Response
class IndividualCompareResponse(BaseModel):
    names:IndCompReqNameFields
    nationalities:IndCompResNationalityFields
    parties_country:IndCompResPartiesCountryFields
    over_all_ratio:float
    
# -------------------- Search --------------------

## Search V1 Version 
class V1_search_parameters(BaseModel):
    party_id:Optional[str] = Field(..., error_msg="Party ID")
    role:Optional[str] 
    sequence:Optional[int]
    source_country:Optional[str]
    organization:Optional[str]
    size:int = Field(..., error_msg="Size")
    pre_processing:bool
    party_id_not_in:list[str]


    @field_validator("party_id" ,"role", "sequence", "source_country", "organization", mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == "":
            return None
        return value
    
class IndividualV1SearchRequest(BaseModel):
    parameters:V1_search_parameters
    object:IndividualObject

## Search by Keys
class Search_by_keys(BaseModel):
    party_id:str = Field(..., error_msg="Party ID")
    role:str 
    sequence:int
    source_country:str
    organization:str
    size:int = Field(..., error_msg="Size")
    pre_processing:bool
    party_id_not_in:list[str]


        
class IndSearch_by_object(BaseModel):
    parameters:Search_by_object_Parameters
    object:IndividualObject
    
# Search Response
class ResultsSearchObject(BaseModel):
    names:IndResSearchNamesFields
    parties_country:IndResultsSearchPartiesCountryFields
    nationalities:IndResultsSearchNationalityFields
    over_all_ratio:float
    auto_marge:bool    

class ResultsSearch(BaseModel):
    keys:MainKeys
    object:ResultsSearchObject
    
class SourceObject(BaseModel):
    keys:MainKeys
    object:IndividualObject 

class IndividualSearchResponse(BaseModel):
    source:SourceObject
    result_search:list[ResultsSearch]
    
# ---------- Checksum Response ----------
class Checksum(BaseModel):
    party_id:str
    party_type:str
    is_searchable:bool
    is_deleted:str
    names:ChecksumNameObject
    nationalities:ChecksumNationalitiesObject
    parties_country:ChecksumPartiesCountryObject
    global_checksum:str
    
    @classmethod
    def convert_yes_no_to_bool(cls, data:dict):
        return cls(**{
            "is_searchable", True if data["is_searchable"].lower() =="y" else False,
            "is_deleted", True if data["is_deleted"].lower() =="y" else False,
                })
    
    
    def to_dict(self):
        return {
            "is_searchable": "y" if self.is_searchable else "n",
            "is_deleted": "y" if self.is_deleted else "n",
        }