from pydantic import BaseModel
from typing import Literal

class settings(BaseModel):
    field:str
    index:str
    cor_local_weight:float
    cor_global_weight:float
    local_weight:float
    global_weight:float
    search_type:Literal['deterministic','phonetics']


class update_settings(BaseModel):
    cor_local_weight:float
    cor_global_weight:float
    local_weight:float
    global_weight:float
    search_type:Literal['deterministic','phonetics']