from typing import List
from pydantic import BaseModel, Field, field_validator  
from src.schemas.names import CorName, CorCompResponseNameFields, CorResponseNameFields
from src.schemas.nationalities import (
                        CorNationality, 
                        CorCompResponseNationalitiesFields, 
                        CorResponseNationalitiesFields
                    )
from src.schemas.parties_country import (
                            CorPartiesCountry, 
                            CorCompResPartiesCountryFields,
                            CorResPartiesCountryFields
                        )
from src.schemas.parties import PartiesObject
from src.schemas.base import CompareParameters, Search_by_object_Parameters

class DefaultResponse(BaseModel):
    detail:str
    
class CorporateObject(BaseModel):
    names:CorName
    nationalities:List[CorNationality]
    parties_country:CorPartiesCountry
    

class CorporateKeys(BaseModel):
    party_id:str
    organization:str
    role:str
    source_country:str
    sequence:int
    company_type:str

# -------------------- Search --------------------    

class CorporateSearchByKeys(BaseModel):
    party_id:str
    organization:str
    role:str
    source_country:str
    sequence:int
    pre_processing:bool
    size:int
    party_id_not_in:List[str]
        
class CorporateSearchByKeysByObjects(BaseModel):
    parameters:Search_by_object_Parameters
    object: CorporateObject

## Response 
class SearchResObject(BaseModel):
    names:CorResponseNameFields
    parties_country:CorResPartiesCountryFields
    nationalities:CorResponseNationalitiesFields

class SearchResultsObject(BaseModel):
    keys:CorporateKeys
    objects:SearchResObject

class SearchResponse(BaseModel):
    source:CorporateObject
    result_search:List[SearchResultsObject]
# -------------------- Compare --------------------    

class CorporateCompareObject(BaseModel):
    parties:PartiesObject
    names:CorName
    nationalities:CorNationality
    parties_country:CorPartiesCountry

# Compare Request
class CorporateCompare(BaseModel):
    parameters:CompareParameters
    object_one:CorporateCompareObject
    object_two:CorporateCompareObject
    
class CorporateCompareResponse(BaseModel):
    names:CorCompResponseNameFields
    nationalities:CorCompResponseNationalitiesFields
    parties_country:CorCompResPartiesCountryFields
    over_all_ratio:float
    
         
# -------------------- ADD --------------------    

    
class CorporateAdd(BaseModel):
    parameters:CorporateKeys
    object:CorporateObject

# -------------------- Update --------------------    

class UpdateParameters(BaseModel):
    organization:str
    role:str
    source_country:str
    sequence:int
    is_searchable:bool 
    is_deleted:bool
    company_type:str
    
    @classmethod
    def convert_yes_no_to_bool(cls, data:dict):
        return cls(**{
            "is_searchable", True if data["is_searchable"].lower() =="y" else False,
            "is_deleted", True if data["is_deleted"].lower() =="y" else False,
            }
        )
    

class CorporateUpdate(BaseModel):

    parameters:UpdateParameters
    object:CorporateObject







    
