from pydantic import BaseModel

class PartiesObject(BaseModel):
    company_type:str
    is_deleted:str
    is_searchable:str
    party_type:str 