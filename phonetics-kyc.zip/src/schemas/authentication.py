
from pydantic import BaseModel, Field, EmailStr  

class Login(BaseModel):
    email:EmailStr=Field(min_length=5, description="User's email address") 
    password:str=Field(min_length=8, description="User's password") 

class Signup(BaseModel):
    name:str=Field(min_length=3)
    email:EmailStr=Field(min_length=5, description="User's email address") 
    password:str=Field(min_length=5)

class Token(BaseModel):
    access_token:str
    token_type:str
            
class LoginResponse(BaseModel):
    token:str
