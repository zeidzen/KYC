from fastapi import status, HTTPException
from src.services.base_services import Base_Services
from src.database import close_connection
from src.schemas.settings_schema import settings
import time

######################################################################################################################
######################################################################################################################
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                        <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   Settings Operations  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                        <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
######################################################################################################################
######################################################################################################################

class Settings_Services(Base_Services):
    
    def __init__(self, endpoint, public_id=""):
        self.system_type=''
        self.endpoint=endpoint  
        self.public_id=public_id
        self.path=f"c.sc.ss.{self.endpoint[0]}.SO."
        super().__init__(system_type=self.system_type, endpoint=self.endpoint, path=self.path)

    def get_settings(self,headers:dict, public_id:str)-> dict:
        
        """ This Function will apply procedure for Get All Settings and Return Results """
        start_time=time.perf_counter()
        self.public_id, func_name, path=public_id, "get_settings",self.path+"get_settings" 
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Get Data
            settings_items=list(self.settings_file.T.to_dict().values())
            settings_items= [settings(**item).__dict__ for item in settings_items]
            # Add log
            process_time=time.perf_counter() - start_time
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_202_ACCEPTED, 
                endpoint=self.endpoint, 
                process_time=process_time,
                public_id=self.public_id, 
                inputs="", 
                output=settings_items
            )
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return settings_items, status.HTTP_202_ACCEPTED
        except HTTPException as http_exc:
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
    
    def get_field_setting(self,headers:dict, public_id:str, index:str, field: str)-> dict:
        
        """ This Function will apply procedure for Get Field Setting and Return Results """
        start_time=time.perf_counter()
        self.public_id, func_name, path=public_id, "get_field_setting",self.path+"get_field_setting" 
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Get Data
            settings_field=self.settings_file[self.settings_file['index'] ==index]
            if settings_field.empty:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, 
                    detail=f"The {index} index does not exists."
                    )
            settings_field=settings_field.loc[settings_field["field"]==field, :]
            if settings_field.empty:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, 
                    detail=f"The {field} field does not exists in the {index} index."
                    )
            settings_field= settings_field.to_dict("records")[0]
            settings_field = settings(**settings_field).__dict__ 
            # Add log
            process_time=time.perf_counter() - start_time
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_202_ACCEPTED, 
                endpoint=self.endpoint, 
                process_time=process_time,
                public_id=self.public_id, 
                inputs="", 
                output=settings_field
            )
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return settings_field, status.HTTP_202_ACCEPTED
        except HTTPException as http_exc:
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)

    def update_field_setting(self,headers:dict, public_id:str, data:dict, index:str, field: str)-> dict:
        
        """ This Function will apply procedure for update Field Setting and Return Results """
        start_time=time.perf_counter()
        self.public_id, func_name, path=public_id, "update_field_setting",self.path+"update_field_setting" 
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Get Data
            settings_field=self.settings_file[self.settings_file['index'] ==index]
            if settings_field.empty:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, 
                    detail=f"The {index} index does not exists."
                    )
            settings_field=settings_field.loc[settings_field["field"]==field, :]
            if settings_field.empty:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, 
                    detail=f"The {field} field does not exists in the {index} index."
                    )
            settings_field= settings_field.to_dict("records")[0]
            settings_field.update(data)
            object_data= settings_field.copy()
            del object_data["Id"]
            self.update_row_using_elastic_id(index="index_setting", Id=settings_field["Id"],_object=object_data)
            settings_field = settings(**settings_field).__dict__ 
            # Add log
            process_time=time.perf_counter() - start_time
            self.add_to_log(
                headers=headers, 
                status_code=status.HTTP_202_ACCEPTED, 
                endpoint=self.endpoint,
                process_time=process_time,
                public_id=self.public_id, 
                inputs="", 
                output=settings_field
            )
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return settings_field, status.HTTP_202_ACCEPTED
        except HTTPException as http_exc:
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)