from logging.handlers import RotatingFileHandler
from src.config import config
import logging

class CustomFormatter(logging.Formatter):

    log_format = config.APP_LOG_FORMAT
    grey="\x1b[38;20m"
    yellow="\x1b[33;20m"
    red="\x1b[31;20m"
    bold_red="\x1b[31;1m"
    reset="\x1b[0m"
    
    FORMATS={
        logging.DEBUG:grey + log_format + reset,
        logging.INFO:grey + log_format + reset,
        logging.WARNING:yellow + log_format + reset,
        logging.ERROR:red + log_format + reset,
        logging.CRITICAL:bold_red + log_format + reset
    }

    def format(self, record):
        log_fmt=self.FORMATS.get(record.levelno)
        formatter=logging.Formatter(log_fmt)
        return formatter.format(record)

class Log_system:

    def __init__(self,endpoint=""):
        
        self.log_format=config.APP_LOG_FORMAT
        self.log_level=config.APP_LOG_LEVEL
        self.log_loc=config.APP_LOG_LOC
        self.handlers=config.APP_HANDLERS
        self.endpoint=endpoint
        self.logger=logging.getLogger(config.PROJECT_NAME)
        self.logger.setLevel(self.get_log_level(self.log_level))
        self.create_handlers()

        if self.handlers==None or self.handlers==list():
            self.handlers=['file', 'console']

    def check_handlers_exists(self,):
        """ Check if the logger has Handlers or not """
        return self.logger.hasHandlers()

    def create_handlers (self):

        """This Function Create Handler for Debug level of log """
        if not self.check_handlers_exists():

            # Application log handler with file rotation 
            app_file_handler = RotatingFileHandler(self.log_loc, maxBytes=config.MAX_BYTES,backupCount=config.BACKUP_COUNT)
            app_file_handler.setLevel(self.get_log_level(level=self.log_level))
            app_file_handler.setFormatter(CustomFormatter())

            # Console handler for terminal output with custom formatter.
            console_handler=logging.StreamHandler()
            console_handler.setLevel(self.get_log_level(level=self.log_level))
            console_handler.setFormatter(logging.Formatter(self.log_format))
            console_handler.setFormatter(CustomFormatter())
            # Add logs to logger

            if 'file' in self.handlers: 
                self.logger.addHandler(app_file_handler)
            if 'console' in self.handlers:
                self.logger.addHandler(console_handler)
        return 
        
    def get_log_level(self, level=None):
       """ Determine log level based on configuration. """
       levels = {
           'DEBUG': logging.DEBUG,
           'INFO': logging.INFO,
           'WARNING': logging.WARNING,
           'ERROR': logging.ERROR,
           'CRITICAL': logging.CRITICAL
       }
       return levels.get(level, logging.DEBUG)  # Default to DEBUG if level is unknown

    def colored(self,r, g, b, text):
        return "\033[38;2;{};{};{}m{} \033[38;2;255;255;255m".format(r, g, b, text)


    def print_information (self, objects):
        
        """ this function will print in case log level DEBUG or INFO """
        
        if self.log_level in ["DEBUG", "INFO"]:
            colored_text=self.colored(101, 103, 140, objects)
            self.logger.info(objects,extra={"path":"", "endpoint":self.endpoint})
            #print(colored_text)
        else:
            return



