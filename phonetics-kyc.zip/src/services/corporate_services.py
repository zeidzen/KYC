from fastapi import status, HTTPException
from src.services.base_services import Base_Services
from src.database import close_connection
from src.services.phonetic import Phonetics 
from src.utils import get_cache, update_cache, model_to_dict
from src.config import config
import re
import time

######################################################################################################################
######################################################################################################################
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                       <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Corporate Operations  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                       <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
######################################################################################################################
######################################################################################################################

class Corporate_Services (Base_Services):

    def __init__(self, endpoint="", public_id=""):
        self.system_type='corporate'
        self.endpoint=endpoint
        super().__init__(system_type =self.system_type, endpoint=self.endpoint)
        self.path=f"c.cc.cs.{self.endpoint[0]}.CO."
        self.public_id=public_id
        
    #######################################################################################################################
    ##############################################   procedures   #########################################################
    #######################################################################################################################

    def add_procedure(self, headers, data)-> tuple:
        
        """ This Function will apply procedure for add and Return Results """
        start_time=time.perf_counter()
        func_name, path="add_procedure", self.path+"add_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            data=model_to_dict(data)
            data["parameters"]["is_searchable"]=True
            data["parameters"]["is_deleted"]=False
            data['parameters']["party_type"]="corporate"
            data['parameters'].update(data['object'])
            data=data['parameters']
             # Normalize data
            data["names"]=self.normalize_names_object(data["names"])
            data["names"]["party_type"]="corporate"
            # Prepare Data
            output=self.prepare_objects_data(data)
            # Add data to database
            output=self.add_objects_to_database(output["data"])
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            output={"detail":output["detail"]}            
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_200_OK , 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            return output, status.HTTP_200_OK 
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
        
    def update_procedure (self, headers, data, party_id)-> tuple:
        
        """ This Function will apply procedure for Update and Return Results """
        start_time=time.perf_counter()
        func_name, path="update_procedure", self.path+"update_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            data=model_to_dict(data)
            data["parameters"]["party_id"]=party_id
            data['parameters']["party_type"]="corporate"
            data['parameters'].update(data['object']) 
            data=data['parameters']
            data["names"]=self.normalize_names_object(data["names"]) # Normalize data 
            output=self.prepare_objects_data(data) # Prepare Data
  
            # Add data to database
            if self.add_type =="update":
                output=self.update_object_in_database(output["data"])
                status_code=status.HTTP_200_OK
            else:
                output=self.add_objects_to_database(output["data"])
                status_code=status.HTTP_201_CREATED
                
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            output={"detail":output["detail"]}
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            return {"detail":output["detail"]}, status_code
        
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)

    def search_by_keys_procedure (self, headers, data)-> tuple:
        
        """ This Function will apply procedure for Update and Return Results """
        start_time=time.perf_counter()
        func_name, path="search_by_keys_procedure", self.path+"search_by_keys_procedure"
        
        try:
            data=model_to_dict(data)
            self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            # Apply Search
            output, status_code =self.search_by_keys(
                                    parameters=data, size=data["size"], 
                                    pre_processing=data["pre_processing"],
                                    init_country=headers['init-country']
                                )
            
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
        
    def search_by_object_procedure (self, headers, data)-> tuple:
        
        """ This Function will apply procedure for Update and Return Results """
        start_time=time.perf_counter()
        func_name, path="search_by_object_procedure", self.path+"search_by_object_procedure"
        
        try:

            data=model_to_dict(data)
            self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            # Apply Search
            output, status_code =self.search_by_object(
                source_obj=data["object"],
                parameters=data["parameters"], 
                size=data["parameters"]["size"], 
                pre_processing=data["parameters"]["pre_processing"],
                init_country=headers['init-country']
            )
            
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
        
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
            
    def compare_procedure(self, headers, data)-> tuple:
        
        """ This Function will apply procedure for compare and Return Results """
        start_time=time.perf_counter()
        func_name, path="compare_procedure", self.path+"compare_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            data=model_to_dict(data)
            # Compare Between Two Objects
            self.obj_phonetics=self.get_phonetics_obj()
            output=self.obj_phonetics.compare_similarity_for_two_object(
                source_object=data["object_one"],  
                similar_object=data["object_two"], 
                pre_processing=data["parameters"]["pre_processing"],
                party_type="corporate"
               )
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint+"/"+self.system_type,
                process_time=time.perf_counter() - start_time, 
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            return output, status.HTTP_200_OK

        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
        
    #######################################################################################################################
    #######################################################################################################################
    #######################################################################################################################

    def normalize_names_object(self,names_object)-> dict:
        
        """This function checks the correctness of the "names" field based on three rules:
            1- It should not have any spaces at the beginning or end.
            2- All letters should be in lowercase.
            3- It should not have more than one space between words."""
        func_name, path="normalize_names_object", self.path+"normalize_names_object"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        for key in names_object.keys():
            if names_object[key] not in [None, [], "" ]:
                names_object[key]=names_object[key].strip().lower()
                names_object[key]=re.sub(r'\s+', ' ', names_object[key])
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return names_object
    
    def get_phonetics_obj(self):
        
        normalize_data= get_cache(cache_key="phonetics_normalize_data")
        normalize_data=normalize_data.fillna("")
        if normalize_data.empty: 
            normalize_data=self.read_normalize_data()
            update_cache(cache_key="phonetics_normalize_data", data=normalize_data)

        return Phonetics(
                        settings_file=self.settings_file, 
                        normalize_file=normalize_data,
                        log_system=self.obj_log_system,
                        system_type=self.system_type,
                        endpoint=self.endpoint
                    )
    
    def generate_query_for_corporate_search (self, index:str, _object:dict, parameters:dict, size=None, _sort=None, _source=None)-> dict:

        # Phonetics lists
        phonetics_must_list, phonetics_must_not_list, phonetics_should_list=list(), list(), list()
        # Deterministic lists
        deterministic_must_list, deterministic_must_not_list, deterministic_should_list =list(), list(), list()
        query=dict()

        query['query']={ "bool":{ "must":[], "should":[], "must_not":[] } }

        if size !=None:
            if size > 0:
                query['size']=size
        if _source !=None:
            query['_source']=_source
        if _sort !=None:
            query['_sort']=_sort 
        if parameters !=None:
                    
            if "party_id_not_in" in parameters.keys():
                if parameters['party_id_not_in'] !=[]:
                    terms={
                            "terms":{ "party_id":parameters['party_id_not_in'] }
                            }
                    deterministic_must_not_list.append(terms)
                del parameters['party_id_not_in']

            for key, value in parameters.items():
                if value !="" and value !=None:
                    match={"match":dict()}
                    key_dict={ "query":value, "operator":"and" }
                    match['match'][key]=key_dict
                    deterministic_must_list.append(match)
                else:
                    continue 
        if _object !=None:
            # Read Settings File
            settings=self.settings_file[self.settings_file['index']==config.INDEX_MAP[index]]
            if index =="names":
                for key, value in _object.items():

                    if value =="" or value ==None: continue 
                    key_info=settings[settings['field']==key]
                    if key_info.iloc[0,:]["search_type"] =="phonetics":

                        match={"match":dict()}
                        key_dict={ "query":value,"fuzziness":"AUTO", "operator":"and" }
                        match['match'][key]=key_dict
                        phonetics_should_list.append(match)

            elif index =="nationalities":

                if  _object !={} and _object !=[] :
                    if len (_object)==1:
                        for key, value in _object[0].items():
                            if value =="" or value ==None:
                                continue 
                            # Deterministic Fields
                            term={"match":dict()}  
                            term['match'][key]={ 'query':value, "operator":"and" } 
                            deterministic_must_list.append(term)
                    else:
                        for obj in _object:
                            for key, value in obj.items():
                                    if value =="":
                                        continue 
                                    # Deterministic Fields
                                    term={"match":dict()}  
                                    term['match'][key]={ 'query':value, "operator":"and" } 
                                    deterministic_should_list.append(term)

        must=phonetics_must_list + deterministic_must_list 
        if   must !=[]:          
            query['query']['bool']['must'].append( {"bool":{"must":must }})

        should=phonetics_should_list + deterministic_should_list
        if should !=[]:
            query['query']['bool']['should'].append( {"bool":{"should":should }})

        if deterministic_must_not_list !=[]:
            query['query']['bool']['must_not']=deterministic_must_not_list 
        return query 

    ##########################################################################################################################
    ################################################ Search Procedure Functions ##############################################
    ##########################################################################################################################

    def collect_nationalities_data (self, obj_keys:dict)-> list:
        
        """This function will get all data related to result object from nationalities index"""
        index, obj_data="nationalities",  list()
        keys, _source=self.select_keys_and_source_for_index_settings(index,obj_keys)
        query=self.generate_query_for_corporate_search (index=index, _object=None, parameters=keys, _source=_source)
        result_index =self.es.search(index=config.NATIONALITIES_INDEX, body=query)
        if len (result_index["hits"]["hits"])> 0:
            for obj_result in result_index["hits"]["hits"]:
                obj_data.append(obj_result['_source'])
        return obj_data

    def collect_parties_country_data (self,obj_keys:dict)-> dict:
        
        """This function will get all data related to result object form parties country index"""
        index, obj_data="parties_country", dict()
        keys, _source=self.select_keys_and_source_for_index_settings(index,obj_keys)
        query=self.generate_query_for_corporate_search(index =index, _object=None, parameters=keys, _source=_source)
        result_index=self.es.search(index=config.PARTIES_COUNTRY_INDEX, body=query)
        if result_index["hits"]["hits"] !=[]:
            obj_data=result_index["hits"]["hits"][0]['_source']                 
        return obj_data

    def collect_objects_data(self, results, source_obj:dict)-> list:
        
        """ This function will collect all data related the object silver with source object."""
        data=list()
        for result_obj in results["hits"]["hits"]:
            # Collect Name Data and Keys 
            if result_obj['_source']['party_id'].lower().strip()!=source_obj['keys']['party_id'].lower().strip():
                obj_keys, obj_data=self.Select_Keys_name_data_for_result_object(result_obj['_source'])
            else:continue
            # Collect Parties Data and Check party id is deleted or searchable.
            parties_data=self.get_parties_data(obj_keys["party_id"],party_type=self.system_type)
            if not parties_data["status"]:continue
            obj_data["parties" ]=parties_data["data"]
            # Collect Parties Country Data
            obj_data["parties_country" ]=self.collect_parties_country_data(obj_keys)
            # Collect Nationalities Data
            obj_data["nationalities" ]=self.collect_nationalities_data(obj_keys)
            data.append({"keys":obj_keys,"object":obj_data})
        return data
    
    def search_by_keys(
            self, 
            parameters:dict, 
            size=None, 
            _sort=None, 
            pre_processing=True, 
            init_country='jo'
            )-> tuple:

        """ This Main Function For corporate Search, will return source object and results similar source object. """
        func_name, path="search_by_keys", self.path+"sp."+"search_by_keys"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Get Data related to primary keys in inputs
        output, status_code=self.get_source_data_based_on_parameters(self.get_primary_keys(parameters))        
        if not output["status"]:
            return {"detail":output["detail"]}, status_code
        
        if output["data"]["object"]["names"]["party_type"] == "corporate":
                source_obj=output["data"]
        else:
            content ={'detail':'The keys associated with individuals data, kindly utilize the designated individuals endpoints.'}
            self.obj_log_system.logger.warning(content["detail"],extra={"path":self.path,"endpoint":self.endpoint})           
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
        
        # Find objects similar to the source object        
        query=self.generate_query_for_corporate_search ( 
            index =config.NAMES_INDEX, 
            _object=output["data"]["object"]["names"],
            parameters=parameters,
            size=size, 
            _sort=_sort
           )
        results=self.es.search(index=config.NAMES_INDEX, body=query)

        # Collect Data related objects similar and Restructure Similar Objects
        output=self.collect_objects_data(results=results, source_obj=output["data"])
        
        # Step 5:Phonetics Operations
        data=list()
        for similar_object in output:
            self.obj_phonetics=self.get_phonetics_obj()
            data_with_weights=self.obj_phonetics.corporate_search_func_check_similarity(
                                                                source_object=source_obj,  
                                                                similar_object=similar_object, 
                                                                pre_processing=pre_processing)
            if data_with_weights['over_all_ratio'] !=0:
                similar_object["data_with_weights"]=data_with_weights
                data.append (similar_object)
        # Step 6:Prepare Results
        data=self.prepare_results(data, source_obj)
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return data, status.HTTP_200_OK

    def search_by_object(
            self, 
            parameters:dict, 
            source_obj:dict,
            size=None, 
            _sort=None, 
            pre_processing=True, 
            init_country='jo'
            )-> tuple:

        """ This Main Function For corporate Search, will return source object and results similar source object. """
        func_name, path="search_by_object", self.path+"sp."+"search_by_object"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        # Find objects similar to the source object        
        query=self.generate_query_for_corporate_search ( 
            index =config.NAMES_INDEX, 
            _object=source_obj["names"],
            parameters=parameters,
            size=size, 
            _sort=_sort
           )
        results=self.es.search(index=config.NAMES_INDEX, body=query)

        # Collect Data related objects similar and Restructure Similar Objects
        output=self.collect_objects_data(results=results, source_obj=source_obj)
        
        # Step 5:Phonetics Operations
        data=list()
        for similar_object in output:
            self.obj_phonetics=self.get_phonetics_obj()
            data_with_weights=self.obj_phonetics.corporate_search_func_check_similarity(
                                                                source_object=source_obj,  
                                                                similar_object=similar_object, 
                                                                pre_processing=pre_processing)
            if data_with_weights['over_all_ratio'] !=0:
                similar_object["data_with_weights"]=data_with_weights
                data.append (similar_object)
        # Step 6:Prepare Results
        data=self.prepare_results( data=data, source_obj=source_obj)
        self.obj_log_system.logger.debug(f"/ {func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return data, status.HTTP_200_OK
