######################################################################################################################
######################################################################################################################
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                           <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Authentication Operations <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                           <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
######################################################################################################################
######################################################################################################################

from fastapi import status, HTTPException
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime, timedelta, timezone
import uuid 
import jwt
from src.database import close_connection
from src.services.base_services import Base_Services
from src.config import config

import time

class Auth_Services (Base_Services):

    def __init__(self, endpoint):

        self.system_type='auth'
        self.endpoint=endpoint
        super(Auth_Services,self).__init__(system_type =self.system_type, endpoint=self.endpoint,path=f"p.c.av.ao.{self.endpoint[0]}.AO.")
        self.path=f"service.auth"
        self.public_id=""

    #######################################################################################################################
    ##############################################   procedures   #########################################################
    #######################################################################################################################

    def login_procedure(self,data,headers):
        """ """
        start_time= time.perf_counter()
        func_name, path="login_procedure", self.path+"login_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        self.obj_log_system.logger.info(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Check User Credential
            output=self.check_user_Credential(email=data["email"], password=data["password"])
            if output["status"]:
                #create token 
                output, status_code=self.create_token(), status.HTTP_201_CREATED
            else:
                output, status_code={"detail":"The user is not exists."}, status.HTTP_404_NOT_FOUND
            # Add to Log
            data['password']='*'*8
            process_time= time.perf_counter() - start_time 
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint, 
                process_time=process_time, 
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
        except HTTPException as http_exc:
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
            
    def signup_procedure (self, data:dict, headers:dict)-> dict:
        
        """ This Function will apply procedure for Sign UP and Return Results """
        start_time= time.perf_counter()
        func_name, path="signup_procedure", self.path+"signup_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Check User Exists
            if self.check_user_exists(data["email"]):
                output, status_code={"detail":"User already exists."}, status.HTTP_409_CONFLICT
                self.obj_log_system.logger.warning("Validation Error",extra={"path":path,"endpoint":self.endpoint})
            else:
                data=self.add_new_user(data)
                output, status_code={'detail':'Successfully registered.'}, status.HTTP_201_CREATED
            # Add to Log   
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            process_time= time.perf_counter() - start_time 
            self.add_to_log (
                headers=headers, 
                status_code=status_code,
                endpoint=self.endpoint,
                process_time=process_time, 
                public_id="", 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            return output, status_code
        except:
            content={"detail":f"Internal server error occurred in the {self.endpoint} endpoint."}
            self.obj_log_system.logger.error(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT
        
    def get_all_users_procedure(self,headers:dict, public_id:str)-> dict:
        
        """ This Function will apply procedure for Get All User and Return Results """
        start_time= time.perf_counter()
        self.public_id, func_name, path=public_id, "get_all_users_procedure",self.path+"get_all_users_procedure" 
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Get Data
            users=list (self.users[['public_id','name','email']].T.to_dict().values())
            # Add log
            process_time= time.perf_counter() - start_time 
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_202_ACCEPTED, 
                endpoint=self.endpoint, 
                process_time=process_time,
                public_id=self.public_id, 
                inputs="", 
                output=""
            )
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return users, status.HTTP_202_ACCEPTED
        except:
            content={"detail":"Internal server error occurred in the {} endpoint.".format(self.endpoint)}
            self.obj_log_system.logger.error(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT
    
    def change_password_procedure (self,data:dict, headers:dict, current_user:str)-> dict:
        
        """ This Function will apply procedure for Change Password and Return Results """
        start_time= time.perf_counter()
        func_name, path="change_password_procedure", self.path+"change_password_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            if not self.check_is_admin(public_id=current_user):
                output, status_code={'detail':'Only the administrator has the permission to Update.'}, status.HTTP_403_FORBIDDEN
                self.obj_log_system.logger.critical(output["detail"],extra={"path":path,"endpoint":self.endpoint})
                
            elif self.check_user_exists(public_id=current_user):
                result=self.update_password(data['public_id'].strip(), data["password"].strip())
                if result['status']:
                    self.obj_log_system.logger.warning(f"Password for {current_user} is updated",extra={"path":path,"endpoint":self.endpoint})
                    output, status_code ={'detail':'Password Updated Successfully.'}, status.HTTP_201_CREATED
                else:
                    output, status_code={'detail':'Error when update the new password'}, status.HTTP_400_BAD_REQUEST
            else:
                output, status_code={"detail":"The user is not exists."}, status.HTTP_404_NOT_FOUND
                self.obj_log_system.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
            
            process_time= time.perf_counter() - start_time 
            self.add_to_log(
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint,
                process_time=process_time, 
                public_id=current_user, 
                inputs=data, 
                output=output
            )
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return output, status_code
        except:
            content={"detail":"Internal server error occurred in the {} endpoint.".format(self.endpoint)}
            self.obj_log_system.logger.error(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT

    #######################################################################################################################
    #######################################################################################################################
    #######################################################################################################################
    
    def create_token(self):
        """Create Login Token."""
        func_name="create_token"
        path=self.path +func_name
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # generates the JWT Token 
        exp = datetime.now(timezone.utc)+timedelta(
                                            hours=config.ACCESS_TOKEN_EXPIRE_HOURS,
                                            minutes=config.ACCESS_TOKEN_EXPIRE_MINUTES)
        token=jwt.encode({
                        'public_id':self.public_id, 
                        'exp':exp}, 
                        config.ACCESS_SECRET_KEY,
                        algorithm=config.ALGORITHM
                       )
        #.decode("utf-8")
        output={'token':token,}
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output

    def check_user_Credential(self,email:str, password:str)-> dict:
        
        """ This Function will check in the database if the user credential is correct or not """
        func_name, path="check_user_Credential", self.path+"check_user_Credential"
        path=self.path +func_name
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Check user 
        users=self.users.loc[self.users['email']==email,:]
        if users.empty:
            self.obj_log_system.logger.debug("the credential could not verify",extra={"path":path,"endpoint":self.endpoint})           
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Could not verify')
             
        elif check_password_hash(users.loc[:,'password'].values[0], password):
            # generates the JWT Token 
            self.public_id=users.loc[:,'public_id'].values[0]
            output={'status':True, 'detail':"User credential is correct." }
        else:
            detail='Email or password is incorrect.'
            self.obj_log_system.logger.warning(detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail)
        
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output    
     
    def check_is_admin(self, public_id:str)-> bool:
        # Check user 
        users=self.users.loc[(self.users['public_id']==public_id)& (self.users['is_admin']==True),:]
        if users.empty:
           output=False
        else:
            output=True
        return output
    
    def check_user_exists (self,email:str=None,public_id:str=None)-> bool:
        
        """ this function check if user exists by check email or public id in users index """
        
        
        func_name, path, self.public_id="check_user_exists", self.path +"check_user_exists", public_id
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Check user 
        users=self.users.loc[(self.users['email'] ==email)| (self.users['public_id']==public_id),:]
        if users.empty:
           output=False
        else:
            output=True
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output
    
    def add_new_user (self,data):
        # Data For create new object 
        
        func_name, path="add_new_user", self.path+"add_new_user"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        data['is_admin']=False
        data['email']=data['email'].strip().lower()
        data['name']=data['name'].strip()
        data["password"]=generate_password_hash(str(data["password"]))
        data["public_id"]=str(uuid.uuid4())
        result=self.add_row(index=config.USERS_INDEX, _object=data)
        data["password"]="*"*10
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return data

    def update_password(self,public_id, new_password):
        
        func_name, path="update_password", self.path +"update_password"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        user=self.users.loc[self.users['public_id']==public_id,:]
        new_object=dict()
        new_object['password']=generate_password_hash(str(new_password))
        new_object['email']=user.loc[:,'email'].values[0]
        new_object['name']=user.loc[:,'name'].values[0]
        new_object['public_id']=user.loc[:,'public_id'].values[0]
        new_object['is_admin']=user.loc[:,'is_admin'].values[0]
        result=self.update_row_using_elastic_id(index=config.USERS_INDEX,Id=user.loc[:,'Id'].values[0], _object=new_object)
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return result
        
