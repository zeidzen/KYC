import re
import string

class normalization ():

    def __init__(self, lang="en"):
        pass

        
    def remove_diacritics(self,text, language="ar"):
        
        arabic_diacritics=re.compile("""
                                 ّ    | # Tashdid
                                 َ    | # Fatha
                                 ً    | # Tanwin Fath
                                 ُ    | # Damma
                                 ٌ    | # Tanwin Damm
                                 ِ    | # Kasra
                                 ٍ    | # Tanwin Kasr
                                 ْ    | # Sukun
                                 ـ     # Tatwil/Kashida
                             """, re.VERBOSE)
        text=re.sub(arabic_diacritics, '', text)
        return text

    def remove_punctuations (self,text):
        
        # remove punctuations
        new_text=""
        punctuations='''=`÷×؛<>_()*&^%][ـ،/:"؟.,'{}~¦+|!”…“–ـ''' #+ string.punctuation
        for char in text:
            if char not in punctuations:
                new_text=new_text + char
            else:
                new_text=new_text + ' '
            text=new_text
        return text  

    def remove_arabic_text (self,text):
        main_text=''.join(ch for ch in text if ch not in set(string.punctuation))
        text=filter(lambda x:x==' ' or x not in string.printable, main_text)
        return text

    def remove_english_text (self,text):
        output=re.sub(r'\s*[A-Za-z]+\b', '', text)
        text=output.rstrip()
        return text 

    def remove_numbers (self,text):
        arabic_number={  0:'۰',  1:'١',  2:'٢',  3:'۳', 4:'٤',  5:'٥', 6:'۶', 7:'۷',8:'۸', 9:'۹',10:"٠",11:"٧",12:'٦',13:'٨',14:'٣',15:'٩'}
        pattern=r'[0-9\(\)/]+'
        # Match all digits in the string and replace them with an empty string
        text=re.sub(pattern, ' ', text)
        for key, value in arabic_number.items():
            text=text.replace( value , '')
        return text 

    def remove_duplicate_characters (self,text):
        arabic_char=["ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج","د","ش","س","ي","ب","ل","ا","ت","ن","م","ك","ط","ئ","ء","ؤ","ر","ى","ة","و","ز","ظ"]
        for i in arabic_char:
            text=re.sub('{}+'.format(i), i,text)
            text=text.strip()
        return text 
        
    def normalize (self,text, language="en"):
        normalize_file=self.normalize_file[self.normalize_file['language']==language]

        punctuation='''=`÷×؛<>_()*&^%][ـ،/:"؟.,'{}~¦+|!”…“–ـ''' + string.punctuation 
        translator=str.maketrans('','',punctuation)
        text=text.translate(translator)

        for index, row in normalize_file.iterrows():
            text=re.sub(row['character'], row['replace_to'], text)
        text=re.sub(' ','', text)
        return text.lower().strip()
        