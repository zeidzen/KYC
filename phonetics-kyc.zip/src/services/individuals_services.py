from fastapi import status, HTTPException
from src.services.base_services import Base_Services
from src.services.phonetic import Phonetics 
from src.utils import get_cache, update_cache, model_to_dict
from src.database import close_connection
from src.config import config
from src.schemas.individuals import Search_by_object_Parameters
import re
import time

######################################################################################################################
######################################################################################################################
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                        <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> individuals Operations <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                        <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
######################################################################################################################
######################################################################################################################

class Individuals_Services (Base_Services):
    
    def __init__(self, endpoint, public_id=""):
        self.system_type='individuals'
        self.endpoint=endpoint  
        self.public_id=public_id
        self.path=f"c.ic.{self.endpoint[0]}.IS."
        super().__init__(system_type=self.system_type, endpoint=self.endpoint, path=self.path)
        # Create Phonetics Operation Object

    #######################################################################################################################
    ##############################################   procedures   #########################################################
    #######################################################################################################################

    def add_procedure(self, headers, data):
        
        """ This Function will apply procedure for individuals add and Return Results """
        start_time=time.perf_counter()
        func_name, path="add_procedure", self.path +"add_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Normalize data 
            data=model_to_dict(data)
            data['parameters']["party_type"]="individuals"
            data['parameters']["is_searchable"]=True
            data['parameters']["is_deleted"]=False
            data['parameters'].update(data['object'])
            data=data['parameters']
            data["names"]=self.normalize_names_object(data["names"])
            data["names"]["party_type"]="individuals"
            # Prepare Data
            output=self.prepare_objects_data(data)
            # Add Data to Database
            output=self.add_objects_to_database(output["data"])
            # Add to Logs
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_201_CREATED, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # End procedure and close Connection
            close_connection(self.es)
            return output, status.HTTP_201_CREATED

        except HTTPException as http_exc:
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
    
    def update_procedure(self, headers, data, party_id):
        
        """ This Function will apply procedure for Update and Return Results """
        start_time=time.perf_counter()
        func_name, path="update_procedure", self.path +"update_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Normalize data 
            data=model_to_dict(data)
            data["parameters"]["party_id"]=party_id
            data['parameters']["party_type"]="individuals"
            data['parameters'].update(data['object'])
            data=data['parameters']
            data["names"]=self.normalize_names_object(data["names"])
            # Prepare Data
            output=self.prepare_objects_data(data)
            # Add or Update data to database
            if self.add_type =="update":
                output=self.update_object_in_database(output["data"])
                status_code=status.HTTP_200_OK 
            else:
                output=self.add_objects_to_database(output["data"])
                status_code=status.HTTP_201_CREATED
            # Add to Logs
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # End procedure and close Connection
            close_connection(self.es)
            return output, status_code
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log(
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
        
    def compare_procedure(self, headers, data):
        
        """ This Function will apply procedure for compare and Return Results """
        start_time=time.perf_counter()
        func_name, path="compare_procedure", self.path+"compare_procedure"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            data=model_to_dict(data)
            # Compare Between Two Objects
            self.obj_phonetics= self.get_phonetics_obj()
            result_with_weight=self.obj_phonetics.compare_similarity_for_two_object(
                    source_object=data["object_one"],
                    similar_object=data["object_two"],
                    pre_processing=data["parameters"]["pre_processing"],
                    party_type="individuals")
            
            output, status_code=result_with_weight, status.HTTP_202_ACCEPTED
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type,
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # End procedure and close Connection
            close_connection(self.es)
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
                
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
            
    def search_by_keys_procedure (self, headers, data):
            
        """ This Function will apply procedure for Search By Keys and Return Results """
        start_time=time.perf_counter()
        func_name, path="search_by_keys_procedure", self.path +"search_by_keys_procedure"
        
        try:
            data=model_to_dict(data)
            self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})            
            output=self.Search_by_keys( 
                                parameters=data, 
                                size=data["size"], 
                                pre_processing=data["pre_processing"], 
                                init_country=headers['init-country'])
            
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint+"/"+self.system_type,
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # End procedure and close Connection
            close_connection(self.es)
            return output, status.HTTP_200_OK 

        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
        
    def search_by_object_procedure (self, headers, data):
        
        """ This Function will apply procedure for Search By Object and Return Results """
        start_time=time.perf_counter()
        func_name, path="search_by_object_procedure", self.path +"search_by_object_procedure"
        
        try:
            data=model_to_dict(data)
            self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})            
            output=self.Search_by_object( 
                                source_obj=data["object"],                                                
                                parameters=data["parameters"], 
                                size=data["parameters"]["size"], 
                                pre_processing=data["parameters"]["pre_processing"], 
                                init_country=headers['init-country'])
            
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # End procedure and close Connection
            close_connection(self.es)
            return output, status.HTTP_200_OK 
        
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)

    def search_procedure (self, headers, data):
        
        """ This Function will apply procedure for Search By Object and Return Results """
        start_time=time.perf_counter()
        func_name, path="search_by_object_procedure", self.path +"search_by_object_procedure"
        
        try:
            data=model_to_dict(data)
            self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})    
            
            if self.is_search_by_keys(data["parameters"]):
                output=self.Search_by_keys( 
                                parameters=data["parameters"], 
                                size=data["parameters"]["size"], 
                                pre_processing=data["parameters"]["pre_processing"], 
                                init_country=headers['init-country'])
                
                
            else:
                data["parameters"] = Search_by_object_Parameters(**data["parameters"]).__dict__
                output=self.Search_by_object( 
                                source_obj=data["object"],                                                
                                parameters=data["parameters"], 
                                size=data["parameters"]["size"], 
                                pre_processing=data["parameters"]["pre_processing"], 
                                init_country=headers['init-country'])
            
            self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            self.add_to_log (
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # End procedure and close Connection
            close_connection(self.es)
            return output, status.HTTP_200_OK 
        
        except HTTPException as http_exc:
            # Add to Elastic Search Logs
            self.add_to_log (
                headers=headers, 
                status_code=http_exc.status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=time.perf_counter() - start_time,
                public_id=self.public_id, 
                inputs=data, 
                output={"detail":http_exc.detail}
            )
            close_connection(self.es)
            self.obj_log_system.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)      
   
    #######################################################################################################################
    #######################################################################################################################
    #######################################################################################################################

    def normalize_names_object(self,names_object):
        
        """ 
        This function checks the correctness of the "names" field based on three rules:

            1- It should not have any spaces at the beginning or end.
            2- All letters should be in lowercase.
            3- It should not have more than one space between words.
        """
        func_name, path="normalize_names_object", self.path+"normalize_names_object"
        self.obj_log_system.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        full_names=dict()
        full_names["en"]=["first_name_en", "second_name_en", "third_name_en", "last_name_en"]
        full_names["ar"]=['first_name_ar', 'second_name_ar', 'third_name_ar', 'last_name_ar']
        for key, values in full_names.items():
            
            if names_object[f'first_name_{key}'] not in [None, ""] and names_object[f'last_name_{key}'] not in [None, ""]:
                # Create Full Name english form (FN, SN, TN, LN)
                full=list()
                for  field in values:
                    if names_object[field] not in [None, ""]:
                        full.append(names_object[field])
                        
                names_object[f'full_name_{key}']=" ".join(full)
                names_object[f'full_name_{key}']=names_object[f'full_name_{key}'].strip().lower()
                names_object[f'full_name_{key}']=re.sub(r'\s+', ' ', names_object[f'full_name_{key}'])
                
            else:continue   
            
        self.obj_log_system.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})            
        return names_object
    
    def get_phonetics_obj(self):
        
        normalize_data= get_cache(cache_key="phonetics_normalize_data")
        
        if normalize_data.empty: 
            normalize_data=self.read_normalize_data()
            update_cache(cache_key="phonetics_normalize_data", data=normalize_data)
        normalize_data=normalize_data.fillna("")

        return Phonetics(
                        settings_file=self.settings_file, 
                        normalize_file=normalize_data,
                        log_system=self.obj_log_system,
                        system_type=self.system_type,
                        endpoint=self.endpoint
                    )
    
    def is_search_by_keys(self, parameters):
        
        if (parameters["party_id"] != None and parameters["role"] != None and 
            parameters["sequence"] != None and parameters["source_country"] != None and 
            parameters["organization"] != None): 
            return True
        return False 
    
    ################################################################################################################
    #################################### Build Query Elasticsearch Functions #######################################
    ################################################################################################################

    def generate_query (self, index:str, fields:dict, size=None)-> dict:
        
        # lists
        phonetics_must_list, phonetics_must_not_list, phonetics_should_list =list(), list(), list()
        deterministic_must_list, deterministic_must_not_list, deterministic_should_list =list(), list(),list()
        query=dict()
        query['query']=dict()
        query['query']['bool']={ "must":list(),"filter":list(),"should":list(),"must_not":list() }
        query['size']=size

        settings=self.settings_file[self.settings_file['index'] ==index]
        
        for key, value in fields.items():
            if value =='' or value ==[]:
                continue 
            key_info=settings[settings['field']==key]
            # Phonetics Fields
            if key_info.iloc[0,:]["search_type"] =="phonetics":
                match={"match":dict()}
                key_dict={ "query":value,"fuzziness":"{}".format(key_info.iloc[0,:]["fuzzi_value"]), "operator":"and" }
                match['match'][key]=key_dict
                phonetics_must_list.append(match)

            # Deterministic Fields
            elif key_info.iloc[0,:]["search_type"] =="deterministic":
                term={"match":dict()} 
                term ["match"][key] ={ 'query':value} 
                deterministic_must_list.append(term)

        # Phonetics  List 
        if phonetics_must_list !=[]:
            query['query']['bool']['must'].append( {"bool":{"should":phonetics_must_list }})
        if phonetics_should_list !=[]:
            query['query']['bool']['must'].append( {"bool":{"should":phonetics_should_list }})
        if phonetics_must_not_list !=[]:
            query['query']['bool']['must'].append( {"bool":{"must_not":phonetics_must_not_list }})
        # Deterministic List
        if deterministic_must_list !=[]:
            query['query']['bool']['must'].append( {"bool":{"must":deterministic_must_list }})
        if deterministic_should_list !=[]:
            query['query']['bool']['must'].append( {"bool":{"should":deterministic_should_list }})
        if deterministic_must_not_list !=[]:
            query['query']['bool']['must'].append( {"bool":{"must_not":deterministic_must_not_list }})
        return query

    def generate_query_for_search (self, index:str, _object:dict, parameters:dict, size=10, _sort=None, _source=None)-> dict:
        # Phonetics lists
        phonetics_must_list, phonetics_must_not_list, phonetics_should_list=list(), list(), list()
        # Deterministic lists
        deterministic_must_list, deterministic_must_not_list, deterministic_should_list =list(), list(), list()
        query=dict()
        query['query']={ "bool":{ "must":[], "should":[], "must_not":[] } }
        query['size']=size
        
        if _source !=None:
            query['_source']=_source
            
        if "party_id_not_in" in parameters.keys():
            if parameters['party_id_not_in'] !=[]:
                terms={"terms":{ "party_id":parameters['party_id_not_in'] }}
                deterministic_must_not_list.append(terms)
            del parameters['party_id_not_in']
            
        if _object ==None:
            for key, value in parameters.items():
                if value !="" and value !=None:
                    match={"match":dict()}
                    key_dict={ "query":value, "operator":"and" }
                    match['match'][key]=key_dict
                    deterministic_must_list.append(match)
                else:
                    continue 

        print(_object)
        print("===="*20)
        if _object !=None:
            # Read Settings File
            settings=self.settings_file[self.settings_file['index'] ==config.INDEX_MAP[index]]
            if index =="names":
                for key, value in _object.items():
                    if value =="" or value ==None or key not in ["first_name_ar","first_name_en","last_name_ar","last_name_en","full_name_ar","full_name_en"]:
                        continue 
                    key_info=settings[settings['field']==key]
                    if key_info.iloc[0,:]["search_type"] =="phonetics":

                        match={"match":dict()}
                        key_dict={ "query":value,"fuzziness":"AUTO", "operator":"and" }
                        match['match'][key]=key_dict
                        if key.lower()in ['full_name_ar','full_name_en'] and not (
                                                                _object['first_name_ar'] not  in [None, "", ''] or 
                                                                _object['first_name_en'] not in [None, "",''] or 
                                                                _object['last_name_en']  not in [None, "", ''] or
                                                                _object['last_name_ar']  not in [None, "", ''] ):
                            
                            phonetics_should_list.append(match)
                        elif key.lower()not in ['full_name_ar','full_name_en']:
                            phonetics_must_list.append(match)

            elif index =="nationalities":
                if  _object !={} and _object !=[] :
                    if len (_object)==1:
                            for key, value in _object[0].items():
                                if value =="" or value ==None:
                                    continue 
                                # Deterministic Fields
                                term={"match":dict()}  
                                term['match'][key]={ 'query':value, "operator":"and" } 
                                deterministic_must_list.append(term)
                    else:
                        for obj in _object:
                            for key, value in obj.items():
                                    if value =="":
                                        continue 
                                    # Deterministic Fields
                                    term={"match":dict()}  
                                    term['match'][key]={ 'query':value, "operator":"and" } 
                                    deterministic_should_list.append(term)

        must=phonetics_must_list + deterministic_must_list 
        if must !=[]:          
            query['query']['bool']['must'].append( {"bool":{"must":must }})
        should=phonetics_should_list + deterministic_should_list
        if should !=[]:
            query['query']['bool']['should'].append( {"bool":{"should":should }})
        if deterministic_must_not_list !=[]:
            query['query']['bool']['must_not']=deterministic_must_not_list 
        return query 

    ########################################################################################################
    ######################################### Search Endpoint ##############################################
    ########################################################################################################

    def collect_nationalities_data(self, obj_keys) -> list:
        
        """This function will get all data related to result object form nationalities index"""
        index, obj_data="nationalities",  list()
        keys, _source=self.select_keys_and_source_for_index_settings(index,obj_keys)
        query=self.generate_query_for_search ( 
                                    index=index, 
                                    _object=None, 
                                    parameters=keys, 
                                    _source=_source,
                                    size=10)
        result_index =self.es.search(index=config.NATIONALITIES_INDEX, body=query)
        if len (result_index["hits"]["hits"])> 0:
            for obj_result in result_index["hits"]["hits"]:
                obj_data.append(obj_result['_source'])
        return obj_data

    def collect_parties_country_data(self, obj_keys)-> dict:

        """This function will get all data related to result object form parties country index"""
        index, obj_data ="parties_country", dict()
        keys, _source=self.select_keys_and_source_for_index_settings(index,obj_keys)
        query=self.generate_query_for_search (
                                            index=config.PARTIES_COUNTRY_INDEX, 
                                            _object=None, 
                                            parameters=keys, 
                                            _source=_source,
                                            size=1
                                            )
        result_index =self.es.search(index=config.PARTIES_COUNTRY_INDEX, body=query)
        if result_index["hits"]["hits"] !=[]:
            obj_data=result_index["hits"]["hits"][0]['_source']                 
        return obj_data

    def collect_objects_data(self, results, source_obj)-> list:
        
        """ This function will collect all data related the object silver with source object."""
        data=list()
        for result_obj in results["hits"]["hits"]:
            # Collect Name Data and Keys 
            if "keys" in source_obj.keys():
                if result_obj['_source']['party_id'].lower().strip()==source_obj['keys']['party_id'].lower().strip():
                    continue
            obj_keys, obj_data=self.Select_Keys_name_data_for_result_object(result_obj['_source'])
            # Collect Parties Data and Check party id is deleted or searchable.
            parties_data=self.get_parties_data(obj_keys["party_id"],party_type=self.system_type)
            if not parties_data["status"]:continue
            obj_data["parties" ]=parties_data["data"]
            # Collect Parties Country Data
            obj_data["parties_country" ]=self.collect_parties_country_data(obj_keys)
            # Collect Nationalities Data
            obj_data["nationalities" ]=self.collect_nationalities_data(obj_keys)
            data.append({"keys":obj_keys,"object":obj_data})
        return data
         
    def Search_by_keys (
                        self, 
                        parameters:dict, 
                        size=None, 
                        _sort=None, 
                        pre_processing=True, 
                        init_country:str='jo')-> tuple:
        
        """This Main Function For individuals Search, will return source object with results similar source object."""
        # Step 4.1.1:Get Source Object by party ID 
        output, status_code=self.get_source_data_based_on_parameters(self.get_primary_keys(parameters))
        if output["status"]:

            if output["data"]["object"]["names"]["party_type"]  == "individuals":
                source_object=output["data"]
            else:
                content ={'detail':'The keys associated with corporate data, kindly utilize the designated corporate endpoints.'}
                self.obj_log_system.logger.warning(content["detail"],extra={"path":self.path,"endpoint":self.endpoint})           
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=content["detail"])
        else:
            del output["status"]
            return output, status_code
        # Find objects similar to the source object
        results=self.search_individuals_names(
                                index_name=config.NAMES_INDEX,
                                source_object=source_object,
                                parameters=parameters,
                                size=size,
                                _sort=_sort
                            )
        # Step 4.1.3 and 4.2:Collect Data related objects similar and Restructure Similar Objects
        output=self.collect_objects_data(results, source_object)
        # Step 5:Phonetics Operations
        data=list()
        for similar_object in output:
            self.obj_phonetics= self.get_phonetics_obj()
            similar_object_with_weights=self.obj_phonetics.individual_search_func_check_similarity(
                                                                source_object=source_object,  
                                                                similar_object=similar_object, 
                                                                pre_processing=pre_processing)
            
            if similar_object_with_weights['over_all_ratio'] >=config.OVERALL_THRESHOLD:
                similar_object["data_with_weights"]=similar_object_with_weights
                data.append (similar_object)
        # Step 6:Prepare Results
        data=self.prepare_results(data, source_object)
        return data

    def Search_by_object (
                        self, 
                        source_obj:dict, 
                        parameters:dict, 
                        size=None, 
                        _sort=None, 
                        pre_processing=True, 
                        init_country='jo')-> tuple:
        
        """ This Main Function For individuals Search, will return source object with results similar source object."""
        # Step 4.1.2:Find objects similar to the source object
        source_object={"object":source_obj, "keys":{"source_country":parameters["source_country"]}}

        results=self.search_individuals_names(
                                index_name=config.NAMES_INDEX,
                                source_object=source_object,
                                parameters=parameters,
                                size=size,
                                _sort=_sort
                            )

        # Step 4.1.3 and 4.2:Collect Data related objects similar and Restructure Similar Objects
        output=self.collect_objects_data(results, source_obj)
        # Step 5:Phonetics Operations
        data=list()
        for similar_object in output:
            self.obj_phonetics= self.get_phonetics_obj()
            similar_object_with_weights=self.obj_phonetics.individual_search_func_check_similarity(
                                                                source_object=source_object,  
                                                                similar_object=similar_object, 
                                                                pre_processing=pre_processing)
            
            if similar_object_with_weights['over_all_ratio'] >=config.OVERALL_THRESHOLD:
                similar_object["data_with_weights"]=similar_object_with_weights
                data.append (similar_object)
        # Step 6:Prepare Results
        data=self.prepare_results(data, source_obj)
        return data

    ########################################################################################################
    ############################################ Add Endpoint ##############################################
    ########################################################################################################

    def Add (self, objects:dict):
        
        # Keys and Parties Data
        keys=self.prepare_keys(objects)
        parties_data=self.prepare_parties_data(objects=objects, party_type="individuals")
        if self.check_keys_is_found(index="names", keys=keys):
            res={"status":False, "detail":"Keys is exist" }
            return res 
        #Names 
        names_data=self.prepare_names_data(objects)

        ## Nationalities
        index="nationalities"
        fields=self.settings_file[self.settings_file['index']==config.NATIONALITIES_INDEX]
        list_of_nationalities=list()
        if objects[index] not in [{},[], None,"" ] and type (objects[index])==list:
            for obj in objects[index]:
                nationalities_data=dict()
                for index_row, row in fields.iterrows():
                    if row['keys'] ==True:
                        if row['field'] in objects.keys():
                            nationalities_data[row['field']]=objects[row['field']]
                        else:
                            res={"status":False,"detail":"index {}:{} key is required.".format(index,row['field'])}
                            return res
                    else:
                        if row['field'] in obj.keys():
                            nationalities_data[row['field']]=obj[row['field']]
                            if nationalities_data[row['field']] ==None:
                                nationalities_data[row['field']]=""
                            elif type(nationalities_data[row['field']])==str:
                                nationalities_data[row['field']]=nationalities_data[row['field']].strip()
                list_of_nationalities.append(nationalities_data)

        ## Parties Country
        index="parties_country"
        fields=self.settings_file[self.settings_file['index']==config.PARTIES_COUNTRY_INDEX]
        if objects[index] not in [ {},"", None, [] ] :
            parties_country_data=dict()
            for index_row, row in fields.iterrows():

                if row['keys'] ==True:
                    if row['field'] in objects.keys():
                        parties_country_data[row['field']]=objects[row['field']]
                    else:
                        res={ 'status':False, "detail":"index {}:{} key is required.".format(index,row['field'])}
                        return res
                else:
                    if row['field'] in objects[index].keys():
                        parties_country_data[row['field']]=objects[index][row['field']]
                        if parties_country_data[row['field']] ==None:
                                parties_country_data[row['field']]=""
                        elif type(parties_country_data[row['field']])==str:
                            parties_country_data[row['field']]=parties_country_data[row['field']].strip()

        # Add Data to DataBase
        if parties_data not in [ None, {}, [] ]:
            self.add_row(index=config.PARTIES_INDEX,_object=parties_data)

        if list_of_nationalities not in [None, {}, [] ]:
            for obj_nationalities in list_of_nationalities:
                self.add_row(index=config.NATIONALITIES_INDEX,_object=obj_nationalities)

        if names_data not in [None, {}, [] ]:
            self.add_row(index=config.NAMES_INDEX,_object=names_data)

        if parties_country_data not in [None, {}, [] ]:
            self.add_row(index=config.PARTIES_COUNTRY_INDEX,_object=parties_country_data)

        res={ 'status':True, "detail":"Objects added successfully" }
        return res

    ########################################################################################################
    ######################################### Update Endpoint ##############################################
    ########################################################################################################

    def Update (self,objects:dict):
        
        ## Parties 
        parties_data =dict()
        index="parties"
        parties_data['party_id']=objects['party_id']
        parties_data['party_type']="individuals"
        parties_data['is_searchable']=objects['is_searchable']
        parties_data['is_deleted']=objects['is_deleted']
        parties_keys={'party_id':objects['party_id'] }

        keys=dict()
        keys['party_id']=objects['party_id']
        keys['organization']=objects['organization']
        keys['role']=objects['role']
        keys['source_country']=objects['source_country']
        keys['sequence']=objects['sequence']

        if not self.check_keys_is_found(index="names", keys=keys):
            res=self.Add(objects)
            return res 

        ## Names 
        index="names"
        fields=self.settings_file[self.settings_file['index']==config.NAMES_INDEX]
        names_data=dict()
        names_keys=dict()
        if objects[index] !={} :
            for index_row, row in fields.iterrows():
                if row['keys'] ==True:
                    if row['field'] in objects.keys():
                        names_data[row['field']]=objects[row['field']]
                        names_keys[row['field']]=objects[row['field']]
                    else:
                        res={'status':False, "detail":"index {}:{} key is required.".format(index,row['field'])}
                        return res
                else:
                    if row['field'] in objects[index].keys():
                        names_data[row['field']]=objects[index][row['field']]
                        if names_data[row['field']] ==None:
                            names_data[row['field']]=""
                        elif type(names_data[row['field']])==str:
                            names_data[row['field']]=names_data[row['field']].strip()
        ## Nationalities
        index="nationalities"
        fields=self.settings_file[self.settings_file['index']==config.NATIONALITIES_INDEX]
        if objects[index] !={}:
            list_of_nationalities=list()
            for obj in objects[index]:

                nationalities_data=dict()
                nationalities_keys=dict()

                for index_row, row in fields.iterrows():

                    if row['keys'] ==True:
                        if row['field'] in objects.keys():
                            nationalities_data[row['field']]=objects[row['field']]
                            nationalities_keys[row['field']]=objects[row['field']]
                        else:
                            res={ 'status':False, "detail":"index {}:{} key is required.".format(index,row['field'])}
                            return res
                    else:
                        if row['field'] in obj.keys():
                            nationalities_data[row['field']]=obj[row['field']]
                            if nationalities_data[row['field']] ==None:
                                nationalities_data[row['field']]=""
                            elif type(nationalities_data[row['field']])==str:
                                nationalities_data[row['field']]=nationalities_data[row['field']].strip()

                list_of_nationalities.append((nationalities_keys,nationalities_data))

        ## Parties Country
        index="parties_country"
        fields=self.settings_file[self.settings_file['index']==config.PARTIES_COUNTRY_INDEX]
        parties_country_data=dict()
        parties_country_keys=dict()
        if objects[index] not in [{}, "", None ] :
            for index_row, row in fields.iterrows():
                if row['keys'] ==True:
                    if row['field'] in objects.keys():
                        parties_country_data[row['field']]=objects[row['field']]
                        parties_country_keys [row['field']]=objects[row['field']]
                    else:
                        res={ 'status':False, "detail":"index {}:{} key is required.".format(index,row['field'])}
                        return res
                else:
                    if row['field'] in objects[index].keys():
                        parties_country_data[row['field']]=objects[index][row['field']]

                        if parties_country_data[row['field']] ==None:
                            parties_country_data[row['field']]=""
                        elif type(parties_country_data[row['field']])==str:
                            parties_country_data[row['field']]=parties_country_data[row['field']].strip()

        # Add Data to DataBase 
        if parties_data !=dict():
            index="parties"
            self.update_row(index=index,_object=parties_data, keys=parties_keys )
        else:
            res={'status':False,"detail":"please add parties data." }
            return res

        if list_of_nationalities !=list():

            index="nationalities"
            for nationalities_keys, obj_nationalities in list_of_nationalities:
                query =self.generate_query ( index=index, fields=nationalities_keys, size=1000  )
                result_index =self.es.search(index=config.NATIONALITIES_INDEX, body=query)
                if len (result_index["hits"]["hits"])> 0:
                    for obj_result in result_index["hits"]["hits"]:
                        self.delete_row(index=index, Id=obj_result['_id'])
                obj_nationalities.update(nationalities_keys)
                self.add_row(index=index,_object=obj_nationalities)
                #self.update_row(index="nationalities",_object=obj_nationalities, keys=nationalities_keys)

        if names_data !=dict()and names_keys !=dict():
            self.update_row(index="names",_object=names_data, keys=names_keys)

        if parties_country_data !=dict()and parties_country_keys !=dict():
            self.update_row(index="parties_country",_object=parties_country_data, keys=parties_country_keys)

        res={'status':True,"detail":"Objects Updated successfully." }
        return res
