import re
import string 
from src.config import config
from src.utils.phonetics import similar, remove_ar_diacritics

class Phonetics ():
    
    def __init__(self, 
                 settings_file, 
                 normalize_file,
                 log_system, 
                 system_type, 
                 endpoint=""):

        self.settings_file=settings_file 
        self.system_type=system_type
        self.normalize_file=normalize_file
        self.obj_log_system=log_system
        self.endpoint=endpoint
        self.empty_values=[None, '', dict(), list(), " "]
        self.path=""
  
    ########################################################################################################
    ########################################## Phonetics Core  #############################################
    ########################################################################################################
      
    def normalize (self, text, language="en"):
        """ """
        normalize_file=self.normalize_file[self.normalize_file['language']==language]
        punctuation=string.punctuation 
        translator=str.maketrans('','',punctuation)
        text=text.translate(translator)

        for index, row in normalize_file.iterrows():
            text=re.sub(row['character'], row['replace_to'], text)
        text=re.sub(' ','', text)
        return text.lower().strip()
     
    def preprocessing_field(self, value, language, preprocessing):
     
        """ """      
        value=value.lower().strip()
        if preprocessing ==True:
            if language =="ar":
                value=remove_ar_diacritics(value)
                value=self.normalize(value, language=language)
        return value 
    
    def similarity_ratio_calculator (self, field_one:str, field_two:str, language='ar', preprocessing=True, field_name=None)->float:
        
        """ """
        field_one_after_per_processing=self.preprocessing_field(field_one, language=language, preprocessing=preprocessing)
        field_two_after_per_processing=self.preprocessing_field(field_two, language=language, preprocessing=preprocessing)
        
        if field_one_after_per_processing =="" or field_two_after_per_processing =="":
            score=0
        else:      
            score=similar(field_one, field_two)

        return score     
      
    def calculate_phonetic_similarity(self, field_one, field_two, language, preprocessing=True):
        
        """ """
        if field_one in [None, ""]  or field_two in [None,""]:
            return 0

        similarity_ratio=self.similarity_ratio_calculator(
                                                    field_one=field_one, 
                                                    field_two=field_two,
                                                    language =language,
                                                    preprocessing=preprocessing
                                                )
        return similarity_ratio
     
    def calculate_deterministic_similarity(self, field_one, field_two):

        if field_one ==field_two not in ["",None]:
            similarity_ratio=100 
        else:
            similarity_ratio=0
        return similarity_ratio
                          
    ########################################################################################################
    ############################################ Compare Core  #############################################
    ########################################################################################################

    def compare_select_type_of_weight(self, part_type):
        
        # The above code is a Python function that takes a parameter `part_type` and assigns a value to
        # the variable `weight_type` based on the value of `part_type`. If `part_type` is equal to
        # "individual", `weight_type` is assigned the value "local_weight". If `part_type` is equal to
        # "corporate", `weight_type` is assigned the value "cor_local_weight". The function then returns
        # the value of `weight_type`.
        if part_type=="individuals":
            weight_type="local_weight"
        elif part_type=="corporate":
            weight_type="cor_local_weight"
        return weight_type
   
    def calculate_overall_weight_for_search(self, source_object, results_similarity, weight_type)-> float:
        
        """ """
        func_name ="calculate_overall_weight_for_search"
        sum_of_wights, sum_of_ratios=0, 0 
        for index in  results_similarity.keys():
            settings=self.settings_file[self.settings_file['index']==config.INDEX_MAP[index]]
            if index in ['names','parties','parties_country']:
                for key, value in results_similarity[index].items():
                    if key in  source_object[index].keys(): 
                        key_info=settings[settings['field']==key]
                        if key_info.iloc[0,:]['weight_calculation'] and source_object[index][key] not in ["", '', ' ', None]:
                            field_wight=float(key_info.iloc[0,:][weight_type])
                            field_ratio=value['ratio'] * field_wight
                            sum_of_wights +=field_wight
                            sum_of_ratios +=field_ratio
                            info_print=f"Field:{key}, weight:{field_wight}, ratio:{field_ratio}"
                            self.obj_log_system.logger.debug(info_print, extra={"path":self.path, "endpoint":self.endpoint})
                        else:continue
            elif index=="nationalities":
                if results_similarity not in self.empty_values  and source_object[index] not in self.empty_values:
                    for nationality_object in results_similarity[index]:
                        for key, value in nationality_object.items():
                            key_info=settings[settings['field']==key]
                            if key_info.iloc[0,:]['weight_calculation']:
                                if  nationality_object['nationality']["value"].lower()!="jo" and key not in ["document_number", "document_type"]:
                                    field_wight=float(key_info.iloc[0,:][weight_type])
                                    field_ratio=value['ratio'] * field_wight
                                    sum_of_wights +=field_wight
                                    sum_of_ratios +=field_ratio
                                    info_print=f"Field:{key}, weight:{field_wight}, ratio:{field_ratio}"
                                    self.obj_log_system.logger.debug(info_print, extra={"path":self.path, "endpoint":self.endpoint})
                                else:continue
                            else:continue
                else:continue
            else:
                self.obj_log_system.logger.error(f"/{func_name} function",extra={"path":self.path,"endpoint":self.endpoint})
                
        
        if sum_of_ratios==0 or sum_of_wights==0:return 0 
        overall=round (sum_of_ratios/sum_of_wights, 1)
        info_print=f"Sum of wights:{sum_of_wights}, sum of ratios:{sum_of_ratios}, overall result:{overall}"
        self.obj_log_system.logger.info(info_print, extra={"path":self.path, "endpoint":self.endpoint})
        self.obj_log_system.logger.debug("=="*20, extra={"path":self.path, "endpoint":self.endpoint})
        return overall    
    
    def old_calculate_overall_weight_for_compare (self, result:dict,  weight_type='local_weight')-> float:

        count, total=0, 0 
        for index in  result.keys():
            settings=self.settings_file[self.settings_file['index']==config.INDEX_MAP[index]]
            for key, value in result[index].items():
                if  result[index][key]['object_one'] not in ['', ' ', None, ""]:
                    key_info=settings[settings['field']==key]
                    if key_info.iloc[0,:]['weight_calculation']:
                        
                        count +=float (key_info.iloc[0,:][weight_type])
                        total=total + value['ratio']  *  float (key_info.iloc[0,:][weight_type])
                        
                        info_print=f"Field:{key}, weight:{key_info.iloc[0,:][weight_type]}, ratio:{value['ratio']*float(key_info.iloc[0,:][weight_type])}" 
                        self.obj_log_system.logger.debug(info_print, extra={"path":self.path, "endpoint":self.endpoint})

        if total ==0 or count ==0:return 0 
        info_print=f"Sum of wights:{count}, sum of ratios:{total}" 
        total=round (total/ count, 1)
        if total > 100:
            total=100 

        info_print= info_print + f", Result:{total}" 
        self.obj_log_system.logger.info(info_print, extra={"path":self.path, "endpoint":self.endpoint})
        return total
    
    def calculate_overall_weight_for_compare(self, source_object, results_similarity, weight_type)-> float:
        
        """ """
        func_name ="calculate_overall_weight_for_compare"
        sum_of_wights, sum_of_ratios=0, 0 
        for index in  results_similarity.keys():
            settings=self.settings_file[self.settings_file['index'] ==config.INDEX_MAP[index]]
            for key, value in results_similarity[index].items():
                if key in  source_object[index].keys(): 
                    key_info=settings[settings['field']==key]
                    if key_info.iloc[0,:]['weight_calculation'] and source_object[index][key] not in ["", '', ' ', None]:
                        field_wight=float(key_info.iloc[0,:][weight_type])
                        field_ratio=value['ratio'] * field_wight
                        sum_of_wights +=field_wight
                        sum_of_ratios +=field_ratio
                        info_print=f"Field:{key}, weight:{field_wight}, ratio:{field_ratio}"
                        self.obj_log_system.logger.debug(info_print, extra={"path":self.path, "endpoint":self.endpoint})

                        results_similarity[index][key]["weight"]=field_wight
                        results_similarity[index][key]["field_ratio"]=field_ratio
                        results_similarity[index][key]["computed"]=True
                    else:
                        results_similarity[index][key]["computed"]=False

        
        if sum_of_ratios==0 or sum_of_wights==0:return 0 
        overall=round (sum_of_ratios/sum_of_wights, 1)

        info_print=f"Sum of wights:{sum_of_wights}, sum of ratios:{sum_of_ratios}, overall:{overall}"
        self.obj_log_system.logger.info(info_print, extra={"path":self.path, "endpoint":self.endpoint})
        self.obj_log_system.logger.debug("=="*20, extra={"path":self.path, "endpoint":self.endpoint})
        results_similarity['over_all_ratio'] = overall
        return results_similarity    
   
    def old_compare_similarity_for_two_object (self, object_one, object_two, pre_processing=True, party_type='individual')-> dict:
        
        obj_data=dict()
        for index, _object in object_one.items():
            obj_data[index]=dict()
            if index =="nationalities" and object_one[index]!=None and  object_one[index] !=[] :
                    object_one[index]=object_one[index][0]
                    object_two[index]=object_two[index][0]

            if object_one[index] in [ [], None, "",{} ] or object_two[index] in [ [], None, "",{} ]:
                continue 
            
            settings=self.settings_file[(self.settings_file['index']==config.INDEX_MAP[index])&(self.settings_file['keys']==False)]

            for  row_id, row in settings.iterrows():
                similarity_ratio=0 

                if row['field'] in object_one[index].keys()and row['field'] in object_two[index].keys():
                    

                    if object_one[index][row['field']] not in ["", None, [] ] or object_two[index][row['field']] not in ["", None, []]:
                        if row['search_type'] =="phonetics":

                            if  object_one[index][row['field']]  in ["", None, [] ]:
                                object_one[index][row['field']] =""

                            if  object_two[index][row['field']]  in ["", None, [] ]:
                                object_two[index][row['field']] =""

                            similarity_ratio=self.similarity_ratio_calculator(
                                                                field_one=object_one[index][row['field']], 
                                                                field_two=object_two[index][row['field']],
                                                                language=row['language'], 
                                                                pre_processing=pre_processing,
                                                                field_name=row['field']
                                                               )

                        elif row['search_type'] =="deterministic":
                            
                            if object_one[index][row['field']]  ==object_two[index][row['field']] :
                                similarity_ratio=100
                            else:
                                similarity_ratio=0
                if row['field'] in object_one[index] and  row['field'] in object_two[index]:
                    object_one_value=object_one[index][row['field']]
                    object_two_value=object_two[index][row['field']]
                    obj_data[index][row['field']]={
                    "object_one":object_one_value,
                    "object_two":object_two_value,
                    "ratio":similarity_ratio
                    }
                    info_print=f"object_one: {object_one_value}, object_two: {object_two_value}, ratio: {similarity_ratio}"
                    self.obj_log_system.logger.debug(info_print, extra={"path":self.path, "endpoint":self.endpoint})
        
        obj_data['over_all_ratio']=self.calculate_overall_weight_for_compare(result=obj_data)
        return obj_data

    def compare_similarity_for_two_object (self, source_object, similar_object, pre_processing=True, party_type='individual')-> dict:

        """ """
        results_similarity=dict()
        results_similarity["names"]=self.compare_calculate_similarity_between_objects("names",source_object, similar_object, pre_processing=pre_processing)
        results_similarity["parties_country"]=self.compare_calculate_similarity_between_objects("parties_country",source_object, similar_object, pre_processing=pre_processing)
        results_similarity["nationalities"]=self.compare_calculate_similarity_between_objects("nationalities",source_object, similar_object, pre_processing=pre_processing)
        weight_type=self.compare_select_type_of_weight(part_type=party_type)
        results_similarity=self.calculate_overall_weight_for_compare(
                                                                    results_similarity=results_similarity, 
                                                                    source_object=source_object, 
                                                                    weight_type=weight_type)
        #section_match_ratio=self.calculate_section_match_ratio(new_obj, section_match_ratio)
        #results_similarity["auto_marge"]=self.calculate_auto_marge(source_object, results_similarity)
        return results_similarity

    def compare_calculate_similarity_between_objects(self, index, source_object, similar_object, pre_processing=True):
        
        """" """
        results_similarity=dict()
        settings=self.settings_file[(self.settings_file['index'] ==config.INDEX_MAP[index])]
      
        for field in source_object[index].keys():
             
            if field in similar_object[index].keys():
                field_settings=settings[settings['field']==field]
                field_one_value=source_object[index][field].lower().strip()
                field_two_value=similar_object[index][field].lower().strip()
                if field_settings.iloc[0,:]['search_type']=="phonetics":
                    similarity_ratio=self.calculate_phonetic_similarity( 
                                                                        field_one=field_one_value,
                                                                        field_two=field_two_value,
                                                                        language=field_settings.iloc[0,:]['language'],
                                                                        preprocessing=pre_processing)
                else:
                    similarity_ratio=self.calculate_deterministic_similarity(
                                                                            field_one=field_one_value,
                                                                            field_two=field_two_value,)
                results_similarity[field]={
                    "object_one":source_object[index][field],
                    "object_two":similar_object[index][field],
                    "ratio":similarity_ratio}
            else:
                results_similarity[field]={
                    "object_one":source_object[index][field],
                    "object_two":"",
                    "ratio":0}
                
        return results_similarity
    
    def calculate_section_match_ratio (self, object, section_match_ratio):

        for index in ['names','parties_country','nationalities']:

            if index !="nationalities":
                if section_match_ratio[index]['index_wight'] !=0 and section_match_ratio[index]['index_count'] !=0:
                
                    ratio=section_match_ratio[index]['index_wight'] / section_match_ratio[index]['index_count']
                    object[index]['section_match_ratio']=round ( ratio, 1)
                else:
                    object[index]['section_match_ratio']=0 
            else:
                if section_match_ratio[index] not in [list(), dict(), None , '' ]:
                    for i in range(len(object[index])):
                        if section_match_ratio[index][i]['index_count'] ==0:
                            ratio=0 
                        elif  section_match_ratio[index][i]['index_count'] ==1 :
                            section_match_ratio[index][i]['index_count']=section_match_ratio[index][i]['index_count'] + 1 
                            ratio=section_match_ratio[index][i]['index_wight'] / section_match_ratio[index][i]['index_count'] 
                        else:
                            ratio=section_match_ratio[index][i]['index_wight'] / section_match_ratio[index][i]['index_count']
                
                        object[index][i]['section_match_ratio']= round ( ratio, 1)
                        #new_obj[index][i]['section_match_ratio_details']=section_match_ratio[index][i]
        return object
    
    #########################################################################################################
    ################################## Individuals and Corporate Search  ####################################
    #########################################################################################################
     
    def select_type_of_weight(self, source_country_similar_object, source_country_source_object, part_type):
        
        """ """
        
        if source_country_similar_object==source_country_source_object:
            
            if part_type=="individual":
                weight_type="local_weight"

            elif part_type=="corporate":
                weight_type="cor_local_weight"
        else:
            if part_type=="individual":
                weight_type="global_weight"
            elif part_type=="corporate":
                weight_type="cor_global_weight"
        return weight_type
            
    def calculate_overall_weight_for_search(self, source_object, results_similarity, weight_type)-> float:
        
        """ """
        func_name ="calculate_overall_weight_for_search"
        sum_of_wights, sum_of_ratios=0, 0 
        for index in  results_similarity.keys():
            settings=self.settings_file[self.settings_file['index']==config.INDEX_MAP[index]]
            if index in ['names','parties','parties_country']:
                for key, value in results_similarity[index].items():
                    if key in  source_object[index].keys(): 
                        key_info=settings[settings['field']==key]
                        if key_info.iloc[0,:]['weight_calculation'] and source_object[index][key] not in ["", '', ' ', None]:
                            field_wight=float(key_info.iloc[0,:][weight_type])
                            field_ratio=value['ratio'] * field_wight
                            sum_of_wights +=field_wight
                            sum_of_ratios +=field_ratio
                            info_print=f"Field:{key}, weight:{field_wight}, ratio:{field_ratio}"
                            self.obj_log_system.print_information(info_print)
                        else:continue
            elif index=="nationalities":
                if results_similarity not in self.empty_values  and source_object[index] not in self.empty_values:
                    for nationality_object in results_similarity[index]:
                        for key, value in nationality_object.items():
                            key_info=settings[settings['field']==key]
                            if key_info.iloc[0,:]['weight_calculation']:
                                if  nationality_object['nationality']["value"].lower()!="jo" and key not in ["document_number", "document_type"]:
                                    field_wight=float(key_info.iloc[0,:][weight_type])
                                    field_ratio=value['ratio'] * field_wight
                                    sum_of_wights +=field_wight
                                    sum_of_ratios +=field_ratio
                                    info_print=f"Field:{key}, weight:{field_wight}, ratio:{field_ratio}"
                                    self.obj_log_system.print_information(info_print)
                                else:continue
                            else:continue
                else:continue
            else:
                self.obj_log_system.logger.error(f"/{func_name} function",extra={"path":self.path,"endpoint":self.endpoint})
                
        info_print=f"Sum of wights:{sum_of_wights}, sum of ratios:{sum_of_ratios}"
        self.obj_log_system.print_information(info_print)
        if sum_of_ratios==0 or sum_of_wights==0:return 0 
        overall=round (sum_of_ratios/sum_of_wights, 1)
        self.obj_log_system.print_information(f"overall result:{overall}")
        self.obj_log_system.print_information("=="*20)
        return overall   
   
    def calculate_similarity_names_objects(self, source_object, similar_object, preprocessing=True):
        
        """" """
        index, results_similarity="names", dict()
        settings=self.settings_file[(self.settings_file['index']==config.NAMES_INDEX)]

        for key, value in similar_object[index].items():
             
            if key in source_object[index].keys():
                field_settings=settings[settings['field']==key]
                field_one=source_object[index][key].lower().strip()
                field_two=similar_object[index][key].lower().strip()  
                
                if field_settings.iloc[0,:]['search_type']=="phonetics":
                        
                    similarity_ratio=self.calculate_phonetic_similarity( 
                                                                        field_one=field_one,
                                                                        field_two=field_two,
                                                                        language=field_settings.iloc[0,:]['language'],
                                                                        preprocessing=preprocessing
                                                                       )
                else:
                    similarity_ratio=self.calculate_deterministic_similarity(
                                                                            field_one=field_one,
                                                                            field_two=field_two
                                                                        )
                results_similarity[key]={"value":value, "ratio":similarity_ratio}
            else:
                results_similarity[key]={"value":value, "ratio":0}
                
        return results_similarity
                                
    def calculate_similarity_parties_country_objects(self, source_object, similar_object, preprocessing=True):
        
        """" """
        index, results_similarity="parties_country", dict()
        settings=self.settings_file[(self.settings_file['index']==config.PARTIES_COUNTRY_INDEX)]

        for key, value in similar_object[index].items():

            if key in source_object[index].keys():
                field_settings=settings[settings['field']==key]
                field_one=source_object[index][key].lower().strip()
                field_two=similar_object[index][key].lower().strip()  
                
                if field_settings.iloc[0,:]['search_type']=="phonetics":
                    similarity_ratio=self.calculate_phonetic_similarity( 
                                                                        field_one=field_one,
                                                                        field_two=field_two,
                                                                        language=field_settings.iloc[0,:]['language'],
                                                                        preprocessing=preprocessing)
                else:
                    similarity_ratio=self.calculate_deterministic_similarity(
                                                                            field_one=field_one,
                                                                            field_two=field_two
                                                                        )
                results_similarity[key]={"value":value, "ratio":similarity_ratio}
            else:
                results_similarity[key]={"value":value, "ratio":0}
        return results_similarity
                 
    def calculate_similarity_nationalities_objects(self, source_object, similar_object, preprocessing=True):
        
        """" """
        index, results_similarity="nationalities", list()
        settings=self.settings_file[(self.settings_file['index']==config.NATIONALITIES_INDEX)]

        if source_object[index] in [list(), dict(), None]:
            
            for obj in similar_object[index]:
                nationality_similar_object =dict()
                for key, value in obj.items():
                    nationality_similar_object[key]={"value":value, "ratio":-4}
                results_similarity.append(nationality_similar_object)
                
        elif len (source_object[index])>=1 and len(similar_object[index])>=1:
            
            for similar_object_nationality in similar_object[index]:
                for source_object_nationality in source_object[index]:
                    similar_obj_nat=dict()
                    
                    if similar_object_nationality['nationality']==source_object_nationality['nationality'] and source_object_nationality['nationality'] !="":
                        for key, value in similar_object_nationality.items():                       
                            if key in source_object_nationality.keys():
                                if source_object_nationality[key] ==value and value !="":
                                    similarity_ratio=100
                                else:similarity_ratio=0
                            else:similarity_ratio=0
                            similar_obj_nat[key]={"value":value, "ratio":similarity_ratio  }
                    else:
                        continue
                    
                    if bool(similar_obj_nat):
                        results_similarity.append(similar_obj_nat)
        return results_similarity
    
        # Auto Marge for Search 
    
    def calculate_auto_marge (self, source_object, similar_object):
        
        if similar_object["over_all_ratio"] >=config.AUTO_MARGE_OVERALL_THRESHOLD:
            if source_object["keys"]["role"]==similar_object["keys"]["role"]:
                if source_object["object"]["nationalities"] not in self.empty_values and similar_object["nationalities"] not in self.empty_values:
                    for sim_nationality in similar_object["nationalities"]:
                        for field in ["document_number","national_number","document_type"]:
                            if field in sim_nationality.keys():
                                if sim_nationality[field] in self.empty_values:
                                    return False
                                elif sim_nationality[field]["ratio"] !=100:
                                    return False
                                else:pass
                            else:return False
                else:return False
                
                if similar_object["parties_country"] in self.empty_values:
                    for field in ["country_of_origin","date_of_birth"]:
                        if field in similar_object["parties_country"].keys():
                            if similar_object["parties_country"][field] in self.empty_values:
                                return False 
                            else:
                                if similar_object["parties_country"][field]["ratio"] !=100:
                                    return False
                                else:pass
                        else:return False
                return True
            else:return False
        else:return False
        
    def individual_search_func_check_similarity(self, source_object, similar_object, pre_processing=True):
        
        """ """
        results_similarity=dict()
        results_similarity["names"]=self.calculate_similarity_names_objects(source_object["object"], similar_object["object"])
        results_similarity["parties_country"]=self.calculate_similarity_parties_country_objects(source_object["object"], similar_object["object"])
        results_similarity["nationalities"]=self.calculate_similarity_nationalities_objects(source_object["object"], similar_object["object"])
        weight_type=self.select_type_of_weight(similar_object["keys"]["source_country"], source_object["keys"]["source_country"], part_type="individual")
        results_similarity['over_all_ratio']=self.calculate_overall_weight_for_search(
                                                                                results_similarity=results_similarity, 
                                                                                source_object=source_object["object"], 
                                                                                weight_type=weight_type)
        #section_match_ratio=self.calculate_section_match_ratio(new_obj, section_match_ratio)
        results_similarity["keys"]=similar_object["keys"]
        if self.endpoint not in ["search_object", "individuals_object_search"]:
            results_similarity["auto_marge"]=self.calculate_auto_marge(source_object, results_similarity)
        else: 
            results_similarity["auto_marge"]= None
        return results_similarity
        
    def corporate_search_func_check_similarity(self, source_object, similar_object, pre_processing=True):
        
            """ """
            results_similarity=dict()
            results_similarity["names"]=self.calculate_similarity_names_objects(source_object["object"], similar_object["object"])
            results_similarity["parties_country"]=self.calculate_similarity_parties_country_objects(source_object["object"], similar_object["object"])
            results_similarity["nationalities"]=self.calculate_similarity_nationalities_objects(source_object["object"], similar_object["object"])
            weight_type=self.select_type_of_weight(similar_object["keys"]["source_country"], source_object["keys"]["source_country"], part_type="corporate")
            results_similarity['over_all_ratio']=self.calculate_overall_weight_for_search(
                                                                                    results_similarity=results_similarity, 
                                                                                    source_object=source_object["object"], 
                                                                                    weight_type=weight_type)
            
            #section_match_ratio=self.calculate_section_match_ratio(new_obj, section_match_ratio)
            results_similarity["keys"]=similar_object["keys"]
            results_similarity["auto_marge"]=self.calculate_auto_marge(source_object, results_similarity)
            return results_similarity
    
    ########################################################################################################
    ########################################################################################################
    ########################################################################################################