import jwt
from fastapi import Depends, HTTPException, status, Request, Header
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, ValidationError
from typing import Dict, Any
from src.schemas.base import MyHeader
from src.config import config

oauth2_scheme=OAuth2PasswordBearer(tokenUrl='/login', scheme_name="JWT")

# Fake token validation function
async def get_current_user(request:Request,token:str=Depends(oauth2_scheme)):
    
    credentials_exception=HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                            detail="Could not Validate Credentials",
                                            headers={"x-access-token":"bearer"})
    
    return verify_token(token)


def verify_token(token:str):   
    try:
        # Decode the JWT token
        payload=jwt.decode(token, config.ACCESS_SECRET_KEY, algorithms=[config.ALGORITHM])
        # Extract public_id from the payload
        public_id=payload.get("public_id")
        if public_id:
            return public_id
        else:
            raise HTTPException(status_code=401, detail="Invalid token:public_id not found")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


# Helper function to convert Pydantic models to dictionaries
def model_to_dict(obj:BaseModel)-> Dict[str, Any]:
    result=obj.__dict__
    for key, value in result.items():
        if isinstance(value, BaseModel):
            result[key]=model_to_dict(value)
            
        elif isinstance(value, list)and value and isinstance(value[0], BaseModel):
            result[key]=[model_to_dict(item)for item in value]
            
    return result


def common_header_dependency(
    Init_Country:str=Header(..., description="Init-Country"),
    Channel_Identifier:str=Header(..., description="Channel-Identifier"),
    Unique_Reference:str=Header(..., description="Unique-Reference"),
):
    try:
        headers=MyHeader(
            Init_Country=Init_Country,
            Channel_Identifier=Channel_Identifier,
            Unique_Reference=Unique_Reference,
        )
    except ValidationError as e: 
        errors={err["loc"][0]: err["msg"] for err in e.errors()}     
        raise HTTPException(status_code=400, detail=errors)
    return headers
    