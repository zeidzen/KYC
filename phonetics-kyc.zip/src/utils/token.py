from typing import Union, Any
from jose import jwt # type: ignore
from jwt.exceptions import InvalidTokenError
from datetime import datetime, timedelta, timezone
from src.config import config

# create token
def create_access_token(subject: Union[str, Any]) -> str:
   expires_at = datetime.now(timezone.utc) + timedelta(
       minutes=config.ACCESS_TOKEN_EXPIRE_HOURS, 
       hours=config.REFRESH_TOKEN_EXPIRE_HOURS
       )
   to_encode = {"exp": expires_at, "sub": str(subject)}
   encoded_jwt = jwt.encode(to_encode, config.ACCESS_SECRET_KEY, algorithm=config.ALGORITHM)
   return encoded_jwt

# Refresh Token
def create_refresh_token(subject: Union[str, Any]) -> str:
   expires_delta = datetime.now(timezone.utc) + timedelta(
       minutes=config.REFRESH_TOKEN_EXPIRE_MINUTES , 
       hours=config.REFRESH_TOKEN_EXPIRE_HOURS
       )
   to_encode = {"exp": expires_delta, "sub": str(subject)}
   encoded_jwt = jwt.encode(to_encode, config.REFRESH_SECRET_KE, config.ALGORITHM)
   return encoded_jwt

# Decode JWT
def decode_jwt(token:str, token_type:str = "access"):
   try:
       if token_type == "access":
           payload = jwt.decode(token, config.ACCESS_SECRET_KEY, config.ALGORITHM)
       elif token_type == "refresh":
           payload = jwt.decode(token, config.REFRESH_SECRET_KE, config.ALGORITHM)
       else:
           return None
       return payload
   except InvalidTokenError:
       return None