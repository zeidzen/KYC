from passlib.context import CryptContext # type: ignore
import random
import string

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def secure_pwd(raw_password: str) -> str:
   return pwd_context.hash(raw_password)

def verify_pwd(plain: str, stored_hash: str) -> bool:
   return pwd_context.verify(plain, stored_hash)
