from difflib import SequenceMatcher
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np 
import re 

def cosine_similarity_score (word_one, word_two):
    """ """
    v1=list (''.join(format(ord(i), '08b')for i in word_one))
    v1=np.array([int (i)for i in v1])
    v2=list (''.join(format(ord(i), '08b')for i in word_two))
    v2=np.array([int (i)for i in v2])
    score=cosine_similarity([v1], [v2])[0][0] *100 

    if score > 78 and score < 87 :
        score=score + 7 
    elif score <=71 and score > 65:
            score=score - 5 
    return int (score)

def similar(string_one, string_two):
    
    score=SequenceMatcher(None, string_one, string_two,).ratio()
    if  score <=0.40: score=0
    elif score <=0.60:score=score - 0.30

    if score < 0.15:score=0 
    score=score * 100 
    
    len_v=abs(len(string_one)- len(string_two))
    if len_v >=3 and score > 88:
        score=score - len_v * 6 

    if score > 99  and len(string_one)==len(string_two):
        score=cosine_similarity_score(string_one, string_two)

    if score >=99:
        score=100 

    score=round(score, 0)
    if score > 100:
        score=100
    return score 

def remove_ar_diacritics(text):

    arabic_diacritics=re.compile("""
                                ّ    | # Tashdid
                                َ    | # Fatha
                                ً    | # Tanwin Fath
                                ُ    | # Damma
                                ٌ    | # Tanwin Damm
                                ِ    | # Kasra
                                ٍ    | # Tanwin Kasr
                                ْ    | # Sukun
                                ـ     # Tatwil/Kashida
                            """, re.VERBOSE
                        )

    text=re.sub(arabic_diacritics, '', text)
    return text