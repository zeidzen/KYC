import pytest
from fastapi.testclient import TestClient
from main import app
from .mock_data import mock_user

client = TestClient(app)

@pytest.fixture
def setup_user():
   """Setup a user for testing."""
   client.post("/signup", json=mock_user)
def test_signup_success():
   """Test successful signup."""
   response = client.post("/signup", json={
       "username": "newuser",
       "email": "newuser@example.com",
       "password": "newpassword"
   })
   assert response.status_code == 201
   assert response.json() == {"message": "User created successfully"}

def test_signup_existing_user(setup_user):
   """Test signup with an existing username."""
   response = client.post("/signup", json=mock_user)
   assert response.status_code == 400
   assert response.json() == {"detail": "Username already exists"}
def test_login_success(setup_user):
   """Test successful login."""
   response = client.post("/login", json={
       "username": mock_user["username"],
       "password": mock_user["password"]
   })
   assert response.status_code == 200
   assert response.json() == {"message": "Login successful"}
def test_login_invalid_credentials():
   """Test login with invalid credentials."""
   response = client.post("/login", json={
       "username": "wronguser",
       "password": "wrongpassword"
   })
   assert response.status_code == 400
   assert response.json() == {"detail": "Invalid credentials"}
def test_get_users(setup_user):
   """Test retrieving users."""
   response = client.get("/users")
   assert response.status_code == 200
   assert mock_user["username"] in response.json()
def test_change_password_success(setup_user):
   """Test changing the password successfully."""
   response = client.post("/change-password", json={
       "username": mock_user["username"],
       "old_password": mock_user["password"],
       "new_password": "newpassword"
   })
   assert response.status_code == 200
   assert response.json() == {"message": "Password changed successfully"}
   # Verify login with new password
   login_response = client.post("/login", json={
       "username": mock_user["username"],
       "password": "newpassword"
   })
   assert login_response.status_code == 200
def test_change_password_invalid_old_password(setup_user):
   """Test changing password with an invalid old password."""
   response = client.post("/change-password", json={
       "username": mock_user["username"],
       "old_password": "wrongpassword",
       "new_password": "newpassword"
   })
   assert response.status_code == 400
   assert response.json() == {"detail": "Invalid old password"}