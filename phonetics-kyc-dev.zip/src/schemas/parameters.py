from pydantic import BaseModel, Field, field_validator
from typing import Optional

# Main Keys
class MainKeys(BaseModel):
    party_id:str
    role:str
    sequence:int
    source_country:str
    organization:str   


# Update Parameters
class individualUpdateParameters(BaseModel):
    party_id:Optional[str]=None
    role:str
    sequence:int
    source_country:str
    organization:str
    is_searchable:bool
    is_deleted:bool

    @classmethod
    def convert_yes_no_to_bool(cls, data:dict):
        return cls(**{
            "is_searchable", True if data["is_searchable"].lower() =="y" else False,
            "is_deleted", True if data["is_deleted"].lower() =="y" else False,
                })
    
class IndividualCompareParameters(BaseModel):
    pre_processing:bool

## Search V1 Version 
class V1_search_parameters(BaseModel):
    party_id:Optional[str] = Field(..., error_msg="Party ID")
    role:Optional[str] 
    sequence:Optional[int]
    source_country:Optional[str]
    organization:Optional[str]
    size:int = Field(..., error_msg="Size")
    pre_processing:bool
    party_id_not_in:list[str]


    @field_validator("party_id" ,"role", "sequence", "source_country", "organization", mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == "":
            return None
        return value
    
## Search by object
class SearchByObjectParameters(BaseModel):
    source_country:str
    size:int
    pre_processing:bool
    party_id_not_in:list[str]

# ------------------------------------------------------- #

class CorporateUpdateParameters(BaseModel):
    party_id:Optional[str]=None
    organization:str
    role:str
    source_country:str
    sequence:int
    is_searchable:bool 
    is_deleted:bool
    company_type:str
    
    @classmethod
    def convert_yes_no_to_bool(cls, data:dict):
        return cls(**{
            "is_searchable", True if data["is_searchable"].lower() =="y" else False,
            "is_deleted", True if data["is_deleted"].lower() =="y" else False,
            }
        )
    
class CompareCompareParameters(BaseModel):
    pre_processing:bool
