from .base_schema import DefaultResponse, MyHeader
from .authentication_schema import Signup, Login, LoginResponse
from .user_schema import User, UsersResponse, ChangePassword
from .individual_schema import (
                        CreateIndividual, 
                        UpdateIndividual, 
                        Individual,
                        CompareIndividual,
                        SearchByKeysIndividual,
                        SearchByObjectIndividual,
                        IndividualV1Search,
                        
                        IndividualSearchResponse
                    )

from src.schemas.corporate_schema import (

                        CreateCorporate,
                        UpdateCorporate,
                        CorporateCompare,
                        CorporateSearchByKeys,
                        CorporateSearchByObjects,

                        CorporateSearchResponse,
                        CorporateCompareResponse
                        )
# from src.schemas.corporate_schema import (
#                             CorporateAdd,
#                             CorporateUpdate, 
#                             CorporateSearchByKeys, 
#                             CorporateCompare,
#                             CorporateCompareResponse,
#                             CorporateSearchByKeysByObjects,
#                             SearchResponse
#                         )