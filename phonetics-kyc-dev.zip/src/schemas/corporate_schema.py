from typing import List
from pydantic import BaseModel, Field, field_validator  
from src.schemas.names import (
                        CorporateName, 
                        CorporateCompareResultsName, 
                        CorporateSearchResultsName,
                        )
from src.schemas.nationalities import (
                        CorNationality, 
                        CorporateCompareResultsNationalities,
                        CorporateSearchResultsNationalities,
                    )
from src.schemas.parties_country import (
                            CorporatePartiesCountry, 
                            CorporateCompareResultsPartiesCountry,
                            CorporateSearchResultsPartiesCountry
                        )
from .parameters import SearchByObjectParameters, CorporateUpdateParameters, CompareCompareParameters



# -------------------- Base --------------------    
class CorporateKeys(BaseModel):
    party_id:str
    organization:str
    role:str
    source_country:str
    sequence:int
    company_type:str


class CorporateObject(BaseModel):
    names:CorporateName
    nationalities:List[CorNationality]
    parties_country:CorporatePartiesCountry


# -------------- ADD and Update -------------- #    
    
class CreateCorporate(BaseModel):
    parameters:CorporateKeys
    object:CorporateObject

class UpdateCorporate(BaseModel):
    parameters:CorporateUpdateParameters
    object:CorporateObject


# -------------------- Search --------------------    

class CorporateSearchByKeys(BaseModel):
    party_id:str
    organization:str
    role:str
    source_country:str
    sequence:int
    pre_processing:bool
    size:int
    party_id_not_in:List[str]
        
class CorporateSearchByObjects(BaseModel):
    parameters:SearchByObjectParameters
    object: CorporateObject

## Response 
class SearchResObject(BaseModel):
    names:CorporateSearchResultsName
    parties_country:CorporateSearchResultsPartiesCountry
    nationalities:CorporateSearchResultsNationalities

class SearchResultsObject(BaseModel):
    keys:CorporateKeys
    objects:SearchResObject

class CorporateSearchResponse(BaseModel):
    source:CorporateObject
    result_search:List[SearchResultsObject]

# -------------------- Compare --------------------    

class CorporateCompareObject(BaseModel):
    names:CorporateName
    nationalities:CorNationality
    parties_country:CorporatePartiesCountry

# Compare Request
class CorporateCompare(BaseModel):
    parameters:CompareCompareParameters
    object_one:CorporateCompareObject
    object_two:CorporateCompareObject
    
class CorporateCompareResponse(BaseModel):
    names:CorporateCompareResultsName
    nationalities:CorporateCompareResultsNationalities
    parties_country:CorporateCompareResultsPartiesCountry
    over_all_ratio:float
    
         




    
