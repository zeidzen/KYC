from pydantic import BaseModel, Field, field_validator
from .base_schema import ResultCompareField, ResultsSearchField
from typing import Optional



# ------------- Individuals ------------- #

# Parties country object
class IndividualPartiesCountry(BaseModel):
    date_of_birth: Optional[str]  # Assuming this is stored as a string in the schema
    place_of_birth: Optional[str]
    country_of_origin: Optional[str]

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value


# Individual Response Search Parties Country Fields
class IndividualSearchResultsPartiesCountry(BaseModel):
    place_of_birth:ResultsSearchField
    date_of_birth:ResultsSearchField
    country_of_origin:ResultsSearchField


class IndividualCompareResultsPartiesCountry(BaseModel):
    place_of_birth:ResultCompareField
    date_of_birth:ResultCompareField
    country_of_origin:ResultCompareField

# ------------- Corporate ------------- #

# Corporate Parties Country Object
class CorporatePartiesCountry(BaseModel):
    country_of_origin:Optional[str] 
    registration_number:Optional[str] 
    tax_identification_number:Optional[str] 
    country_of_registration:Optional[str] 
    license_profession_number:Optional[str]  

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value
    
# Corporate Response Parties Country Fields     
class CorporateCompareResultsPartiesCountry(BaseModel):
    country_of_origin:ResultCompareField
    registration_number:ResultCompareField
    tax_identification_number:ResultCompareField
    license_profession_number:ResultCompareField
    country_of_registration:ResultCompareField

class CorporateSearchResultsPartiesCountry(BaseModel):
    country_of_origin:ResultsSearchField
    registration_number:ResultsSearchField
    tax_identification_number:ResultsSearchField
    license_profession_number:ResultsSearchField
    country_of_registration:ResultsSearchField




# Checksum
class ChecksumPartiesCountry(BaseModel):
    object:IndividualPartiesCountry
    checksum:str
    
class ChecksumPartiesCountryObject(BaseModel):
    objects:list[ChecksumPartiesCountry]
    checksum:str
     