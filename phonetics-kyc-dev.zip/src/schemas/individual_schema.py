from pydantic import BaseModel, Field, field_validator
from typing import Optional, List
from datetime import datetime

from .names import IndividualsName, IndividualsResultsCompareName, IndividualsResultsSearchNames
from .nationalities import IndividualNationality, IndividualCompResultsNationalityFields, IndividualResultsSearchNationality
from .parties_country import IndividualPartiesCountry, IndividualSearchResultsPartiesCountry, IndividualCompareResultsPartiesCountry
from .parameters import MainKeys, individualUpdateParameters, IndividualCompareParameters, V1_search_parameters, SearchByObjectParameters

# Define the main 'Object' containing all the nested objects
class Object(BaseModel):
    names: IndividualsName
    nationalities: List[IndividualNationality]
    parties_country: IndividualPartiesCountry

# Main Individuals model
class Individual(BaseModel):
    customer_id: Optional[str]
    party_id: str
    source_country: str
    role: str
    organization: str
    sequence: int
    is_searchable: Optional[bool]
    is_deleted: Optional[bool]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    name: Optional[IndividualsName] = None
    nationalities: Optional[List[IndividualNationality]] = None
    parties_country: Optional[IndividualPartiesCountry] = None

# -------------------- Add and Update --------------------
class CreateIndividual(BaseModel):
    parameters: MainKeys
    object: Object

class UpdateIndividual(BaseModel):
    parameters: individualUpdateParameters
    object: Object

# -------------------- Compare --------------------    
class IndividualCompareObject(BaseModel):
    names:IndividualsName
    nationalities:IndividualNationality
    parties_country:IndividualPartiesCountry

# Compare Request        
class CompareIndividual(BaseModel):
    parameters:IndividualCompareParameters
    object_one:IndividualCompareObject
    object_two:IndividualCompareObject

# Compare Response
class CompareResponseIndividual(BaseModel):
    names:IndividualsResultsCompareName
    nationalities:IndividualCompResultsNationalityFields
    parties_country:IndividualCompareResultsPartiesCountry
    over_all_ratio:float
    
# -------------------- Search --------------------
## Search by Keys
class SearchByKeysIndividual(BaseModel):
    party_id:str = Field(..., error_msg="Party ID")
    role:str 
    sequence:int
    source_country:str
    organization:str
    size:int = Field(..., error_msg="Size")
    pre_processing:bool
    party_id_not_in:list[str]


class IndividualV1Search(BaseModel):
    parameters:V1_search_parameters
    object:Object

        
class SearchByObjectIndividual(BaseModel):
    parameters:SearchByObjectParameters
    object:Object
    
# Search Response
class ResultsSearchObject(BaseModel):
    names:IndividualsResultsSearchNames
    parties_country:IndividualSearchResultsPartiesCountry
    nationalities:IndividualResultsSearchNationality
    over_all_ratio:float
    auto_marge:bool    

class ResultsSearch(BaseModel):
    keys:MainKeys
    object:ResultsSearchObject
    
class SourceObject(BaseModel):
    keys:MainKeys
    object:Object 

class IndividualSearchResponse(BaseModel):
    source:SourceObject
    result_search:list[ResultsSearch]
    
# ---------- Checksum Response ----------
class Checksum(BaseModel):
    party_id:str
    party_type:str
    is_searchable:bool
    is_deleted:str
    names:IndividualsName
    nationalities:IndividualNationality
    parties_country:IndividualPartiesCountry
    global_checksum:str
    
    @classmethod
    def convert_yes_no_to_bool(cls, data:dict):
        return cls(**{
            "is_searchable", True if data["is_searchable"].lower() =="y" else False,
            "is_deleted", True if data["is_deleted"].lower() =="y" else False,
                })
    
    
    def to_dict(self):
        return {
            "is_searchable": "y" if self.is_searchable else "n",
            "is_deleted": "y" if self.is_deleted else "n",
        }


