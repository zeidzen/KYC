from pydantic import BaseModel, Field, field_validator
from .base_schema import ResultCompareField, ResultsSearchField
from typing import Optional



# ------------- Individuals ------------- #
# Individual Nationality object
class IndividualNationality(BaseModel):
    nationality: Optional[str]
    national_number: Optional[str]
    document_type: Optional[str]
    document_number: Optional[str]

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value
    
# Individual Compare Response Nationality Fields  
class IndividualCompResultsNationalityFields(BaseModel):
    document_number:ResultCompareField
    document_type:ResultCompareField
    national_number:ResultCompareField
    nationality:ResultCompareField

# Individual Search Response Nationality Fields      
class IndividualResultsSearchNationality(BaseModel):
    document_number:ResultsSearchField
    document_type:ResultsSearchField
    national_number:ResultsSearchField
    nationality:ResultsSearchField
    
# Checksum    
class ChecksumNationality(BaseModel):
    object:IndividualNationality
    checksum:str
    
class ChecksumNationalitiesObject(BaseModel):
    objects:list[ChecksumNationality]
    checksum:str    
    
# Corporate Nationality Object     
class CorNationality(BaseModel):
    national_number:Optional[str] 
    nationality:Optional[str] 

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value

# Corporate Response Nationality Fields     
class CorporateCompareResultsNationalities(BaseModel):
    national_number:ResultCompareField
    nationality:ResultCompareField
    

class CorporateSearchResultsNationalities(BaseModel):
    national_number:ResultsSearchField
    nationality:ResultsSearchField