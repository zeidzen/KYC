from pydantic import BaseModel, Field, field_validator, EmailStr, ValidationError
from datetime import datetime
from typing import Optional


class User(BaseModel):

    user_id: str = Field(..., description="Unique identifier for the user")
    name: str = Field(..., min_length=2, description="Full name of the user")
    email: EmailStr = Field(..., min_length=5, description="User's email address")
    password: str = Field(..., min_length=8, description="User's password")
    is_admin: bool = Field(..., description="Indicates if the user has admin privileges")
    created_at: datetime = Field(..., description="Date when the user was created")
    updated_at: Optional[datetime] = Field(None, description="Date when the user was last updated")

    @field_validator('name')
    @classmethod
    def validate_name(cls, value: str) -> str:
        """Validate that the name is at least 2 characters long."""
        if len(value.strip()) < 2:
            raise ValueError("Name must be at least 2 characters long")
        return value.strip()

    @classmethod
    def validate_password(cls, value: str) -> str:
        """Validate the password for minimum requirements."""
        if len(value) < 8:
            raise ValueError("Password must be at least 8 characters long")
        if not any(char.isdigit() for char in value):
            raise ValueError("Password must contain at least one digit")
        if not any(char.isupper() for char in value):
            raise ValueError("Password must contain at least one uppercase letter")
        if not any(char.islower() for char in value):
            raise ValueError("Password must contain at least one lowercase letter")
        return value

    @field_validator('email')
    @classmethod
    def validate_email(cls, value: EmailStr) -> EmailStr:
        """Ensure email is a valid format (additional checks can be added if needed)."""
        return value.strip()


class ChangePassword(BaseModel):
    user_id: str
    password: str = Field(min_length=8, description="Password must be at least 8 characters long.")

    @field_validator('password')
    def validate_password(cls, value: str) -> str:
        """Validate the password against specific requirements."""
        if not any(char.isdigit() for char in value):
            raise ValueError("Password must contain at least one digit.")
        if not any(char.isupper() for char in value):
            raise ValueError("Password must contain at least one uppercase letter.")
        if not any(char.islower() for char in value):
            raise ValueError("Password must contain at least one lowercase letter.")
        if not any(char in "!@#$%^&*()-_=+[]{}|;:'\",.<>?/`~" for char in value):
            raise ValueError("Password must contain at least one special character.")
        return value


    
class UsersResponse (BaseModel):
    users:list[User]
    
