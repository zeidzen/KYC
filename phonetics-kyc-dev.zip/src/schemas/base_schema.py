from pydantic import BaseModel, Field

class MyHeader(BaseModel):
    Init_Country:str
    Channel_Identifier:str
    Unique_Reference:str
    Time_Stamp:str


class DefaultResponse(BaseModel):
    detail:str

class ResultCompareField(BaseModel):
    object_one:str
    object_two:str
    ratio:float
    weight:float
    field_ratio:float
    computed:bool
    
class ResultsSearchField(BaseModel):
    value:str
    ratio:int


    
