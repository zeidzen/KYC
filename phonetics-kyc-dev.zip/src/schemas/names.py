from pydantic import BaseModel, Field, field_validator
from .base_schema import ResultCompareField, ResultsSearchField
from typing import Optional


# ------------- Individuals ------------- #

class IndividualsName(BaseModel):
    first_name_ar:Optional[str] 
    first_name_en:Optional[str] 
    second_name_ar:Optional[str] 
    second_name_en:Optional[str] 
    third_name_ar:Optional[str] 
    third_name_en:Optional[str] 
    last_name_ar:Optional[str] 
    last_name_en:Optional[str] 
    full_name_ar:Optional[str] 
    full_name_en:Optional[str] 
    short_name_ar:Optional[str] 
    short_name_en:Optional[str] 
    mother_name_ar:Optional[str] 
    mother_name_en:Optional[str] 

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value
    
# ------------- Individuals Search ------------- #
# Individual Response Search Names Fields
class IndividualsResultsSearchNames(BaseModel):
    first_name_ar:ResultsSearchField
    first_name_en:ResultsSearchField
    second_name_ar:ResultsSearchField
    second_name_en:ResultsSearchField
    third_name_ar:ResultsSearchField
    third_name_en:ResultsSearchField
    last_name_ar:ResultsSearchField
    last_name_en:ResultsSearchField
    full_name_ar:ResultsSearchField
    full_name_en:ResultsSearchField
    short_name_ar:ResultsSearchField
    short_name_en:ResultsSearchField
    mother_name_ar:ResultsSearchField
    mother_name_en:ResultsSearchField

# ------------- Individuals Compare ------------- #
class IndividualsResultsCompareName(BaseModel):
    first_name_ar:ResultCompareField
    first_name_en:ResultCompareField 
    second_name_ar:ResultCompareField 
    second_name_en:ResultCompareField
    third_name_ar:ResultCompareField
    third_name_en:ResultCompareField
    last_name_ar:ResultCompareField
    last_name_en:ResultCompareField
    full_name_ar:ResultCompareField
    full_name_en:ResultCompareField
    short_name_ar:ResultCompareField
    short_name_en:ResultCompareField
    mother_name_ar:ResultCompareField
    mother_name_en:ResultCompareField

# ------------- Corporate ------------- #
class CorporateName(BaseModel):
    full_name_ar:Optional[str] 
    full_name_en:Optional[str] 
    commercial_name_ar:Optional[str] 
    commercial_name_en:Optional[str] 
    cor_full_name_en:Optional[str] 
    cor_full_name_ar:Optional[str] 
    short_name_ar:Optional[str] 
    short_name_en:Optional[str] 
    
    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value

# ------------- Corporate Search ------------- #
class CorporateSearchResultsName(BaseModel):
    commercial_name_ar:ResultsSearchField
    commercial_name_en:ResultsSearchField
    cor_full_name_ar:ResultsSearchField
    cor_full_name_en:ResultsSearchField
    full_name_ar:ResultsSearchField
    full_name_en:ResultsSearchField
    short_name_ar:ResultsSearchField
    short_name_en:ResultsSearchField

# ------------- Corporate Compare ------------- #

class CorporateCompareResultsName(BaseModel):
    commercial_name_ar:ResultCompareField
    commercial_name_en:ResultCompareField
    cor_full_name_ar:ResultCompareField
    cor_full_name_en:ResultCompareField
    full_name_ar:ResultCompareField
    full_name_en:ResultCompareField
    short_name_ar:ResultCompareField
    short_name_en:ResultCompareField


# ------------- CheckSum ------------- #

class ChecksumName(BaseModel):
    object:IndividualsName
    checksum:str

class ChecksumNameObject(BaseModel):
    objects:ChecksumName
    checksum:str
    
# Corporate Response Name Fields




