import logging
from logging.handlers import RotatingFileHandler
from typing import Optional
from src.config import config


class CustomFormatter(logging.Formatter):
   """
   Custom logging formatter that applies different colors based on log level.
   """
   log_format = config.LOG.APP_LOG_FORMAT
   grey = "\x1b[38;20m"
   yellow = "\x1b[33;20m"
   red = "\x1b[31;20m"
   bold_red = "\x1b[31;1m"
   reset = "\x1b[0m"
   FORMATS = {
       logging.DEBUG: grey + log_format + reset,
       logging.INFO: grey + log_format + reset,
       logging.WARNING: yellow + log_format + reset,
       logging.ERROR: red + log_format + reset,
       logging.CRITICAL: bold_red + log_format + reset
   }
   def format(self, record: logging.LogRecord) -> str:
       log_fmt = self.FORMATS.get(record.levelno, self.log_format)
       formatter = logging.Formatter(log_fmt)
       return formatter.format(record)
   
class DefaultLogFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "endpoint"):
            record.endpoint = "System"

        if not hasattr(record, "path"):
            record.path = "None"

        return True

class LogsService:
   """
   Service class to manage logging for an application with custom handlers and formatters.
   """
   _logger_instance = None
   @classmethod
   def get_logger(cls, endpoint: str = "") -> logging.Logger:
       if cls._logger_instance is None:
           cls._logger_instance = cls(endpoint).logger
       return cls._logger_instance
   
   def __init__(self, endpoint: str = "") -> None:
       if LogsService._logger_instance is not None:
           return
       self.log_format = config.LOG.APP_LOG_FORMAT
       self.log_level = config.LOG.APP_LOG_LEVEL
       self.log_loc = config.LOG.APP_LOG_LOCATION
       self.handlers = config.LOG.APP_HANDLERS or ['file', 'console']
       self.endpoint = endpoint
       # Create and configure the logger
       self.logger = logging.getLogger(config.APP_NAME)
       self.logger.setLevel(self.get_log_level(self.log_level))
       # Create and add handlers to the logger
       self.create_handlers()

   def has_handlers(self) -> bool:
       """ Check if the logger already has handlers. """
       return bool(self.logger.handlers)
   
   def create_handlers(self) -> None:
       """
       Create handlers for logging if they do not already exist.
       Adds file handler and/or console handler based on configuration.
       """
       if not self.has_handlers():
           # Create file handler with rotation
           if 'file' in self.handlers:
               app_file_handler = RotatingFileHandler(
                   self.log_loc,
                   maxBytes=config.LOG.MAX_BYTES,
                   backupCount=config.LOG.BACKUP_COUNT
               )
               app_file_handler.setLevel(self.get_log_level(self.log_level))
               app_file_handler.setFormatter(CustomFormatter())
               app_file_handler.addFilter(DefaultLogFilter())

               self.logger.addHandler(app_file_handler)


           # Create console handler with custom formatter
           if 'console' in self.handlers:
               console_handler = logging.StreamHandler()
               console_handler.setLevel(self.get_log_level(self.log_level))
               console_handler.setFormatter(CustomFormatter())
               console_handler.addFilter(DefaultLogFilter())
               self.logger.addHandler(console_handler)

   def get_log_level(self, level: Optional[str] = None) -> int:
       """
       Determine log level based on configuration.
       Args:
           level (Optional[str]): The log level as a string.
       Returns:
           int: Corresponding logging level constant.
       """
       levels = {
           'DEBUG': logging.DEBUG,
           'INFO': logging.INFO,
           'WARNING': logging.WARNING,
           'ERROR': logging.ERROR,
           'CRITICAL': logging.CRITICAL
       }
       return levels.get(level, logging.DEBUG)  # Default to DEBUG if level is unknown
   
   def log_info(self, message: str) -> None:
       """
       Log an informational message, used when log level is INFO or DEBUG.
       Args:
           message (str): The message to log.
       """
       if self.logger.isEnabledFor(logging.INFO):
           self.logger.info(message, extra={"endpoint": self.endpoint})