import jwt
from fastapi import Depends, HTTPException, status, Request, Header
from fastapi.security import OAuth2PasswordBearer
from pydantic import ValidationError
from src.schemas.base_schema import MyHeader
from .token import decode_jwt

oauth2_scheme=OAuth2PasswordBearer(tokenUrl='/login', scheme_name="JWT")

async def get_current_user(request: Request, token: str = Depends(oauth2_scheme)) -> str:
    """
    Extracts the user ID from the JWT token.

    Args:
    request (Request): The HTTP request object.
    token (str): The JWT token as a string.

    Returns:
    Dict: A dictionary containing the user's ID.

    Raises:
    HTTPException: If the JWT token is invalid or expired.
    """
    try:
        data = decode_jwt(token)
        return data["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Token has expired")
    except jwt.JWTClaimsError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Invalid claims, please check the audience and issuer")
    except jwt.JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Unable to parse token")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail=str(e))


def common_header_dependency(
    Init_Country:str=Header(..., description="Init-Country"),
    Channel_Identifier:str=Header(..., description="Channel-Identifier"),
    Unique_Reference:str=Header(..., description="Unique-Reference"),
):
    try:
        headers=MyHeader(
            Init_Country=Init_Country,
            Channel_Identifier=Channel_Identifier,
            Unique_Reference=Unique_Reference,
        )
    except ValidationError as e: 
        errors={err["loc"][0]: err["msg"] for err in e.errors()}     
        raise HTTPException(status_code=400, detail=errors)
    return headers
    