from passlib.context import CryptContext
import secrets
import string
from fastapi import HTTPException, status
from .log_service import LogsService
# Initialize the password context with bcrypt scheme

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

logger = LogsService.get_logger()

# Constants for salt generation
CHARACTERS = string.ascii_letters + string.digits

def secure_pwd(raw_password: str) -> str:
    """
    Hashes a password using bcrypt.

    Args:
        raw_password (str): The raw password to hash.

    Returns:
        str: The hashed password.
    """

    func_name="secure_pwd"
    logger.debug(f"{func_name} function",extra={"endpoint":"Utilities"})

    if not raw_password:
        logger.error("Password are required.", extra={"endpoint":"Utilities"})
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Password and salt are required.")
    
    logger.debug(f"/{func_name} function",extra={"endpoint":"Utilities"})
    return pwd_context.hash(raw_password)
    
def verify_pwd(plain: str, stored_hash: str) -> bool:
    """
    Verifies a salted password against a stored hash.

    Args:
        plain (str): The plain password to verify.
        salt (str): The salt used for hashing the password.
        stored_hash (str): The stored hashed password.

    Returns:
        bool: True if the password matches, False otherwise.
    """
    func_name="secure_pwd"
    logger.debug(f"{func_name} function",extra={"endpoint":"Utilities"})
    if not plain or not stored_hash:
        logger.error("Password, salt, and hash are required.", extra={"endpoint":"Utilities"})
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Password, salt, and hash are required.")
    
    logger.debug(f"/{func_name} function",extra={"endpoint":"Utilities"})
    return pwd_context.verify(plain, stored_hash)
