from pydantic_settings import BaseSettings
from pydantic import Field
from pathlib import Path
from typing import List, Optional
from pathlib import Path


env_path = Path(r"V:\phonetics-kyc-dev\.env")

class FastAPIConfig(BaseSettings):
    HOST: str = Field(..., env="FASTAPI_HOST")
    PORT: int = Field(..., env="FASTAPI_PORT")
    DEBUG: bool = Field(..., env="FASTAPI_DEBUG")
    VERSION: str = Field(..., env="FASTAPI_VERSION")

    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"

class ElasticSearchConfig(BaseSettings):
    HOST: str = Field(..., env="ELASTICSEARCH_HOST")
    PORT: int = Field(..., env="ELASTICSEARCH_PORT")
    USERNAME: str = Field(..., env="ELASTICSEARCH_USERNAME")
    ELASTICSEARCH_PASSWORD: str = Field(..., env="ELASTICSEARCH_PASSWORD")
    SCHEME: str = Field(..., env="SCHEME")

    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"

class RedisConfig(BaseSettings):
    HOST: str = Field(..., env="REDIS_HOST")
    PORT: int = Field(..., env="REDIS_PORT")
    REDIS_TIME_TO_LIVE: int = Field(..., env="REDIS_TIME_TO_LIVE")

    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"
             
class TokenConfig(BaseSettings):
    ALGORITHM: str = Field(..., env="TOKEN_ALGORITHM")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(..., env="ACCESS_TOKEN_EXPIRE_MINUTES")
    ACCESS_TOKEN_EXPIRE_HOURS: int = Field(..., env="ACCESS_TOKEN_EXPIRE_HOURS")
    ACCESS_SECRET_KEY: str = Field(..., env="ACCESS_SECRET_KEY")
    REFRESH_TOKEN_EXPIRE_MINUTES: int = Field(..., env="REFRESH_TOKEN_EXPIRE_MINUTES")
    REFRESH_TOKEN_EXPIRE_HOURS: int = Field(..., env="REFRESH_TOKEN_EXPIRE_HOURS")
    REFRESH_SECRET_KEY: str = Field(..., env="REFRESH_SECRET_KEY")
   

    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"

class LogConfig(BaseSettings):
    MAX_BYTES: int = Field(..., env="LOG_MAX_BYTES")
    BACKUP_COUNT: int = Field(..., env="LOG_BACKUP_COUNT")
    LOGS_DATE_FORMAT: str = Field(..., env="LOGS_DATE_FORMAT")
    APP_LOG_FORMAT: str = Field(..., env="APP_LOG_FORMAT")
    APP_LOG_LEVEL: str = Field(..., env="APP_LOG_LEVEL")
    APP_LOG_LOCATION: str = Field(..., env="APP_LOG_LOCATION")
    APP_HANDLERS: List[str] = Field(..., env="APP_HANDLERS")
    ACCESS_LOG_FORMAT: str = Field(..., env="ACCESS_LOG_FORMAT")
    ACCESS_LOG_LEVEL: str = Field(..., env="ACCESS_LOG_LEVEL")
    ACCESS_LOG_LOCATION: str = Field(..., env="ACCESS_LOG_LOCATION")
    ACCESS_HANDLERS: List[str] = Field(..., env="ACCESS_HANDLERS")

    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"

class IndexConfig(BaseSettings):
    DATE_FORMAT: str = Field(..., env="INDEX_DATE_FORMAT")
    USERS_INDEX: str = Field(..., env="USERS_INDEX")
    INDIVIDUALS_INDEX: str = Field(..., env="INDIVIDUALS_INDEX")
    SIMILAR_INDIVIDUALS_INDEX: str = Field(..., env="SIMILAR_INDIVIDUALS_INDEX")
    CORPORATE_INDEX: str = Field(..., env="CORPORATE_INDEX")
    SIMILAR_CORPORATE_INDEX: str = Field(..., env="SIMILAR_CORPORATE_INDEX")
    PREPROCESSING_INDEX: str = Field(..., env="PREPROCESSING_INDEX")
    SETTINGS_INDEX: str = Field(..., env="SETTINGS_INDEX")
    LOG_INDEX: str = Field(..., env="LOG_INDEX")

    @property
    def INDEX_MAP(self):
        
        return {
                "users": self.USERS_INDEX,
                'INDIVIDUALS_INDEX':self.INDIVIDUALS_INDEX,
                'SIMILAR_INDIVIDUALS_INDEX':self.SIMILAR_INDIVIDUALS_INDEX,
                'CORPORATE_INDEX':self.CORPORATE_INDEX,
                'SIMILAR_CORPORATE_INDEX':self.SIMILAR_CORPORATE_INDEX,
                'PREPROCESSING_INDEX':self.PREPROCESSING_INDEX,
                'SETTINGS_INDEX':self.SETTINGS_INDEX,
                'LOG_INDEX':self.LOG_INDEX,
            }
    
    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"

class BusinessConfig(BaseSettings):
    OVERALL_THRESHOLD: int = Field(..., env="OVERALL_THRESHOLD")
    AUTO_MERGE_OVERALL_THRESHOLD: int = Field(..., env="AUTO_MERGE_OVERALL_THRESHOLD")

    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"
             
class Settings(BaseSettings):
   
    # ---------- Project Information ----------
    APP_NAME: str = Field(..., env="APP_NAME")
    APP_DESCRIPTION: Optional[str] = Field(..., env="APP_DESCRIPTION")
    APP_VERSION: str = Field(..., env="APP_VERSION")

    # ---------- Sub-configurations ----------  
    FASTAPI: FastAPIConfig = FastAPIConfig()
    ELASTICSEARCH: ElasticSearchConfig = ElasticSearchConfig()
    REDIS: RedisConfig = RedisConfig()
    TOKEN: TokenConfig = TokenConfig()
    LOG: LogConfig = LogConfig()
    INDEXES: IndexConfig = IndexConfig()
    BusinessRules:BusinessConfig = BusinessConfig()

    
    class Config:
        env_file = env_path
        env_file_encoding = "utf-8"
        extra = "allow"

config = Settings()