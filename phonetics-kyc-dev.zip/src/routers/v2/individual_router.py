from fastapi import APIRouter, Request, Depends, Header
from fastapi.responses import JSONResponse
from src.database import get_db
from src.services import IndividualsService
from src.utils.helpers import get_current_user
from src.schemas import DefaultResponse, CreateIndividual, UpdateIndividual
from src.schemas.individual_schema import (
                        CreateIndividual,
                        UpdateIndividual,
                        CompareIndividual,
                        SearchByKeysIndividual,
                        SearchByObjectIndividual,
                        CompareResponseIndividual,
                        IndividualSearchResponse,
                    )



# Create an API router
IndividualRouter=APIRouter(prefix="/api/v2/individuals", tags=["api_v2", "Individuals"])

@IndividualRouter.post('/add/', response_model=DefaultResponse)
async def add_individuals(
                    data:CreateIndividual, 
                    request:Request, 
                    current_user:str=Depends(get_current_user),
                    es= Depends(get_db)
                )-> JSONResponse:
    
    """ This Endpoint for add customer to elasticsearch database."""
    # Read Data and Create Connection
    service_obj=IndividualsService(es=es, endpoint="individuals/add", user_id=current_user)
    # Apply Add Individual Procedure
    content, status_code=service_obj.create_individual(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@IndividualRouter.put('/update/{party_id}', response_model=DefaultResponse)
async def update_individuals(
                        party_id:str, 
                        data:UpdateIndividual, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db),
                    )-> JSONResponse:
        
    """ This Endpoint for add and update customer to elasticsearch database."""
    # Read Data and Create Connection
    service_obj=IndividualsService(es=es, endpoint="individuals/update", user_id=current_user)
    # Apply Individual Update Procedure
    content, status_code=service_obj.update_individual(
                                                headers=dict(request.headers), 
                                                data=data, 
                                                party_id=party_id
                                            )
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@IndividualRouter.post('/compare/',response_model=CompareResponseIndividual)
async def individuals_compare (
                    data:CompareIndividual, 
                    request:Request, 
                    current_user:str=Depends(get_current_user),
                    es= Depends(get_db)
                    
                )-> JSONResponse:
    
    """ This Endpoint for compare between two objects Based on Business rules of individuals users."""
    # Read Data and Create Connection
    service_obj=IndividualsService(es=es, endpoint="individuals/compare", user_id=current_user)
    # Apply Individual Compare Procedure
    content, status_code=service_obj.individuals_compare(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@IndividualRouter.post('/search-keys/', response_model=IndividualSearchResponse)
async def individuals_search_by_keys(
                            data:SearchByKeysIndividual, 
                            request:Request, 
                            current_user:str=Depends(get_current_user),
                            es= Depends(get_db)
                        )-> JSONResponse: 
    
    """This Endpoint for Search about individuals objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only"""
    # Read Data and Create Connection
    service_obj=IndividualsService(es=es, endpoint="individuals/search-keys", user_id=current_user)
    # Apply Individuals Search By Keys Procedure
    content, status_code=service_obj.individuals_search_by_keys(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)
    
@IndividualRouter.post('/search-object/', response_model=IndividualSearchResponse)
async def individuals_search_by_object(
                                data:SearchByObjectIndividual, 
                                request:Request, 
                                current_user:str=Depends(get_current_user),
                                es= Depends(get_db)
                            )-> JSONResponse: 
    
    """This Endpoint for Search about individuals objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only"""
    # Read Data and Create Connection
    service_obj=IndividualsService(es=es,endpoint="individuals/search-object", user_id=current_user)
    # Apply Individuals Search By Object Procedure
    content, status_code=service_obj.individuals_search_by_object(
                                                    headers=dict(request.headers), 
                                                    data=data
                                                )
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)
