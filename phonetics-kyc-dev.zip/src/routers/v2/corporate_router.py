from fastapi import APIRouter, Request, Depends, Header
from fastapi.responses import JSONResponse
from src.services import Corporate_Services
from src.database import get_db
from src.utils.helpers import get_current_user
from src.schemas import (
                        MyHeader,
                        DefaultResponse,
                        CreateCorporate,
                        UpdateCorporate,
                        CorporateCompare,
                        CorporateSearchByKeys,
                        CorporateSearchByObjects,

                        CorporateSearchResponse,
                        CorporateCompareResponse
                    )

# Create an API router
CorporateRouter=APIRouter(prefix="/api/v2/corporate", tags=["api_v2", "Corporate"])

@CorporateRouter.post('/add/', response_model=DefaultResponse)
async def create_corporate(
                    data:CreateCorporate, 
                    request:Request, 
                    current_user:str=Depends(get_current_user),
                    es= Depends(get_db)    
                )-> JSONResponse:

    """ This Endpoint for Add a new corporate to the elasticsearch database. """
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="corporate/add", user_id=current_user)
    # Start add corporate procedure
    content, status_code =service_obj.create_corporate(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@CorporateRouter.put('/update/{party_id}', response_model=DefaultResponse)
async def update_corporate(
                        party_id:str, 
                        data:UpdateCorporate, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db)
                        )-> JSONResponse:
     
    """This Endpoint for Add and Update a new corporate to the elasticsearch database."""

    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="corporate/update", user_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.update_corporate(headers=dict(request.headers), data=data, party_id=party_id)
    # Return Response  
    return JSONResponse(content=content, status_code=status_code)

@CorporateRouter.post('/compare/', response_model=CorporateCompareResponse)
async def compare_corporate(
                    data:CorporateCompare, 
                    request:Request, 
                    current_user:str=Depends(get_current_user),
                    es= Depends(get_db)
                )-> JSONResponse:
    
    """ This Endpoint for compare between two objects Based on Business rules of corporate users."""
   
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="corporate/compare", user_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.corporate_compare(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@CorporateRouter.post('/search-keys/', response_model=CorporateSearchByKeys)
async def search_by_keys_corporate(
                        data:CorporateSearchByKeys, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db)
                        )-> JSONResponse:
    
    """This Endpoint for Search about corporate objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only."""
    
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="search-by-object", user_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.corporate_search_by_keys(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content,status_code=status_code)
 
@CorporateRouter.post('/search-object/', response_model=CorporateSearchResponse)
async def search_by_object_corporate(
                        data:CorporateSearchByObjects, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db)
                        )-> JSONResponse:
    
    """This Endpoint for Search about corporate objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only."""
    
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="corporate/search-by-keys", user_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.corporate_search_by_object(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content,status_code=status_code)

