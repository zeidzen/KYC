from .v1 import V1_IndividualRouter, V1_SettingsRouter
from .v2 import (
    V2_AuthenticationRouter,
    V2_CorporateRouter,
    V2_Ind_Cor_Router,
    V2_IndividualRouter
)