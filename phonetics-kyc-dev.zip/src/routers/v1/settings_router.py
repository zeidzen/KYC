from fastapi import APIRouter, Request, Depends
from fastapi.responses import JSONResponse
from src.services import Settings_Services
from src.utils.helpers import get_current_user
from src.schemas.settings_schema import settings, update_settings
from typing import List
# Create an API router
SettingsRouter=APIRouter(prefix="/api/v1/settings", tags=["api_v1", "Settings"])

@SettingsRouter.get('/',response_model=List[settings])
async def get_settings(request:Request, current_user:str=Depends(get_current_user))-> JSONResponse:

    """ This Endpoint for Get All settings for all indexes from index_settings table."""
    # 1.Read Data and Create Connection
    obj_Operations=Settings_Services(endpoint="settings")
    # Apply Get All Users Procedure
    content, status_code=obj_Operations.get_settings(
                                                    headers=dict(request.headers),
                                                    user_id=current_user)
    # Create Response
    return JSONResponse(content=content, status_code=status_code)

        
@SettingsRouter.get('/{index}/{field}', response_model=settings)
async def get_settings(
    request:Request, index: str, field:str, current_user:str=Depends(get_current_user))-> JSONResponse:

    """ This Endpoint for Get Field Settings from index_settings table."""
    # 1.Read Data and Create Connection
    obj_Operations=Settings_Services(endpoint="settings")
    # Apply Get All Users Procedure
    content, status_code=obj_Operations.get_field_setting(
                                                    headers=dict(request.headers),
                                                    index=index,
                                                    field=field,
                                                    user_id=current_user)
    # Create Response
    return JSONResponse(content=content, status_code=status_code)
    
@SettingsRouter.put('/{index}/{field}', response_model=settings)
async def get_settings(
    request:Request, index: str, field:str, data:update_settings, current_user:str=Depends(get_current_user))-> JSONResponse:

    """ This Endpoint for Update Field Settings"""
    # 1.Read Data and Create Connection
    obj_Operations=Settings_Services(endpoint="settings")
    # Apply Get All Users Procedure
    content, status_code=obj_Operations.update_field_setting(
                                                    headers=dict(request.headers),
                                                    index=index,
                                                    field=field,
                                                    data=data,
                                                    user_id=current_user)
    # Create Response
    return JSONResponse(content=content, status_code=status_code)
    