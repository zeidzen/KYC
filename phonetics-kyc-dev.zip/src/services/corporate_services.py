from fastapi.encoders import jsonable_encoder
from fastapi import status, HTTPException
from elasticsearch import Elasticsearch, exceptions as es_exceptions
import uuid
import re
import time
import operator
import pickle
from typing import Dict, Tuple
from datetime import datetime
from uuid import UUID
from src.services.base_services import BaseService
from src.database import close_connection
from src.utils.cache import get_cache, update_cache
from src.config import config
from src.schemas import (
                    CreateCorporate, 
                    UpdateCorporate,
                    CorporateCompare,
                    CorporateSearchByKeys,
                    CorporateSearchByObjects
                )
from src.crud.crud_logs import CrudLogs
from src.crud.crud_corporate import CrudCorporate

class Corporate_Services (BaseService):

    def __init__(self, es:Elasticsearch, endpoint:str="", user_id:UUID=""):
        super().__init__(es=es, service_type='corporate', endpoint=endpoint)
        self.path=f"c.cc.cs.{self.endpoint[0]}.CO."
        self.user_id=user_id
        
    
    def create_corporate(self, headers:Dict, data:CreateCorporate)-> Tuple[Dict, int]:
        
        """ This Function will apply procedure for add and Return Results """

        start_time = time.perf_counter()
        func_name, log_path = "create_corporate", self.path + "create_corporate"
        self.logger.debug(f"{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})
        
        try:

            new_corporate = {
                "customer_id": str(uuid.uuid4()),
                "party_id": data.parameters.party_id,
                "source_country": data.parameters.source_country,
                "role": data.parameters.role,
                "organization": data.parameters.organization,
                "sequence": data.parameters.sequence,
                "company_type": data.parameters.company_type,
                "is_searchable": True,
                "is_deleted": False,
                "created_at": datetime.now().strftime(config.INDEXES.DATE_FORMAT),
                "updated_at": None,
                "names": self.normalize_names(data.object.names.__dict__),
                "nationalities": [nationality.__dict__ for nationality in data.object.nationalities],
                "parties_country": data.object.parties_country.__dict__
            }

            # Check if Corporate exists
            is_exists=CrudCorporate.check_if_corporate_exists(es=self.es, keys=data.parameters.__dict__)
            if is_exists:
                content = {"detail": "The parties keys already exist"}
                self.logger.warning(content["detail"], extra={"path": log_path, "endpoint": self.endpoint})
                raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=content["detail"])

            # Create new Corporate
            content = CrudCorporate.create_new_corporate(
                es=self.es,
                record_id=new_corporate["customer_id"],
                record_data=new_corporate
            )            

            # Add to Logs
            self.logger.debug(f"/{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})
            CrudLogs.add_to_log(
                es=self.es,
                service_type=self.service_type,
                headers=headers,
                status_code=status.HTTP_201_CREATED,
                endpoint=self.endpoint,
                process_time=time.perf_counter() - start_time,
                user_id=self.user_id,
                inputs=jsonable_encoder(data),
                output=content
            )

            return content, status.HTTP_201_CREATED

        except HTTPException as http_exc:
            self._handle_exception(headers, jsonable_encoder(data), start_time, log_path, http_exc)


    def update_corporate(self, headers: dict, party_id:str, data: UpdateCorporate)-> tuple[dict, int]:
        
        """This Function will apply procedure for updating corporate and Return Results"""

        start_time = time.perf_counter()
        func_name, log_path = "update_corporate", self.path + "update_corporate"
        self.logger.debug(f"{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})

        try:
            # Prepare the new or updated corporate data
            data.parameters.party_id=party_id 
            updated_corporate = {
                "party_id": data.parameters.party_id,
                "source_country": data.parameters.source_country,
                "role": data.parameters.role,
                "organization": data.parameters.organization,
                "sequence": data.parameters.sequence,
                "company_type": data.parameters.company_type,
                "is_searchable": data.parameters.is_searchable,
                "is_deleted": data.parameters.is_deleted,
                "updated_at": datetime.now().strftime(config.INDEXES.DATE_FORMAT),
                "names": self.normalize_names(data.object.names.__dict__),
                "nationalities": [nationality.__dict__ for nationality in data.object.nationalities],
                "parties_country": data.object.parties_country.__dict__
            }

            # Check if the corporate exists
            is_exists=CrudCorporate.check_if_corporate_exists(es=self.es, keys=data.parameters.__dict__)
            if is_exists:
                # Update the corporate if it exists
                content = CrudCorporate.update_corporate(es=self.es, updated_data=updated_corporate)
                self.logger.info(content["detail"], extra={"path": log_path, "endpoint": self.endpoint})
                status_code = status.HTTP_200_OK
            else:
                # Create a new corporate if it does not exist
                data.parameters.party_id=party_id 
                content, status_code = self.create_corporate(headers=headers, data=data)

            # Add to Logs
            self.logger.debug(f"/{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})
            CrudLogs.add_to_log(
                es=self.es,
                service_type=self.service_type,
                headers=headers,
                status_code=status_code,
                endpoint=self.endpoint,
                process_time=time.perf_counter() - start_time,
                user_id=self.user_id,
                inputs=jsonable_encoder(data),
                output=content
            )

            return content, status_code

        except es_exceptions.TransportError as e:
            self.logger.error(f"Transport error occurred: {e}", extra={"path": log_path, "endpoint": self.endpoint})
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=f"Transport error occurred: {str(e)}")

        except es_exceptions.RequestError as e:
            self.logger.error(f"Request error occurred: {e}", extra={"path": log_path, "endpoint": self.endpoint})
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Request error occurred: {str(e)}")

        except HTTPException as http_exc:
            self._handle_exception(headers, jsonable_encoder(data), start_time, log_path, http_exc)

        except Exception as e:
            self.logger.error(f"An unknown error occurred: {e}", extra={"path": log_path, "endpoint": self.endpoint})
            raise HTTPException(status_code=500, detail=f"An unknown error occurred: {str(e)}")

    
    def corporate_compare(self, headers: dict, data:CorporateCompare)-> tuple[dict, int]:
        """ This Function applies the procedure for comparing individuals and returns results. """
        
        start_time = time.perf_counter()
        func_name = "compare_individuals"
        log_path = self.path + func_name

        self.logger.debug(f"{func_name} function started", extra={"path": log_path, "endpoint": self.endpoint})

        try:
            # Get the phonetics object used for comparison
            self.obj_phonetics = self.get_phonetics_obj()
                
            data = jsonable_encoder(data)
            # Perform the comparison between the two objects using phonetics
            content = self.obj_phonetics.compare_similarity_for_two_object(
                source_object=data["object_one"],
                similar_object=data["object_two"],
                pre_processing=data["parameters"]["pre_processing"],
                party_type=self.service_type
            )
            # Add the comparison result to logs
            process_time = time.perf_counter() - start_time
            CrudLogs.add_to_log(
                es=self.es,
                service_type=self.service_type,
                headers=headers,
                status_code=status.HTTP_202_ACCEPTED,
                endpoint=self.endpoint,
                process_time=process_time,
                user_id=self.user_id,
                inputs=data,
                output=content
            )

            self.logger.debug(f"/{func_name} function completed", extra={"path": log_path, "endpoint": self.endpoint})
            return content, status.HTTP_202_ACCEPTED

        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data, start_time, log_path, http_exc)

        finally:
            # Ensure the connection is closed whether an exception occurred or not
            close_connection(self.es)


    def corporate_search_by_keys(self, headers:dict, data:CorporateSearchByKeys)-> tuple[dict, int]:
            
        """ This Function will apply procedure for Search By Keys and Return Results """

        start_time = time.perf_counter()
        func_name = "individuals_search_by_keys"
        log_path = self.path + func_name

        self.logger.debug(f"{func_name} function started", extra={"path": log_path, "endpoint": self.endpoint})


        try:
            
            data = jsonable_encoder(data)

            # Get the phonetics object used for comparison
            phonetics_obj = self.get_phonetics_obj()

            source_object =CrudCorporate.get_corporate_by_keys(
                                                es=self.es, 
                                                keys=self.get_primary_keys(data)
                                                )

            # Find objects similar to the source object
            similar_objects= CrudCorporate.find_similar_corporate(
                                        es=self.es,
                                        settings=phonetics_obj.settings,
                                        name_object=source_object["names"],
                                        party_id_not_in=data["party_id_not_in"]
                                    )

            results=list()
            for similar_object in similar_objects:
                similarity_result=phonetics_obj.check_similarity(
                                                            source_object=source_object,  
                                                            similar_object=similar_object, 
                                                            pre_processing=data["pre_processing"]
                                                            )
                if similarity_result['over_all_ratio'] >=config.BusinessRules.OVERALL_THRESHOLD:
                    results.append(similarity_result)

            # 6.3 Sort Results Based on Over All Ratio
            source_object = {
                "keys":phonetics_obj.collect_keys_info(source_object),
                "object":{
                    "names":source_object["names"],
                    "nationalities":source_object["nationalities"],
                    "parties_country":source_object["parties_country"]
                }
            }
            results.sort(key=operator.itemgetter("over_all_ratio"), reverse=True)
            content={"result_search":results, "source":source_object}

            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint, 
                process_time=time.perf_counter() - start_time, 
                user_id=self.user_id, 
                inputs=data, 
                output=content
            )
            # End procedure and close Connection
            close_connection(self.es)
            self.logger.debug(f"/{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
            return content, status.HTTP_200_OK 

        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data, start_time, log_path, http_exc)

        finally:
            # Ensure the connection is closed whether an exception occurred or not
            close_connection(self.es)


    def corporate_search_by_object(self, headers:Dict, data:CorporateSearchByObjects)-> tuple[dict, int]:  

        """ This Function will apply procedure for Search By Object and Return Results """

        start_time = time.perf_counter()
        func_name = "individuals_search_by_object"
        log_path = self.path + func_name

        self.logger.debug(f"{func_name} function started", extra={"path": log_path, "endpoint": self.endpoint})
        
        try:

            data = jsonable_encoder(data)
            source_object = pickle.loads(pickle.dumps(data))
            source_object["object"].update(source_object["parameters"])
            source_object = source_object["object"]

            # Get the phonetics object used for comparison
            phonetics_obj = self.get_phonetics_obj()

            # Find objects similar to the source object
            similar_objects= CrudCorporate.find_similar_corporate(
                                        es=self.es,
                                        settings=phonetics_obj.settings,
                                        name_object=source_object["names"],
                                        party_id_not_in=source_object["party_id_not_in"]
                                    )

            results=list()
            for similar_object in similar_objects:
                similarity_result=phonetics_obj.check_similarity(
                                                            source_object=source_object,  
                                                            similar_object=similar_object, 
                                                            pre_processing=source_object["pre_processing"]
                                                        )
                if similarity_result['over_all_ratio'] >=config.BusinessRules.OVERALL_THRESHOLD:
                    results.append(similarity_result)

            results.sort(key=operator.itemgetter("over_all_ratio"), reverse=True)
            content={"result_search":results, "source":data["object"]}

            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint, 
                process_time=time.perf_counter() - start_time, 
                user_id=self.user_id, 
                inputs=data, 
                output=content
            )
            # End procedure and close Connection
            close_connection(self.es)
            self.logger.debug(f"/{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
            return content, status.HTTP_200_OK 

        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data, start_time, log_path, http_exc)

        finally:
            # Ensure the connection is closed whether an exception occurred or not
            close_connection(self.es)

    
    def normalize_names(self, names_object: Dict[str, str]) -> Dict[str, str]:
        """
        Normalize the name fields in a dictionary to meet specified formatting rules:
        1. No leading or trailing spaces.
        2. All characters in lowercase.
        3. No consecutive spaces between words.

        Args:
            names_object (Dict[str, str]): A dictionary containing name fields as strings.

        Returns:
            Dict[str, str]: The dictionary with normalized name fields.
        """
        func_name = "normalize_names"
        log_path = f"{self.path}/{func_name}"
        self.logger.debug(f"{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})

        # Precompile the regex for replacing multiple spaces to enhance performance
        space_replacer = re.compile(r'\s+')

        # Create a new dictionary to avoid modifying the input dictionary directly
        normalized_names = {}

        for key, value in names_object.items():
            if isinstance(value, str):  # Ensure the value is a string to prevent errors
                # Normalize the string
                normalized_value = value.strip().lower()
                normalized_value = space_replacer.sub(' ', normalized_value)
                normalized_names[key] = normalized_value
            else:
                self.logger.warning(f"Non-string value encountered in {key}: {value}",
                                    extra={"path": log_path, "endpoint": self.endpoint})

        self.logger.debug(f"/{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})
        return normalized_names
