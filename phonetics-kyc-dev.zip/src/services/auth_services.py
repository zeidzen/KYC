######################################################################################################################
######################################################################################################################
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                           <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Authentication Operations <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                           <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
######################################################################################################################
######################################################################################################################

from fastapi import status, HTTPException
from elasticsearch import Elasticsearch
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime, timedelta, timezone
import uuid 
import jwt
import time
from typing import Dict, Tuple
from src.database import close_connection
from src.crud.crud_user import CrudUser
from src.crud.crud_logs import CrudLogs
from src.services import BaseService
from src.config import config
from src.utils.token import create_access_token
from src.utils.password import verify_pwd
from src.schemas import Login, Signup, ChangePassword, User


class Auth_Services (BaseService):

    def __init__(self, endpoint:str, es:Elasticsearch):

        self.service_type='auth'
        self.endpoint=endpoint
        self.es=es
        super().__init__(
            es=self.es,
            service_type=self.service_type, 
            endpoint=self.endpoint,
            path=f"p.c.av.ao.{self.endpoint[0]}.AO."
        )
        self.path=f"service.auth"
        self.user_id=""
        

        # # Read User 
        # self.users=get_cache(cache_key="phonetics_users")
        # if self.users.empty or True:
        #     self.users=CrudUser.get_users(es=self.es)
        #     self.users=pd.DataFrame(self.users)
        #     update_cache(cache_key=f"phonetics_users", data=self.users)
        #     self.logger.debug(f"Phonetics Users updated in the cache",extra={"path":path,"endpoint":self.endpoint})



    def login(self, data: Login, headers: Dict[str, str]) -> Tuple[Dict[str, str], int]:
        """
        Authenticate a user and generate a JWT token.

        Args:
        data (Login): The login credentials, including email and password.
        headers (dict): The request headers.

        Returns:
        Tuple[Dict[str, str], int]: A tuple containing the JWT token and HTTP status code.
        
        Raises:
        HTTPException: If authentication fails.
        """
        start_time = time.perf_counter()
        log_path = self.path + "login"

        # Log function entry
        self.logger.debug("Starting login procedure", extra={"path": log_path, "endpoint": self.endpoint})

        try:
            # Retrieve user from database
            user = CrudUser.get_by_email(es=self.es, email=data.email)
            if not user:
                detail = "Could not verify credentials."
                self.logger.debug(detail, extra={"path": log_path, "endpoint": self.endpoint})
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail)

            # Verify password
            if verify_pwd(stored_hash=user[0]["_source"]['password'], plain=data.password):
                user_details = user[0]["_source"]
                self.user_id = user_details['user_id']
                access_token = create_access_token(subject=self.user_id)
                output, status_code = {"token": access_token}, status.HTTP_201_CREATED
            else:
                detail = "Email or password is incorrect."
                self.logger.warning(detail, extra={"path": log_path, "endpoint": self.endpoint})
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail)

            # Log the process time
            CrudLogs.add_to_log(
                es=self.es,
                service_type=self.service_type,
                headers=headers,
                status_code=status_code,
                endpoint=self.endpoint,
                process_time=time.perf_counter() - start_time,
                user_id=self.user_id,
                inputs={"email": data.email, "password": "********"},
                output=output
            )
            close_connection(self.es)
            return output, status_code

        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data, start_time, log_path, http_exc)
   
    def signup (self, data:Signup, headers:dict)-> dict:
        
        """ This Function will apply procedure for Sign UP and Return Results """
        start_time= time.perf_counter()
        func_name, log_path="signup_procedure", self.path+"signup_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
        
        try:
            # Check User Exists
            user_data = data.__dict__.copy()
            user_data['is_admin']=False
            user_data['email']=user_data['email'].strip().lower()
            user_data['name']=user_data['name'].strip()
            user_data["password"]=generate_password_hash(str(user_data["password"]))
            user_data["user_id"]=str(uuid.uuid4())
            user_data["created_at"]=datetime.now(timezone.utc)
            CrudUser.create_user(es=self.es, user_data=User(**user_data))
            output, status_code={'detail':'Successfully registered.'}, status.HTTP_201_CREATED
            # Add to Log   
            self.logger.debug(f"/{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
            process_time= time.perf_counter() - start_time 
            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint, 
                process_time=process_time, 
                user_id=self.user_id, 
                inputs=data.__dict__, 
                output=output
            )

            close_connection(self.es)
            return output, status_code
        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data.__dict__, start_time, log_path, http_exc)
        
    def get_all_users_procedure(self,headers:dict, user_id:str)-> dict:
        
        """ This Function will apply procedure for Get All User and Return Results """
        start_time= time.perf_counter()
        self.user_id, func_name, log_path=user_id, ".get_all_users_procedure",self.path+"get_all_users_procedure" 
        self.logger.debug(f"{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
        
        try:
            # Get Data
            users=CrudUser.get_users(es=self.es)
            # Add log
            process_time= time.perf_counter() - start_time 
            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status.HTTP_202_ACCEPTED,
                endpoint=self.endpoint, 
                process_time=process_time, 
                user_id=self.user_id, 
                inputs=None, 
                output=None
            )
            self.logger.debug(f"/{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
            close_connection(self.es)
            return users, status.HTTP_202_ACCEPTED
        
        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, None, start_time, log_path, http_exc)
    
    def change_password (self,data:ChangePassword, headers:dict, current_user:str)-> dict:
        
        """ This Function will apply procedure for Change Password and Return Results """
        start_time= time.perf_counter()
        func_name, path="change_password_procedure", self.path+"change_password_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        # try:
        if not self.check_is_admin(user_id=current_user):
            output, status_code={'detail':'Only the administrator has the permission to Update.'}, status.HTTP_403_FORBIDDEN
            self.logger.critical(output["detail"],extra={"path":path,"endpoint":self.endpoint})
            
        elif CrudUser.check_user_exists_by_user_id(es=self.es, user_id=data.user_id):
            self.update_password(data.user_id.strip(), data.password.strip())
            self.logger.warning(f"Password for {current_user} is updated",extra={"path":path,"endpoint":self.endpoint})
            output, status_code ={'detail':'Password Updated Successfully.'}, status.HTTP_201_CREATED
        else:
            output, status_code={"detail":"The user is not exists."}, status.HTTP_404_NOT_FOUND
            self.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
        
        process_time= time.perf_counter() - start_time 
        CrudLogs.add_to_log (
            es=self.es,
            service_type=self.service_type,
            headers=headers, 
            status_code=status.HTTP_202_ACCEPTED,
            endpoint=self.endpoint, 
            process_time=process_time, 
            user_id=self.user_id, 
            inputs=data.__dict__, 
            output=output
        )

        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        close_connection(self.es)
        return output, status_code
        # except:
        #     content={"detail":"Internal server error occurred in the {} endpoint.".format(self.endpoint)}
        #     self.logger.error(content["detail"],extra={"path":path,"endpoint":self.endpoint})
        #     close_connection(self.es)
        #     return content, status.HTTP_409_CONFLICT

    #######################################################################################################################
    #######################################################################################################################
    #######################################################################################################################
    

    def check_is_admin(self, user_id:str)-> bool:
        # Check user 
        user=CrudUser.get_by_id(es=self.es, user_id=user_id)
        if user["is_admin"]:
           return True
        return False
    

    def check_user_exists (self,email:str=None,user_id:str=None)-> bool:
        
        """ this function check if user exists by check email or public id in users index """
        
        
        func_name, path, self.user_id="check_user_exists", self.path +"check_user_exists", user_id
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})

        user=CrudUser.get_by_id(es=self.es, user_id=user_id)

        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        if user:
           return False
        return True
    

    def update_password(self, user_id, new_password):
        
        func_name, path="update_password", self.path +"update_password"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        update_fields={'password':generate_password_hash(str(new_password))}
        result = CrudUser.update_user(es=self.es, user_id=user_id, update_fields=update_fields)
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return result
        
