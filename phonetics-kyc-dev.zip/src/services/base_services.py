import pandas as pd
import time
from src.crud.crud_settings import CrudSettings
from src.crud.crud_preprocessing import CrudPreprocessing
from src.crud.crud_logs import CrudLogs
from src.utils.cache import get_cache, update_cache
from src.utils.log_service import LogsService
from src.database import close_connection
from .phonetic import PhoneticsService


class BaseService:

    def __init__(self,es ,service_type='system',endpoint="",path=""):
        
        # System Type
        self.es=es
        self.service_type=service_type
        self.endpoint=endpoint
        self.org_path="bs.BS."
        self.path=path + self.org_path
        self.logger = LogsService.get_logger()
        #self.settings=self.read_setting_data(service_type=self.service_type)

        # Read Setting Information 
        # self.settings_file=pd.DataFrame() #get_cache(cache_key=f"phonetics_settings_{self.service_type}")
        # if self.settings_file.empty or True: 
        #     self.settings_file=self.read_setting_data(service_type=self.service_type)
        #     self.settings_file=pd.DataFrame(self.settings_file)
        #     update_cache(cache_key=f"phonetics_settings_{self.service_type}", data=self.settings_file)
        #     self.logger.debug(f"Phonetics settings updated in the cache",extra={"path":path,"endpoint":self.endpoint})

        

        if self.endpoint=="update":
            self.add_type="add"
        
    

    def get_primary_keys(self, data):
    
        """ This function for select the primary keys and return them. """
        
        primary_keys_list=["party_id","role","sequence","source_country","organization"]
        primary_keys=dict()
        for key, value in data.items():
            
            if key in primary_keys_list:
                primary_keys[key]=value 
        return primary_keys
    

    def get_phonetics_obj(self):
        
        settings=self.read_setting_data(service_type=self.service_type)
        normalize_data= self.read_normalize_data()
        normalize_data=normalize_data.fillna("")

        # if normalize_data.empty: 
        #     normalize_data=self.read_normalize_data()
        #     update_cache(cache_key="phonetics_normalize_data", data=normalize_data)
        # normalize_data=normalize_data.fillna("")

        return PhoneticsService(
                        settings=settings, 
                        normalize_data=normalize_data,
                        service_type=self.service_type,
                        endpoint=self.endpoint
                    )


    def read_normalize_data(self,):
        # Read Normalize Data
        normalize_data = CrudPreprocessing.get_preprocessing(es=self.es)
        normalize_data=pd.DataFrame(normalize_data)
        normalize_data=normalize_data.fillna("")
        return normalize_data


    def read_setting_data (self, service_type):
        
        " Read Setting information from ElasticSearch index"

        func_name, path="read_setting_data", self.path+"read_setting_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Get Setting Information (index_settings)

        settings=CrudSettings.get_settings(es=self.es)
        settings=pd.DataFrame(settings)
        if service_type =="corporate":
            settings=settings[settings["service_type"]!="individuals"]
            settings["local_weight"]=settings["cor_local_weight"]
            settings["global_weight"]=settings["cor_global_weight"]
        elif service_type =="individuals":
            settings=settings[settings["service_type"]!="corporate"]

        cleanup={
            "pre_processing":{'TRUE':True, "FALSE":False},
            "keys":{'TRUE':True, "FALSE":False},
            "weight_calculation":{'TRUE':True, "FALSE":False},
            "status":{'TRUE':True, "FALSE":False},
            "return_with_result":{'TRUE':True, "FALSE":False},
        }
        settings=settings.replace(cleanup)
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return settings
    

    def _handle_exception(self, headers, data, start_time, log_path, http_exc):
        CrudLogs.add_to_log(
            es=self.es,
            service_type=self.service_type,
            headers=headers,
            status_code=http_exc.status_code,
            endpoint=self.endpoint,
            process_time=time.perf_counter() - start_time,
            user_id=self.user_id,
            inputs=data,
            output={"detail": http_exc.detail}
        )
        close_connection(self.es)
        self.logger.error(http_exc.detail, extra={"path": log_path, "endpoint": self.endpoint})
        raise http_exc