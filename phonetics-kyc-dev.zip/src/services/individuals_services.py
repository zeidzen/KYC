from fastapi.encoders import jsonable_encoder
from fastapi import status, HTTPException
from elasticsearch import Elasticsearch, exceptions as es_exceptions
from typing import Dict, Tuple
from datetime import datetime, timezone
import uuid
import pickle
import operator
import re
import time
from src.services import BaseService
from src.utils.cache import get_cache, update_cache
from src.database import close_connection
from src.config import config
from src.schemas import (
                CreateIndividual, 
                UpdateIndividual,
                CompareIndividual,
                SearchByKeysIndividual,
                SearchByObjectIndividual,

                IndividualV1Search
            )       
from src.crud.crud_logs import CrudLogs
from src.crud.crud_individual import CrudIndividual

class IndividualsService(BaseService):

    def __init__(self, es:Elasticsearch, endpoint:str, user_id:str=""):
        super().__init__(es=es, service_type='individual', endpoint=endpoint)
        self.user_id = user_id
        self.path = f"r.ic.{self.endpoint[0]}.IS."

    def create_individual(self, headers: dict, data: CreateIndividual)-> tuple[dict, int]:
        """ This Function will apply procedure for adding individuals and Return Results """
        start_time = time.perf_counter()
        func_name, log_path = "create_individual", self.path + "create_individual"
        self.logger.debug(f"{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})

        try:            
            new_individual = {
                "customer_id": str(uuid.uuid4()),
                "party_id": data.parameters.party_id,
                "source_country": data.parameters.source_country,
                "role": data.parameters.role,
                "organization": data.parameters.organization,
                "sequence": data.parameters.sequence,
                "is_searchable": True,
                "is_deleted": False,
                "created_at": datetime.now().strftime(config.INDEXES.DATE_FORMAT),
                "updated_at": None,
                "names": self.normalize_names(data.object.names.__dict__),
                "nationalities": [nationality.__dict__ for nationality in data.object.nationalities],
                "parties_country": data.object.parties_country.__dict__
            }

            # Check if Individual exists
            is_exists=CrudIndividual.check_if_individual_exists(es=self.es, keys=data.parameters.__dict__)
            if is_exists:
                content = {"detail": "The parties keys already exist"}
                self.logger.warning(content["detail"], extra={"path": log_path, "endpoint": self.endpoint})
                raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=content["detail"])

            # Create new individual
            content = CrudIndividual.create_new_individual(
                es=self.es,
                record_id=new_individual["customer_id"],
                record_data=new_individual
            )            
            # Add to Logs
            self.logger.debug(f"/{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})
            CrudLogs.add_to_log(
                es=self.es,
                service_type=self.service_type,
                headers=headers,
                status_code=status.HTTP_201_CREATED,
                endpoint=self.endpoint,
                process_time=time.perf_counter() - start_time,
                user_id=self.user_id,
                inputs=jsonable_encoder(data),
                output=content
            )

            return content, status.HTTP_201_CREATED

        except HTTPException as http_exc:
            self._handle_exception(headers, jsonable_encoder(data), start_time, log_path, http_exc)

    def update_individual(self, headers: dict, party_id:str, data: UpdateIndividual)-> tuple[dict, int]:
        
        """This Function will apply procedure for updating individuals and Return Results"""

        start_time = time.perf_counter()
        func_name, log_path = "update_individual", self.path + "update_individual"
        self.logger.debug(f"{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})

        try:
            # Prepare the new or updated individual data
            data.parameters.party_id=party_id 
            updated_individual = {
                "party_id": data.parameters.party_id,
                "source_country": data.parameters.source_country,
                "role": data.parameters.role,
                "organization": data.parameters.organization,
                "sequence": data.parameters.sequence,
                "is_searchable": data.parameters.is_searchable,
                "is_deleted": data.parameters.is_deleted,
                "updated_at": datetime.now().strftime(config.INDEXES.DATE_FORMAT),
                "names": self.normalize_names(data.object.names.__dict__),
                "nationalities": [nationality.__dict__ for nationality in data.object.nationalities],
                "parties_country": data.object.parties_country.__dict__
            }

            # Check if the individual exists
            is_exists=CrudIndividual.check_if_individual_exists(es=self.es, keys=data.parameters.__dict__)
            if is_exists:
                # Update the individual if it exists
                content = CrudIndividual.update_individual(es=self.es, updated_data=updated_individual)
                self.logger.info(content["detail"], extra={"path": log_path, "endpoint": self.endpoint})
                status_code = status.HTTP_200_OK
            else:
                # Create a new individual if it does not exist
                data.parameters.party_id=party_id 
                content, status_code = self.create_individual(headers=headers, data=data)

            # Add to Logs
            self.logger.debug(f"/{func_name} function", extra={"path": log_path, "endpoint": self.endpoint})
            CrudLogs.add_to_log(
                es=self.es,
                service_type=self.service_type,
                headers=headers,
                status_code=status_code,
                endpoint=self.endpoint,
                process_time=time.perf_counter() - start_time,
                user_id=self.user_id,
                inputs=jsonable_encoder(data),
                output=content
            )

            return content, status_code

        except es_exceptions.TransportError as e:
            self.logger.error(f"Transport error occurred: {e}", extra={"path": log_path, "endpoint": self.endpoint})
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=f"Transport error occurred: {str(e)}")

        except es_exceptions.RequestError as e:
            self.logger.error(f"Request error occurred: {e}", extra={"path": log_path, "endpoint": self.endpoint})
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Request error occurred: {str(e)}")

        except HTTPException as http_exc:
            self._handle_exception(headers, jsonable_encoder(data), start_time, log_path, http_exc)

        except Exception as e:
            self.logger.error(f"An unknown error occurred: {e}", extra={"path": log_path, "endpoint": self.endpoint})
            raise HTTPException(status_code=500, detail=f"An unknown error occurred: {str(e)}")

    def individuals_compare(self, headers: dict, data:CompareIndividual)-> tuple[dict, int]:
        """ This Function applies the procedure for comparing individuals and returns results. """
        
        start_time = time.perf_counter()
        func_name = "compare_individuals"
        log_path = self.path + func_name

        self.logger.debug(f"{func_name} function started", extra={"path": log_path, "endpoint": self.endpoint})

        try:
            # Get the phonetics object used for comparison
            self.obj_phonetics = self.get_phonetics_obj()
                
            data = jsonable_encoder(data)
            # Perform the comparison between the two objects using phonetics
            content = self.obj_phonetics.compare_similarity_for_two_object(
                source_object=data["object_one"],
                similar_object=data["object_two"],
                pre_processing=data["parameters"]["pre_processing"],
                party_type=self.service_type
            )
            # Add the comparison result to logs
            process_time = time.perf_counter() - start_time
            CrudLogs.add_to_log(
                es=self.es,
                service_type=self.service_type,
                headers=headers,
                status_code=status.HTTP_202_ACCEPTED,
                endpoint=self.endpoint,
                process_time=process_time,
                user_id=self.user_id,
                inputs=data,
                output=content
            )

            self.logger.debug(f"/{func_name} function completed", extra={"path": log_path, "endpoint": self.endpoint})
            return content, status.HTTP_202_ACCEPTED

        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data, start_time, log_path, http_exc)

        finally:
            # Ensure the connection is closed whether an exception occurred or not
            close_connection(self.es)
            
    def individuals_search_by_keys(self, headers:dict, data:SearchByKeysIndividual)-> tuple[dict, int]:
            
        """ This Function will apply procedure for Search By Keys and Return Results """

        start_time = time.perf_counter()
        func_name = "individuals_search_by_keys"
        log_path = self.path + func_name

        self.logger.debug(f"{func_name} function started", extra={"path": log_path, "endpoint": self.endpoint})


        try:
            
            data = jsonable_encoder(data)

            # Get the phonetics object used for comparison
            phonetics_obj = self.get_phonetics_obj()

            source_object =CrudIndividual.get_individual_by_keys(
                                                es=self.es, 
                                                keys=self.get_primary_keys(data)
                                                )
            
            # Find objects similar to the source object
            similar_objects= CrudIndividual.find_similar_individual(
                                        es=self.es,
                                        settings=phonetics_obj.settings,
                                        name_object=source_object["names"],
                                        party_id_not_in=data["party_id_not_in"]
                                    )

            results=list()
            for similar_object in similar_objects:
                similarity_result=phonetics_obj.check_similarity(
                                                            source_object=source_object,  
                                                            similar_object=similar_object, 
                                                            pre_processing=data["pre_processing"]
                                                        )
                if similarity_result['over_all_ratio'] >=config.BusinessRules.OVERALL_THRESHOLD:
                    results.append(similarity_result)

            # 6.3 Sort Results Based on Over All Ratio
            source_object = {
                "keys":phonetics_obj.collect_keys_info(source_object),
                "object":{
                    "names":source_object["names"],
                    "nationalities":source_object["nationalities"],
                    "parties_country":source_object["parties_country"]
                }
            }
            results.sort(key=operator.itemgetter("over_all_ratio"), reverse=True)
            content={"result_search":results, "source":source_object}

            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint, 
                process_time=time.perf_counter() - start_time, 
                user_id=self.user_id, 
                inputs=data, 
                output=content
            )
            # End procedure and close Connection
            close_connection(self.es)
            self.logger.debug(f"/{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
            return content, status.HTTP_200_OK 

        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data, start_time, log_path, http_exc)

        finally:
            # Ensure the connection is closed whether an exception occurred or not
            close_connection(self.es)
   
    def individuals_search_by_object(self, headers:Dict, data:SearchByObjectIndividual)-> tuple[dict, int]:  

        """ This Function will apply procedure for Search By Object and Return Results """

        start_time = time.perf_counter()
        func_name = "individuals_search_by_object"
        log_path = self.path + func_name

        self.logger.debug(f"{func_name} function started", extra={"path": log_path, "endpoint": self.endpoint})
        
        try:

            data = jsonable_encoder(data)
            source_object = pickle.loads(pickle.dumps(data))
            source_object["object"].update(source_object["parameters"])
            source_object = source_object["object"]

            # Get the phonetics object used for comparison
            phonetics_obj = self.get_phonetics_obj()

            # Find objects similar to the source object
            similar_objects= CrudIndividual.find_similar_individual(
                                        es=self.es,
                                        settings=phonetics_obj.settings,
                                        name_object=source_object["names"],
                                        party_id_not_in=source_object["party_id_not_in"]
                                    )

            results=list()
            for similar_object in similar_objects:
                similarity_result=phonetics_obj.check_similarity(
                                                            source_object=source_object,  
                                                            similar_object=similar_object, 
                                                            pre_processing=source_object["pre_processing"]
                                                        )
                if similarity_result['over_all_ratio'] >=config.BusinessRules.OVERALL_THRESHOLD:
                    results.append(similarity_result)

            results.sort(key=operator.itemgetter("over_all_ratio"), reverse=True)
            content={"result_search":results, "source":data["object"]}

            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status.HTTP_200_OK, 
                endpoint=self.endpoint, 
                process_time=time.perf_counter() - start_time, 
                user_id=self.user_id, 
                inputs=data, 
                output=content
            )
            # End procedure and close Connection
            close_connection(self.es)
            self.logger.debug(f"/{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
            return content, status.HTTP_200_OK 

        except HTTPException as http_exc:
            # Handle the exception using the shared handler function
            self._handle_exception(headers, data, start_time, log_path, http_exc)

        finally:
            # Ensure the connection is closed whether an exception occurred or not
            close_connection(self.es)

    def individuals_v1_search(self, headers: Dict, data: IndividualV1Search) -> Tuple[Dict, int]:
        """
        Processes the individual search request either by keys or by object and returns the results.

        Args:
            headers (Dict): HTTP headers to be passed to the search requests.
            data (IndividualV1Search): Data payload for the search, containing parameters.

        Returns:
            Tuple[Dict, int]: The search results content and HTTP status code.
        """
        start_time = time.perf_counter()
        func_name = "individuals_v1_search"
        log_path = f"{self.path}{func_name}"
        
        self.logger.debug(f"Starting {func_name}", extra={"path": log_path, "endpoint": self.endpoint})
        
        # Convert data to JSON-compatible format (if necessary)
        source_object = jsonable_encoder(data)

        # Determine search type based on provided parameters
        if self.is_search_by_keys(source_object["parameters"]):
            content, status_code = self.individuals_search_by_keys(
                headers=headers,
                data=SearchByKeysIndividual(**source_object["parameters"])
            )
        else:
            # Assuming the conversion to dictionary for the parameters is necessary for `individuals_search_by_object`
            content, status_code = self.individuals_search_by_object(
                headers=headers,
                data=SearchByObjectIndividual(**source_object)
            )

        self.logger.debug(f"/{func_name} function",extra={"path":log_path,"endpoint":self.endpoint})
        return content, status_code
                    
    def normalize_names(self, names_object: Dict[str, str]) -> Dict[str, str]:
        """
        Normalize name fields in a names object based on specified rules.
        This function ensures:
            1. No leading or trailing spaces in name fields.
            2. All letters are in lowercase.
            3. Only single spaces between words.

        Args:
            names_object (dict): The dictionary containing name fields.

        Returns:
            dict: The normalized names object.
        """
        func_name = "normalize_names_object"
        log_path = f"{self.path}/{func_name}"
        self.logger.debug(f"Entering {func_name}", extra={"path": log_path, "endpoint": self.endpoint})

        # Regex to identify multiple consecutive spaces
        multiple_spaces = re.compile(r'\s+')
        # Create a new dictionary to store normalized names
        normalized_names = {}

        # Normalize each field
        for field, value in names_object.items():
            normalized_value = multiple_spaces.sub(' ', value.strip().lower())
            normalized_names[field] = normalized_value

        # Construct full names for specified languages
        full_names = {
            "en": ["first_name_en", "second_name_en", "third_name_en", "last_name_en"],
            "ar": ["first_name_ar", "second_name_ar", "third_name_ar", "last_name_ar"]
        }

        for lang, fields in full_names.items():
            # Use normalized fields to construct the full name
            name_parts = [normalized_names.get(field, '') for field in fields]
            if any(name_parts):  # Only construct full_name if there are any parts
                full_name_key = f'full_name_{lang}'
                full_name = ' '.join(name_parts).strip()
                normalized_names[full_name_key] = full_name

        self.logger.debug(f"Exiting {func_name}", extra={"path": log_path, "endpoint": self.endpoint})
        return normalized_names

    def _handle_exception(self, headers, data, start_time, log_path, http_exc):
        CrudLogs.add_to_log(
            es=self.es,
            service_type=self.service_type,
            headers=headers,
            status_code=http_exc.status_code,
            endpoint=self.endpoint,
            process_time=time.perf_counter() - start_time,
            user_id=self.user_id,
            inputs=data,
            output={"detail": http_exc.detail}
        )
        close_connection(self.es)
        self.logger.error(http_exc.detail, extra={"path": log_path, "endpoint": self.endpoint})
        raise http_exc

    def is_search_by_keys(self, parameters):
            
            if (parameters["party_id"] != None and parameters["role"] != None and 
                parameters["sequence"] != None and parameters["source_country"] != None and 
                parameters["organization"] != None): 
                return True
            return False 
