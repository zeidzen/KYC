from fastapi import status, HTTPException
import re
import string 
from typing import Dict, Any, List
from src.config import config
from src.utils.phonetics import similar, remove_arabic_text
from src.utils.log_service import LogsService

class PhoneticsService ():
    
    def __init__(self, 
                 settings, 
                 normalize_data,
                 service_type, 
                 endpoint=""):

        self.settings=settings 
        self.service_type=service_type
        self.normalize_data=normalize_data
        self.endpoint=endpoint
        self.empty_values=[None, '', dict(), list(), " "]
        self.path=""
        self.logger=LogsService.get_logger()

    ########################################################################################################
    ########################################## Phonetics Core  #############################################
    ########################################################################################################
      
    def normalize (self, text:str, language:str="en"):
        """ """
        normalize_data=self.normalize_data[self.normalize_data['language']==language]
        punctuation=string.punctuation 
        translator=str.maketrans('','',punctuation)
        text=text.translate(translator)

        for index, row in normalize_data.iterrows():
            text=re.sub(row['character'], row['replace_to'], text)
        text=re.sub(' ','', text)
        return text.lower().strip()
     
    def preprocessing_field(self, value:str, language:str)-> str:
        """
        Preprocess a given value based on the language and preprocessing requirements.

        Args:
            value (str): The field value to preprocess.
            language (str): The language of the value, e.g., 'ar' for Arabic.
            preprocessing (bool): Whether to apply preprocessing or not.

        Returns:
            str: The preprocessed field value.
        """
        if not value or not isinstance(value, str):
            return ""

        # Lowercase and strip whitespace
        preprocessed_value = value.lower().strip()

        # Preprocess based on language
        if language == "ar":
            preprocessed_value=remove_arabic_text(value)
            preprocessed_value=self.normalize(value, language=language)

        return preprocessed_value

    def calculate_phonetic_similarity(self, field_one:str, field_two:str, language:str='ar', preprocessing=True) -> float:
        """
        Calculate the phonetic similarity between two fields.

        Args:
            field_one (str): The first string to compare.
            field_two (str): The second string to compare.
            language (str, optional): The language for preprocessing. Default is 'ar'.
            preprocessing (bool, optional): Whether to preprocess the fields before comparison. Default is True.
        Returns:
            float: The phonetic similarity score between the two fields.
        """

        # Validate input fields
        if not field_one or not field_two:
            return 0.0

        # Preprocess fields if required
        if preprocessing:
            field_one = self.preprocessing_field(field_one, language=language)
            field_two = self.preprocessing_field(field_two, language=language)

            # If either field is empty after preprocessing, return 0
            if not field_one or not field_two:
                return 0.0

        # Calculate similarity score
        score = similar(field_one, field_two)
        return score
     
    def calculate_deterministic_similarity(self, field_one:str, field_two:str)-> float:

        if field_one ==field_two not in ["",None]:
            similarity_ratio=100 
        else:
            similarity_ratio=0
        return similarity_ratio

    def select_type_of_weight(self, part_type:str, source_country_similar_object:str=None, source_country_source_object:str=None) -> str:
        """
        Select the appropriate type of weight based on source country and part type.

        Args:
            source_country_similar_object (str, optional): The country of the similar object.
            source_country_source_object (str, optional): The country of the source object.
            part_type (str, optional): The type of part ('individual' or 'corporate').

        Returns:
            str: The selected weight type.

        Raises:
            ValueError: If the part type is not recognized or if required parameters are missing.
        """

        function_name = "select_type_of_weight"
        self.logger.debug(f"{function_name} function started", extra={"path": self.path, "endpoint": self.endpoint})

        # Validate part_type input
        if part_type not in ["individual", "corporate"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid part type: {part_type}. Expected 'individual' or 'corporate'."
            )

        # Determine if the weight is local or global
        is_local = False
        if source_country_similar_object is not None and source_country_source_object is not None:
            is_local = source_country_similar_object == source_country_source_object

        # Define mapping for weight types
        weight_mapping = {
            "individual": {
                True: "local_weight",
                False: "global_weight"
            },
            "corporate": {
                True: "cor_local_weight",
                False: "cor_global_weight"
            }
        }

        # Select the appropriate weight type
        weight_type = weight_mapping[part_type][is_local]

        self.logger.info(f"Selected weight type: {weight_type} for part_type: {part_type} with local status: {is_local}",
                        extra={"path": self.path, "endpoint": self.endpoint})

        self.logger.debug(f"/{function_name} function completed", extra={"path": self.path, "endpoint": self.endpoint})
        return weight_type
                              
    ########################################################################################################
    ############################################ Compare Core  #############################################
    ########################################################################################################

    def calculate_overall_weight_for_compare(self, source_object:Dict, results_similarity:Dict, weight_type:str) -> float:
        """
        Calculate the overall weight for comparison based on the similarity of fields between the source object and the results similarity.

        Args:
            source_object (dict): The original object to be compared.
            results_similarity (dict): The results of similarity comparisons.
            weight_type (str): The type of weight to be used in the calculations.

        Returns:
            float: The overall weighted score.
        """
        func_name = "calculate_overall_weight_for_compare"
        self.logger.debug(f"{func_name} function started", extra={"path": self.path, "endpoint": self.endpoint})

        sum_of_weights, sum_of_ratios = 0, 0

        def calculate_field_weight(key, value, index):
            """Helper function to calculate and update field weight and ratios."""
            nonlocal sum_of_weights, sum_of_ratios
            key_info = self.settings[self.settings['field'] == key]

            # Ensure key_info is not empty before accessing its values
            if not key_info.empty and key_info.iloc[0]['weight_calculation']:
                if source_object[index].get(key) not in ["", None, ' ', '']:
                    field_weight = float(key_info.iloc[0][weight_type])
                    field_ratio = value['ratio'] * field_weight
                    sum_of_weights += field_weight
                    sum_of_ratios += field_ratio

                    # Update the results similarity with computed values
                    results_similarity[index][key].update({
                        "weight": field_weight,
                        "field_ratio": field_ratio,
                        "computed": True
                    })

                    # Log information about the calculation
                    self.logger.debug(
                        f"Field: {key}, weight: {field_weight}, ratio: {field_ratio}",
                        extra={"path": self.path, "endpoint": self.endpoint}
                    )
                else:
                    results_similarity[index][key]["computed"] = False
            else:
                results_similarity[index][key]["computed"] = False

        # Iterate through the similarity results and calculate weights
        for index, fields in results_similarity.items():
            for key, value in fields.items():
                if key in source_object.get(index, {}):
                    calculate_field_weight(key, value, index)

        # Calculate the overall weight
        if sum_of_weights == 0:
            overall = 0.0
        else:
            overall = round(sum_of_ratios / sum_of_weights, 1)

        # Log the final summary of weight calculations
        self.logger.info(
            f"Sum of weights: {sum_of_weights}, sum of ratios: {sum_of_ratios}, overall: {overall}",
            extra={"path": self.path, "endpoint": self.endpoint}
        )
        self.logger.debug("=" * 40, extra={"path": self.path, "endpoint": self.endpoint})
        self.logger.debug(f"/{func_name} function completed", extra={"path": self.path, "endpoint": self.endpoint})

        return overall
   
    def compare_similarity_for_two_object (self, source_object:Dict, similar_object:Dict, pre_processing:bool=True, party_type:str='individual')-> Dict:

        """ """
        results_similarity=dict()
        results_similarity["names"]=self.compare_calculate_similarity_between_objects("names",source_object, similar_object, pre_processing=pre_processing)
        results_similarity["parties_country"]=self.compare_calculate_similarity_between_objects("parties_country",source_object, similar_object, pre_processing=pre_processing)
        results_similarity["nationalities"]=self.compare_calculate_similarity_between_objects("nationalities",source_object, similar_object, pre_processing=pre_processing)
        weight_type=self.select_type_of_weight(part_type=party_type)
        results_similarity["over_all_ratio"]=self.calculate_overall_weight_for_compare(
                                                                    results_similarity=results_similarity, 
                                                                    source_object=source_object, 
                                                                    weight_type=weight_type)
        #section_match_ratio=self.calculate_section_match_ratio(new_obj, section_match_ratio)
        #results_similarity["auto_marge"]=self.calculate_auto_marge(source_object, results_similarity)
        return results_similarity

    def compare_calculate_similarity_between_objects(self, index:str, source_object:Dict, similar_object:Dict, pre_processing:bool=True)-> Dict:
        
        """" """
        results_similarity=dict()
        for field in source_object[index].keys():
             
            if field in similar_object[index].keys():
                field_settings=self.settings[self.settings['field']==field]
                field_one_value=source_object[index][field].lower().strip()
                field_two_value=similar_object[index][field].lower().strip()

                if field_settings.iloc[0,:]['search_type']=="phonetics":
                    
                    similarity_ratio=self.calculate_phonetic_similarity(
                                                    field_one=field_one_value, 
                                                    field_two=field_two_value,
                                                    language =field_settings.iloc[0,:]['language'],
                                                    preprocessing=pre_processing
                                                )
                else:
                    similarity_ratio=self.calculate_deterministic_similarity(
                                                                            field_one=field_one_value,
                                                                            field_two=field_two_value,)
                results_similarity[field]={
                    "object_one":source_object[index][field],
                    "object_two":similar_object[index][field],
                    "ratio":similarity_ratio}
            else:
                results_similarity[field]={
                    "object_one":source_object[index][field],
                    "object_two":"",
                    "ratio":0}
                
        return results_similarity
    
    #########################################################################################################
    ################################## Individuals and Corporate Search  ####################################
    #########################################################################################################
    
    def log_customer_details(self, results_similarity:Dict):
        """
        Logs detailed customer-related information from results_similarity data.

        Args:
            results_similarity (dict): A dictionary containing similarity results with key information.
        """
        # Log a separator for clear readability in logs
        self.logger.info("====" * 20, extra={"path": self.path, "endpoint": self.endpoint})
        self.logger.info("Calculate Overall for Customer:", extra={"path": self.path, "endpoint": self.endpoint})
        
        # Safely construct the key details message with default values if keys are missing
        key_details = (
            f"Party Id: {results_similarity.get('keys', {}).get('party_id', 'N/A')} - "
            f"Role: {results_similarity.get('keys', {}).get('role', 'N/A')} - "
            f"Source Country: {results_similarity.get('keys', {}).get('source_country', 'N/A')} - "
            f"Organization: {results_similarity.get('keys', {}).get('organization', 'N/A')} - "
            f"Sequence: {results_similarity.get('keys', {}).get('sequence', 'N/A')}"
        )
        
        # Log the constructed key details
        self.logger.info(key_details, extra={"path": self.path, "endpoint": self.endpoint})

    def calculate_overall_weight_for_search(self, source_object:Dict, results_similarity:Dict, weight_type: str) -> float:
        """
        Calculate the overall weight for search based on the similarity of fields between the source object and the result similarity.

        Args:
            source_object (dict): The original object to be compared.
            results_similarity (dict): The results of similarity comparisons.
            weight_type (str): The type of weight to be used in the calculations.

        Returns:
            float: The overall weighted score.
        """
        func_name = "calculate_overall_weight_for_search"
        self.logger.debug(f"{func_name} function", extra={"path": self.path, "endpoint": self.endpoint})

        sum_of_weights, sum_of_ratios = 0, 0
        self.log_customer_details(results_similarity=results_similarity)
        def process_field(key, value, source_sub_object):
            """Helper function to process a single field and update weights and ratios."""
            nonlocal sum_of_weights, sum_of_ratios

            if key in source_sub_object and source_sub_object[key] not in ["", ' ', None]:
                key_info = self.settings[self.settings['field'] == key]
                if not key_info.empty and key_info.iloc[0]['weight_calculation']:
                    field_weight = float(key_info.iloc[0][weight_type])
                    field_ratio = value['ratio'] * field_weight
                    sum_of_weights += field_weight
                    sum_of_ratios += field_ratio
                    self.logger.debug(f"Field: {key}, weight: {field_weight}, ratio: {field_ratio}",
                                    extra={"path": self.path, "endpoint": self.endpoint})

        try:
            # Process different parts of the similarity results
            for index, similarity_data in results_similarity.items():
                if index in ['names', 'parties', 'parties_country']:
                    for key, value in similarity_data.items():
                        process_field(key, value, source_object[index])

                elif index == "nationalities":
                    if similarity_data not in self.empty_values and source_object[index] not in self.empty_values:
                        for nationality_object in similarity_data:
                            for key, value in nationality_object.items():
                                if nationality_object['nationality']["value"].lower() != "jo" and key not in ["document_number", "document_type"]:
                                    process_field(key, value, nationality_object)


            # Calculate the final weight
            overall_weight = sum_of_ratios / sum_of_weights if sum_of_weights != 0 else 0.0

            self.logger.info(f"sum of ratios: {sum_of_ratios}, sum of weights: {sum_of_weights}, overall weight: {overall_weight}",
                            extra={"path": self.path, "endpoint": self.endpoint})
            
            self.logger.info("===="*20, extra={"path": self.path, "endpoint": self.endpoint})
            self.logger.debug(f"/{func_name} function", extra={"path": self.path, "endpoint": self.endpoint})
            return overall_weight

        except Exception as e:
            self.logger.error(f"An error occurred in {func_name}: {str(e)}", extra={"path": self.path, "endpoint": self.endpoint})
            raise

    def calculate_similarity_objects(self, source_object:Dict, similar_object:Dict, preprocessing=True)-> Dict:
        """
        Calculates the similarity between two objects based on configurable similarity methods for each field.

        Args:
            source_object (dict): A dictionary containing key-value pairs representing the source object.
            similar_object (dict): A dictionary containing key-value pairs representing the object to compare against.
            preprocessing (bool): Flag indicating whether preprocessing should be applied to data before comparison.

        Returns:
            dict: A dictionary containing keys from the similar_object with their similarity ratios and original values.
        """

        func_name = "calculate_similarity_objects"
        results_similarity = {}

        self.logger.debug(f"{func_name} function started", extra={"path": self.path, "endpoint": self.endpoint})
        # Cache field settings to avoid repeated DataFrame access
        
        field_settings = {row['field']: row for index, row in self.settings.iterrows()}

        for key, value in similar_object.items():
            if key in source_object:
                # Get the specific field settings if they exist
                settings = field_settings.get(key, None)

                field_one = source_object[key].lower().strip()
                field_two = value.lower().strip()

                # Determine similarity type from settings
                if settings['search_type'] == "phonetics":
                    similarity_ratio = self.calculate_phonetic_similarity(
                        field_one=field_one, 
                        field_two=field_two,
                        language=settings['language'],
                        preprocessing=preprocessing
                    )
                else:
                    similarity_ratio = self.calculate_deterministic_similarity(
                        field_one=field_one,
                        field_two=field_two
                    )
                results_similarity[key] = {"value": value, "ratio": similarity_ratio}
            else:
                results_similarity[key] = {"value": value, "ratio": 0}
        
        self.logger.debug(f"/{func_name} function started", extra={"path": self.path, "endpoint": self.endpoint})
        return results_similarity

    def calculate_similarity_nationalities_objects(self, source_object:Dict, similar_object:Dict)-> List:
        """
        Calculate similarity scores for each nationality entry between a source object and a similar object,
        based on specified attributes within each nationality.

        Args:
            source_object (dict): Contains nationalities list under the 'nationalities' key.
            similar_object (dict): Contains nationalities list under the 'nationalities' key.
            preprocessing (bool): Flag to indicate whether preprocessing should be applied.

        Returns:
            list: A list of dictionaries, each representing a nationality with its similarity ratio.
        """
        results_similarity = []
        # Only proceed if both nationality lists are available and not empty
        if source_object and similar_object:
            for similar_nat in similar_object:
                for source_nat in source_object:
                    # Compare nationalities based on the 'nationality' key
                    if similar_nat.get('nationality') == source_nat.get('nationality') and similar_nat.get('nationality') != "":
                        similar_obj_nat = {}
                        # Iterate over each key in the similar nationality dictionary
                        for key in similar_nat:
                            if key in source_nat:
                                # Calculate similarity ratio for matching keys
                                value = similar_nat[key]
                                ratio = 100 if value == source_nat[key] and value != "" else 0
                                similar_obj_nat[key] = {"value": value, "ratio": ratio}
                        # Add the calculated nationality data to the results list if not empty
                        if similar_obj_nat:
                            results_similarity.append(similar_obj_nat)
                    else:
                        # Handle non-matching or missing nationality entries
                        continue
        else:
            # Log or handle the case where nationalities are missing or empty in either object
            print("Nationalities data missing or empty in source or similar objects")

        return results_similarity

    def calculate_auto_marge(self, source_object:Dict, similar_object:Dict)-> bool:
        """
        Determines if automatic merging is feasible based on a set of predefined criteria including
        overall similarity ratio, role comparison, nationalities, and parties country checks.

        Args:
            source_object (dict): The source object containing details about an individual.
            similar_object (dict): The similar object to compare against the source.

        Returns:
            bool: True if the objects should be automatically merged, False otherwise.
        """
        # Check overall similarity threshold
        if self.endpoint in ["individuals/search-object", "corporate/search-by-keys"]:
            return None

        if similar_object["over_all_ratio"] < config.BusinessRules.AUTO_MERGE_OVERALL_THRESHOLD:
            return False

        # Check role alignment
        if source_object["role"] != similar_object["keys"]["role"]:
            return False

        # Check nationalities conditions
        if source_object["nationalities"] !=[] or similar_object["nationalities"] !=[]:
            return False

        for sim_nationality in similar_object["nationalities"]:
            for field in ["document_number", "national_number", "document_type"]:
                # Check if field exists and not in empty values and if ratio is not 100%
                if sim_nationality.get(field, None) !="" or sim_nationality.get(field, {}).get("ratio", 0) != 100:
                    return False

        # Check parties country conditions
        if "parties_country" in similar_object:
            if similar_object["parties_country"] in self.empty_values:
                return False

            for field in ["country_of_origin", "date_of_birth"]:
                if similar_object["parties_country"].get(field, None) in self.empty_values:
                    return False
                if similar_object["parties_country"].get(field, {}).get("ratio", 0) != 100:
                    return False

        return True
    
    def collect_keys_info(self, _object:Dict) -> Dict:
        """ Collect essential keys from the similar object. """
        return {key: _object.get(key) for key in ["party_id", "role", "sequence", "source_country", "organization"]}

    def structure_search_results(self, results_similarity:Dict)-> Dict:
        """ Structure the final results based on similarity calculations. """
        return {
            "keys": results_similarity["keys"],
            "object": {
                "names": results_similarity["names"],
                "nationalities": results_similarity["nationalities"],
                "parties_country": results_similarity["parties_country"]
            },
            "over_all_ratio": results_similarity['over_all_ratio'],
            'auto_marge': results_similarity['auto_marge']
        }

    def check_similarity(self, source_object:Dict, similar_object:Dict, pre_processing=True)-> Dict:
        """
        Calculate similarity metrics between two individual profiles, including various subcomponents
        like names, countries, and nationalities, and compute overall weights.

        Args:
            source_object (dict): Dictionary containing the source individual's details.
            similar_object (dict): Dictionary containing the similar individual's details.
            pre_processing (bool): Flag to indicate whether preprocessing should be applied.

        Returns:
            dict: A dictionary containing all similarity results and related metadata.
        """
        func_name="check_similarity"
        results_similarity = {}
        self.logger.debug(f"{func_name} function", extra={"path": self.path, "endpoint": self.endpoint})
        # Safely access and compute similarities for different parts
        try:

            results_similarity = {
                "names": self.calculate_similarity_objects(
                                    source_object.get("names"),
                                    similar_object.get("names"),
                                    preprocessing=pre_processing
                                ),
                "parties_country": self.calculate_similarity_objects(
                                    source_object.get("parties_country"),
                                    similar_object.get("parties_country")
                                ),
                "nationalities": self.calculate_similarity_nationalities_objects(
                                    source_object.get("nationalities"),
                                    similar_object.get("nationalities")
                                ),
                "keys": self.collect_keys_info(similar_object)
            }

            # Calculate weights based on country and part type
            results_similarity['over_all_ratio'] = self.calculate_overall_weight_for_search(
            results_similarity=results_similarity,
            source_object=source_object,
            weight_type=self.select_type_of_weight(
                            source_country_similar_object=similar_object.get("source_country"),
                            source_country_source_object=source_object.get("source_country"),
                            part_type="individual"
                        )
            )
            # Conditionally compute auto merge
            results_similarity["auto_marge"] = self.calculate_auto_marge(source_object, results_similarity)
         
            self.logger.debug(f"/{func_name} function", extra={"path": self.path, "endpoint": self.endpoint})
            return self.structure_search_results(results_similarity=results_similarity)
            
        except KeyError as e:
            # Log the error or handle it as needed
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, 
                detail=f"Key error in individuals check_similarity: {str(e)}"
            )
