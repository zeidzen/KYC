from fastapi import HTTPException, status
from elasticsearch import Elasticsearch ,NotFoundError
from datetime import datetime, timezone
from src.utils.log_service import LogsService
from src.config import config
import json

logger = LogsService.get_logger()

class CrudLogs: 

    """
    CRUD operations for Elasticsearch users index.
    """

    @staticmethod
    def add_to_log (
            es:Elasticsearch,
            headers:dict, 
            status_code: int, 
            endpoint:str, 
            service_type:str,
            process_time:int=None, 
            user_id:str=None, 
            inputs='', 
            output=''):

        """ Add Log to elasticsearch log index """
        func_name, path="add_to_log", "crud/crud_logs"+".add_to_log"
        logger.debug(f"{func_name} function",extra={"path":path,"endpoint":endpoint})
        json.dumps(inputs)
        try:
            obj_log=dict()
            obj_log['init_country']=headers['init-country']
            obj_log['channel_identifier']=headers['channel-identifier']
            obj_log['unique_reference']=headers['unique-reference']
            obj_log["service_type"]=service_type
            obj_log['endpoint']=endpoint
            obj_log['process_time']=process_time
            obj_log['time_stamp']=headers['time-stamp']
            obj_log['user_id']=user_id
            obj_log['status']=status_code
            obj_log['input']=json.dumps(inputs)
            obj_log['output']=json.dumps(output)
            obj_log["created_at"]=datetime.now().strftime(config.INDEXES.DATE_FORMAT)
        except:
            content={"detail":f"Error when create log object in the {endpoint} endpoint."}
            logger.error(content["detail"],extra={"path":path,"endpoint":endpoint})
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=content["detail"])
        try:
            es.index( index=config.INDEXES.LOG_INDEX, body=obj_log)
        except:
            content={"detail":f"Error when add log object to database in the {endpoint} endpoint."}
            logger.error(content["detail"],extra={"path":path,"endpoint":endpoint})
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=content["detail"])

        logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":endpoint})
    