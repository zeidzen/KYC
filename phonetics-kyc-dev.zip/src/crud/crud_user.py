from fastapi import HTTPException, status
from elasticsearch import Elasticsearch, NotFoundError
from src.utils.log_service import LogsService
from src.schemas import User
from src.config import config
from typing import Any

logger = LogsService.get_logger()

class CrudUser: 

    """
    CRUD operations for Elasticsearch users index.
    """


    @staticmethod
    def create_user(es: Elasticsearch, user_data: User) -> Any:
        """
        Create a new user in the Elasticsearch index.

        Args:
            es (Elasticsearch): Elasticsearch client instance.
            user_data (BaseModel): The data of the user to be created, as a Pydantic model.

        Returns:
            dict: Response from Elasticsearch if the user is created successfully.

        Raises:
            ValueError: If a user with the given email already exists.
            Exception: If any other error occurs during the process.
        """
        func_name = "create_user"
        path = "crud/users"
        endpoint = "signup"
        
        logger.debug(f"Entering {func_name}", extra={"path": path, "endpoint": endpoint})
        try:
            # Check if a user with the given email already exists
            if CrudUser.check_user_exists_by_email(es=es, email=user_data.email):
                logger.warning(f"User with email {user_data.email} already exists.", extra={"path": path, "endpoint": endpoint})
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"User with email {user_data.email} already exists."
                )
            
            # Create the user in the Elasticsearch index
            response = es.index(
                index=config.INDEXES.USERS_INDEX,
                id=user_data.user_id,
                document=user_data.__dict__
            )
            
            logger.info(f"User created with ID: {user_data.user_id}", extra={"path": path, "endpoint": endpoint})
            logger.debug(f"Exiting {func_name}", extra={"path": path, "endpoint": endpoint})
            return response
        
        except ValueError as ve:
            error_message = f"A user with the same email already exists. Operation aborted. Details: {ve}"
            logger.error(f"{error_message} in {func_name}", extra={"path": path, "endpoint": endpoint})
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=error_message)
        except Exception as e:
            error_message = f"An unexpected error occurred while performing {func_name}. Please contact support if the issue persists. Details: {e}"
            logger.error(error_message, extra={"path": path, "endpoint": endpoint})
            raise HTTPException( status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=error_message)

    @staticmethod
    def check_user_exists_by_email(es: Elasticsearch, email: str) -> bool:
        """
        Check if a user exists in the Elasticsearch index by email.
        Args:
            es (Elasticsearch): Elasticsearch client instance.
            index_name (str): The name of the Elasticsearch index.
            email (str): The email of the user to check.
        Returns:
            bool: True if the user exists, False otherwise.
        """

        func_name, path, endpoint="check_user_exists_by_email", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})

        try:
            query = {
                "query": {
                    "match": {
                        "email": email
                    }
                }
            }
            response = es.search(index=config.INDEXES.USERS_INDEX, body=query, size=1)
            exists = response["hits"]["total"]["value"] > 0
            logger.info(f"User with email {email} exists: {exists}", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return exists
        except NotFoundError:
            logger.warning(f"Index {config.INDEXES.USERS_INDEX} not found.", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return False
        except Exception as e:
            logger.error(f"Error checking if user exists by email: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )

    @staticmethod
    def check_user_exists_by_user_id(es: Elasticsearch, user_id: str) -> bool:
        """
        Check if a user exists in the Elasticsearch index by user_id.
        Args:
            es (Elasticsearch): Elasticsearch client instance.
            index_name (str): The name of the Elasticsearch index.
            user_id (str): The user_id of the user to check.
        Returns:
            bool: True if the user exists, False otherwise.
        """

        func_name, path, endpoint="check_user_exists_by_email", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})

        try:
            query = {
                "query": {
                    "match": {
                        "user_id": user_id
                    }
                }
            }
            response = es.search(index=config.INDEXES.USERS_INDEX, body=query, size=1)
            exists = response["hits"]["total"]["value"] > 0
            logger.info(f"User with user id {user_id} exists: {exists}", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return exists
        except NotFoundError:
            logger.warning(f"Index {config.INDEXES.USERS_INDEX} not found.", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return False
        except Exception as e:
            logger.error(f"Error checking if user exists by user id: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )
        
    @staticmethod
    def get_by_email(es: Elasticsearch, email: str) -> bool:
        """
        Check if a user exists in the Elasticsearch index by email.
        Args:
            es (Elasticsearch): Elasticsearch client instance.
            email (str): The email of the user to check.
        Returns:
            user data
        """

        func_name, path, endpoint="get_by_email", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})

        try:
            query = {
                "query": {
                    "match": {
                        "email": email
                    }
                }
            }
            response = es.search(index=config.INDEXES.USERS_INDEX, body=query, size=1)
            exists = response["hits"]["total"]["value"] > 0
            logger.info(f"Get user data with email {email}", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return response["hits"]["hits"]
        except NotFoundError:
            logger.warning(f"Index {config.INDEXES.USERS_INDEX} not found.", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return False
        except Exception as e:
            logger.error(f"Error checking if user exists by email: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )
    
    @staticmethod
    def get_by_id(es: Elasticsearch, user_id: str) -> bool:
        """
        Check if a user exists in the Elasticsearch index by email.
        Args:
            es (Elasticsearch): Elasticsearch client instance.
            user_id (str): The user_id of the user to check.
        Returns:
            user data
        """

        func_name, path, endpoint="get_by_id", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})

        try:
            query = {
                "query": {
                    "match": {
                        "user_id": user_id
                    }
                }
            }
            response = es.search(index=config.INDEXES.USERS_INDEX, body=query, size=1)
            exists = response["hits"]["total"]["value"] > 0
            logger.info(f"Get user data with id {user_id}", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return response["hits"]["hits"][0]["_source"]
        except NotFoundError:
            logger.warning(f"Index {config.INDEXES.USERS_INDEX} not found.", extra={"path":path,"endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return False
        except Exception as e:
            logger.error(f"Error checking if user exists by id: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )

    @staticmethod
    def get_users(es:Elasticsearch):
        """
        Retrieve a user by ID.
        Args:
            user_id (str): The ID of the user to retrieve.
        Returns:
            dict: The user data.
        """
        func_name, path, endpoint="get_users", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})
        
        try:

            body={"query":{"match_all":{}}, "size":10000}
            response = es.search( index=config.INDEXES.USERS_INDEX, body=body)
            total_users = response["hits"]["total"]["value"] 
            logger.info(f"Fetching {total_users} users from: {config.INDEXES.USERS_INDEX}")
            data=list()
            for doc in response['hits']['hits']:
                doc['_source']["Id"] =doc['_id']  
                data.append(doc['_source'])

            logger.info(f"Fetching {total_users} users from: {config.INDEXES.USERS_INDEX}")

            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return data
        except Exception as e:
            logger.error(f"Error reading users: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )

    @staticmethod
    def read_user(es:Elasticsearch, user_id: str):
        """
        Retrieve a user by ID.
        Args:
            user_id (str): The ID of the user to retrieve.
        Returns:
            dict: The user data.
        """
        func_name, path, endpoint="read_user", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})
        
        try:
            response = es.get(index=config.INDEXES.USERS_INDEX, id=user_id)
            logger.info(f"User retrieved with ID: {user_id}")

            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return response["_source"]
        except NotFoundError:
            logger.warning(f"User with ID {user_id} not found.")
            return None
        except Exception as e:
            logger.error(f"Error reading user: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )

    @staticmethod
    def search_users(es:Elasticsearch, query: dict):
        """
        Search for users based on a query.
        Args:
            query (dict): Elasticsearch query to filter users.
        Returns:
            list: List of matching users.
        """

        func_name, path, endpoint="search_users", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})

        try:
            response = es.search(index=config.INDEXES.USERS_INDEX, query=query)
            hits = response.get("hits", {}).get("hits", [])
            logger.info(f"Found {len(hits)} users matching query.")

            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return [hit["_source"] for hit in hits]
        except Exception as e:
            logger.error(f"Error searching users: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )

    @staticmethod    
    def update_user(es:Elasticsearch, user_id: str, update_fields: dict):
        """
        Update specific fields of a user.
        Args:
            user_id (str): The ID of the user to update.
            update_fields (dict): The fields to update.
        Returns:
            dict: Response from Elasticsearch.
        """

        func_name, path, endpoint="update_user", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})
        try:
            script = {
                "source": "; ".join([f"ctx._source['{key}'] = params['{key}']" for key in update_fields.keys()]),
                "params": update_fields
            }
            response = es.update(index=config.INDEXES.USERS_INDEX, id=user_id, script=script)
            logger.info(f"User updated with ID: {user_id}")

            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return response
        except NotFoundError:
            logger.warning(f"User with ID {user_id} not found for update.")
            return None
        except Exception as e:
            logger.error(f"Error updating user: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )
    
    @staticmethod   
    def delete_user(es:Elasticsearch, user_id: str):
        """
        Delete a user by ID.
        Args:
            user_id (str): The ID of the user to delete.
        Returns:
            dict: Response from Elasticsearch.
        """
        func_name, path, endpoint="delete_user", "crud/users", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})

        try:
            response = es.delete(index=config.INDEXES.USERS_INDEX, id=user_id)
            logger.info(f"User deleted with ID: {user_id}")
            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return response
        except NotFoundError:
            logger.warning(f"User with ID {user_id} not found for deletion.")
            return None
        except Exception as e:
            logger.error(f"Error deleting user: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An unexpected error occurred. Please contact support if the issue persists."
                )