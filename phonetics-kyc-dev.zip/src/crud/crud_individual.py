from elasticsearch import Elasticsearch, exceptions as es_exceptions
from pandas import DataFrame
from typing import List
from fastapi import HTTPException, status
from src.utils.log_service import LogsService
from src.config import config


logger = LogsService.get_logger()
path="r.v2.ir.s.is.c"
endpoint="CRUD/Individuals"

class CrudIndividual:

    @staticmethod
    def check_if_individual_exists(es: Elasticsearch, keys: dict) -> bool:
        """
        Check if any record exists in an Elasticsearch index that matches the given keys.

        Args:
            es: Elasticsearch client instance.
            index (str): The name of the Elasticsearch index.
            keys (dict): Dictionary of fields and values to search for.

        Returns:
            bool: True if at least one record exists that matches the query, False otherwise.
        """
        func_name="check_if_individual_exists"
        logger.debug(f"{func_name} function", extra={"path":path, "endpoint":endpoint})
        # Building the deterministic must list based on non-empty keys
        must_conditions = [
            {'match': {key: value}} for key, value in keys.items() if value not in ['', [], None, True, False]
        ]

        # Construct and execute the search query
        if must_conditions:
            query = {
                'query': {
                    'bool': {
                        'must': must_conditions
                    }
                }
            }
            result = es.search(index=config.INDEXES.INDIVIDUALS_INDEX, body=query)
            logger.debug(f"/{func_name} function", extra={"path":path, "endpoint":endpoint})
            return not result['hits']['hits'] == list()

        return False  # Return False if there are no valid conditions to search


    @staticmethod
    def get_individual_by_keys(es: Elasticsearch, keys: dict) -> dict:

        """
        Retrieve an individual record from Elasticsearch based on the given keys.

        Args:
            es (Elasticsearch): The Elasticsearch client instance.
            keys (dict): Dictionary containing the fields to search by.
                Required fields: party_id, source_country, role, organization, sequence.

        Returns:
            dict: The individual record if found, otherwise raises HTTPException.
        """
        func_name="get_individual_by_keys"
        logger.debug(f"{func_name} function", extra={"path":path, "endpoint":endpoint})
        try:
            # Build the search query using the five fields
            search_query = {
                "query": {
                    "bool": {
                        "must": [
                            {"match": {"party_id": keys["party_id"]}},
                            {"match": {"source_country": keys["source_country"]}},
                            {"match": {"role": keys["role"]}},
                            {"match": {"organization": keys["organization"]}},
                            {"match": {"sequence": keys["sequence"]}},
                        ]
                    }
                }
            }

            # Search for the document that matches the criteria
            search_result = es.search(index=config.INDEXES.INDIVIDUALS_INDEX, body=search_query)

            if search_result["hits"]["total"]["value"] > 0:
                # Record found, return the document
                logger.debug(f"/{func_name} function", extra={"path":path, "endpoint":endpoint})
                return search_result["hits"]["hits"][0]["_source"]
            else:
                # No matching record found, raise an exception
                logger.warning("No individual record found with the given keys", extra={"path":path, "endpoint":endpoint})
                raise HTTPException(status_code=404, detail="No individual record found with the given keys")

        except es_exceptions.ConnectionError as e:
            logger.error(f"Failed to connect to Elasticsearch: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=503, detail=f"Failed to connect to Elasticsearch: {str(e)}")

        except es_exceptions.TransportError as e:
            logger.error(f"Transport error occurred: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=502, detail=f"Transport error occurred: {str(e)}")

        except es_exceptions.RequestError as e:
            logger.error(f"Request error occurred: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=400, detail=f"Request error occurred: {str(e)}")


    @staticmethod
    def create_new_individual(es: Elasticsearch, record_id: str, record_data: dict) -> dict:
        """
        Create a new record in an Elasticsearch index.

        Args:
            es (Elasticsearch): The Elasticsearch client instance.
            record_id (str): The unique identifier for the record.
            record_data (dict): The data of the record to be added.

        Returns:
            dict: A dictionary with the status detail of the operation.
        """
        func_name="create_new_individual"
        logger.debug(f"{func_name} function", extra={"path":path, "endpoint":endpoint})
        try:
            # Index the document
            result = es.index(index=config.INDEXES.INDIVIDUALS_INDEX, id=record_id, body=record_data)

            if result.get('result') == 'created':
                logger.debug(f"/{func_name} function", extra={"path":path, "endpoint":endpoint})
                return {"detail": "Individual record created successfully"}
            else:
                logger.error("Failed to create individual record", extra={"path":path, "endpoint":endpoint})
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to create individual record")

        except es_exceptions.ConnectionError as e:
            logger.error(f"Failed to connect to Elasticsearch: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=f"Failed to connect to Elasticsearch: {str(e)}")

        except es_exceptions.TransportError as e:
            logger.error(f"Transport error occurred: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=f"Transport error occurred: {str(e)}")

        except es_exceptions.RequestError as e:
            logger.error(f"Request error occurred: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Request error occurred: {str(e)}")


    @staticmethod
    def update_individual(es: Elasticsearch, updated_data: dict) -> dict:
        """
        Update an existing record in an Elasticsearch index or create it if it does not exist.

        Args:
            es (Elasticsearch): The Elasticsearch client instance.
            record_id (str): The unique identifier for the record.
            updated_data (dict): The data to update the record with.

        Returns:
            dict: A dictionary with the status detail of the operation.
        """

        func_name="update_individual"
        logger.debug(f"{func_name} function", extra={"path":path, "endpoint":endpoint})
        
        try:
            # Record exists, proceed to update

            individual_record = CrudIndividual.get_individual_by_keys(es, updated_data)
            result = es.update(
                index=config.INDEXES.INDIVIDUALS_INDEX, 
                id=individual_record["customer_id"], 
                body={"doc": updated_data}
            )

            if result.get('result') == 'updated':
                logger.debug(f"/{func_name} function", extra={"path":path, "endpoint":endpoint})
                return {"detail": "Individual record updated successfully"}
            else:
                logger.error(f"Failed to update individual record", extra={"path":path, "endpoint":endpoint})
                raise HTTPException(status_code=500, detail="Failed to update individual record")

        except es_exceptions.ConnectionError as e:
            logger.error(f"Failed to connect to Elasticsearch: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=503, detail=f"Failed to connect to Elasticsearch: {str(e)}")

        except es_exceptions.TransportError as e:
            logger.error(f"Transport error occurred: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=502, detail=f"Transport error occurred: {str(e)}")

        except es_exceptions.RequestError as e:
            logger.error(f"Request error occurred: {e}", extra={"path":path, "endpoint":endpoint})
            raise HTTPException(status_code=400, detail=f"Request error occurred: {str(e)}")


    @staticmethod
    def find_similar_individual(es:Elasticsearch, settings: DataFrame, name_object: dict, party_id_not_in: List[str] = None) -> dict:
        
        """
        Generate an Elasticsearch query for searching similar individuals based on the 'name' fields.

        Args:
            settings (DataFrame): Settings that define search types for different fields.
            name_object (dict): The main object containing 'name' fields for phonetic or deterministic searches.
            party_id_not_in (list, optional): List of party IDs to be excluded from the search.

        Returns:
            dict: The Elasticsearch query.
        """
        func_name = "find_similar_individual"
        logger.debug(f"{func_name} function started", extra={"path": "path", "endpoint": "endpoint"})

        # Initialize lists for different query types
        phonetics_must_list, phonetics_should_list = [], []
        deterministic_must_not_list = []

        # Initialize the base query
        query = {
            "query": {
                "bool": {
                    "must": [],
                    "should": [],
                    "must_not": []
                }
            }
        }

        # Handle party_id exclusion filter if provided
        if party_id_not_in:
            deterministic_must_not_list.append({"terms": {"party_id": party_id_not_in}})

        # Process the "names" fields from the input object
        for key, value in name_object.items():

            if value !="" and key in ["first_name_ar","first_name_en","last_name_ar","last_name_en","full_name_ar","full_name_en"]:
                key_info = settings[settings['field'] == key]

                if key_info.empty:
                    logger.error(f"Settings not found for field: {key}", extra={"path": "path", "endpoint": "endpoint"})
                    continue

                # Check for phonetic or deterministic search
                if key_info.iloc[0]["search_type"] == "phonetics":
                    match = {"match": {f"names.{key}": {"query": value, "fuzziness": "AUTO", "operator": "and"}}}

                    # Handle special cases for full_name fields
                    if key in ['full_name_ar', 'full_name_en']:
                        # Add to should list only if first and last name fields are empty
                        if all(name_object.get(name_key) != "" for name_key in ['first_name_ar', 'first_name_en', 'last_name_ar','last_name_en']):
                            phonetics_should_list.append(match)
                    else:
                        phonetics_must_list.append(match)

        # Construct the query with must, should, and must_not clauses
        if phonetics_must_list:
            query['query']['bool']['must'].extend(phonetics_must_list)

        if phonetics_should_list:
            query['query']['bool']['should'].extend(phonetics_should_list)

        if deterministic_must_not_list:
            query['query']['bool']['must_not'].extend(deterministic_must_not_list)

            # Search for the document that matches the criteria
        try:
            search_result = es.search(index=config.INDEXES.INDIVIDUALS_INDEX, body=query)

            total_similar_individuals = search_result.get("hits", {}).get("total", {}).get("value", 0)
            logger.info(f"Total of Similar Individuals: {total_similar_individuals}", extra={"path": "path", "endpoint": "endpoint"})
            logger.debug(f"{func_name} function", extra={"path": "path", "endpoint": "endpoint"})

            results=list()
            if total_similar_individuals > 0:
                hits = search_result.get("hits", {}).get("hits", [])
                results = [hit["_source"] for hit in hits if "_source" in hit]

            return results
        except Exception as e:
            logger.error(f"Error executing search query: {str(e)}", extra={"path": "path", "endpoint": "endpoint"})
            raise HTTPException(status_code=500, detail="An error occurred while executing the search query.")
