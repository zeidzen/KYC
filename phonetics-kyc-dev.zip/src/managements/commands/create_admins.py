import uuid
from datetime import datetime, timezone
from pydantic import ValidationError
from termcolor import colored
from src.database import create_connection
from src.crud.crud_user import CrudUser
from src.schemas import User
from src.utils.password import secure_pwd

# Assume logging and database handling are simplified and included here
import logging

# Setting up basic logging for the example
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Function to prompt for user input and validate it using the AdminUser model
def get_admin_information(attempts: int = 3):
    """
    Collect admin information with a maximum number of attempts for validation.
    
    Args:
        attempts (int): Maximum number of attempts allowed for entering valid data.

    Returns:
        User: Validated admin user information or None if validation fails.
    """
    logger.info("Collecting admin information.")
    for attempt in range(attempts):
        try:
            print(f"Attempt {attempt + 1} of {attempts}")
            user_data = {
                "name": input("Enter your Name: "),
                "email": input("Enter your Email: "),
                "password": input("Enter your Password: "),
                "user_id": str(uuid.uuid4()),
                "is_admin": True,
                "created_at": datetime.now(timezone.utc)
            }
            User.validate_password(user_data["password"])
            user_data["password"]=secure_pwd(user_data["password"])
            admin_user = User(**user_data)
            logger.info(f"Admin information validated successfully for: {admin_user.email}")
            return admin_user
        except ValidationError as e:
            print(colored(f"Invalid input: {e}", 'red'))
            logger.warning(f"Validation error: {e}. Attempts remaining: {attempts - attempt - 1}")
    
    logger.error("Exceeded maximum attempts for entering valid admin information.")
    print(colored("You have exceeded the maximum number of attempts. Please try again later.", 'red'))
    return None

def create_admin():
    """
    Create an admin user after collecting and validating admin information.
    """
    logger.info("Starting admin creation process.")
    admin_user = get_admin_information()
    if admin_user:
        confirm = input("Are you sure you want to create this Admin? (y/n): ").lower()
        if confirm in ['y', 'yes']:
            es = create_connection()
            CrudUser.create_user(es=es, user_data=admin_user)
            print(colored(f"Admin created successfully: {admin_user.email}", 'green'))
        else:
            logger.info("Admin creation cancelled by the user.")
            print(colored("Admin creation cancelled.", 'yellow'))
    else:
        print(colored("Admin creation failed due to invalid input.", 'red'))
