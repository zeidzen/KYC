from src.config import config
from termcolor import colored
import time
from src.database import *
#from .create_admins import create_admin


def build_project():

    # Create an Elasticsearch client
    print(">> Create Connection. . .", end=" ")
    es_client =create_connection()
    print(colored("Done", 'green'))

    # Index creation request
    indexes_setup=[
    (config.INDEXES.USERS_INDEX, users_schema),
    (config.INDEXES.INDIVIDUALS_INDEX, individuals_schema),
    (config.INDEXES.SIMILAR_INDIVIDUALS_INDEX, similar_individuals_schema),
    (config.INDEXES.CORPORATE_INDEX, corporate_schema),
    (config.INDEXES.PREPROCESSING_INDEX, similar_corporate_schema),
    (config.INDEXES.LOG_INDEX, log_schema),
    (config.INDEXES.SETTINGS_INDEX, settings_schema),
    ]


    print(">> Create Indexes . . .")
    for index, setting in indexes_setup:
        try:
            print(index, ":", end=" ")
            response=es_client.indices.create(index=index, body=setting)
            print(colored("Done", 'green'))
        except:
            print(colored("The {} index already exists.".format(index), 'red'))

    print("-----" * 10)

    print(">> Setup Default Settings . . .")
    # Default Settings
    print(colored("Please wait, this process may take up to 2 minutes.", 'yellow'))
    response=es_client.count(index=config.INDEXES.SETTINGS_INDEX)
    is_empty=response['count'] ==0
    if is_empty:
        for row_id, document in enumerate(default_settings):
            time.sleep(0.3)
            es_client.index(index=config.INDEXES.SETTINGS_INDEX, body=document)
            
        print("Default Settings:",colored("Done", 'green'))
    else:
        print(colored(f"The index <{config.INDEXES.SETTINGS_INDEX}> is not empty.", 'red'))  
        
    # Preprocessing
    response = es_client.count(index=config.INDEXES.PREPROCESSING_INDEX)
    is_empty=response['count'] ==0

    if is_empty:
        for row_id, document in enumerate(default_preprocessing):
            time.sleep(0.5)
            es_client.index(index=config.INDEXES.PREPROCESSING_INDEX, body=document)
        print("Default Preprocessing:",colored("Done", 'green'))
    else:
        print(colored(f"The index <{config.INDEXES.PREPROCESSING_INDEX}> is not empty.", 'red'))  


    # print("-----" * 10)
    # while True:
    #     response = input("Do you want to create an admin? (yes/no): ").strip().lower()
    #     if response in ['yes', 'y']:
    #         from .create_admins import create_admin
    #         create_admin()
    #         break  # Exit the loop after creating the admin
    #     elif response in ['no', 'n']:
    #         print("Admin creation skipped.")
    #         break  # Exit the loop if the user chooses not to create an admin
    #     else:
    #         print("Invalid input. Please enter 'yes' or 'no'.")


    print(">> Close Connection. . .", end=" ")
    close_connection(es_client)
    print(colored("Done".format(index), 'green'))
