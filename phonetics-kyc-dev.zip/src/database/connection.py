from elasticsearch import Elasticsearch
from src.config import config
#from src.services import LogsService

#logger = LogsService.get_logger()
endpoint =""

def create__bank_connection():
    """ Create a connection with Elasticsearch based on the environment and credentials. """
    func_name = "create_connection"
    path = f".{func_name}"

    #logger.debug(f"{func_name} function", extra={"path": path,"endpoint":endpoint})

    try:

        elastic_url = f"{config.ELASTICSEARCH.SCHEME}://{config.ELASTICSEARCH.HOST}:{config.ELASTICSEARCH.PORT}"
        es = Elasticsearch(
            [elastic_url],
            http_auth=(config.ELASTICSEARCH_USERNAME, config.ELASTICSEARCH_PASSWORD)
        )
        if es.ping():
            #logger.debug(f"Connection established in {func_name}", extra={"path": path,"endpoint":endpoint})
            #logger.debug(f"/{func_name} function", extra={"path": path,"endpoint":endpoint})
            return es
        else:
            #logger.critical("Elasticsearch connection failed", extra={"path": path,"endpoint":endpoint})
            raise Exception("ElasticSearch connection failed")
    except Exception as e:
        #logger.critical("Failed to create Elasticsearch connection", extra={"path": path,"endpoint":endpoint})
        raise Exception(f"ElasticSearch connection failed: {e}")

def create_connection():
    """
    Establish a connection to Elasticsearch based on the provided environment and credentials.
    
    Returns:
        Elasticsearch: An Elasticsearch client instance if the connection is successful.
    
    Raises:
        Exception: If the connection to Elasticsearch fails.
    """
    func_name = "create_connection"
    path = f".{func_name}"

    # Log the start of the connection process
    # logger.debug(f"Starting {func_name}", extra={"path": path})
    API_KEY = "LVc5dkU1UUJzdDNadm0zd2QxTVY6VVY4MVNvOVFTTFdta01SM0VpeV9xZw=="
    ELASTICSEARCH_HOST="https://fa2b785296b2487f8f886f66c04768d9.us-central1.gcp.cloud.es.io"
    ELASTICSEARCH_PORT = 9200
    SCHEME = "https"

    es = Elasticsearch(
        cloud_id="a5ebe9d1c48143ad816d6e62dfdadf2c:dXMtY2VudHJhbDEuZ2NwLmNsb3VkLmVzLmlvOjQ0MyRkMjE1N2M4MDQ2MzA0YTlkYmFlNWU1YTcwZGU2ZDgwNyQyZDJmODY4NzUxMDY0NzY1OWUyMzY3NDY1MzAyY2U5OA==",
        api_key=API_KEY,
    )

    # Test the connection
    if es.ping():
        # Connection successful
        # logger.debug(f"Connection established successfully in {func_name}", extra={"path": path})
        return es
    else:
        # Connection failed
        # logger.critical(f"Elasticsearch connection failed in {func_name}", extra={"path": path})
        raise Exception("ElasticSearch connection failed")

def close_connection(es):
    """ Close the Elasticsearch connection. """
    func_name = "close_connection"
    path = f"Path_to_{func_name}"

    #logger.debug(f"Calling {func_name} function", extra={"path": path,"endpoint":endpoint})

    try:
        es.close()
        #logger.debug(f"Connection closed in {func_name}", extra={"path": path,"endpoint":endpoint})
    except Exception as e:
        #logger.critical("Failed to close Elasticsearch connection", extra={"path": path,"endpoint":endpoint})
        raise Exception(f"Connection close failed: {e}")

def get_db():
    es = create_connection()
    return es