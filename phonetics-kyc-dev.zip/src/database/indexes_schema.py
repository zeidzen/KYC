# Individuals Index Schema and mappings
individuals_schema = {
    "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 0
    },
    "mappings": {
        "properties": {
            "customer_id": {"type": "keyword"},
            "party_id": {"type": "keyword"},
            "source_country": {"type": "keyword"},
            "role": {"type": "keyword"},
            "organization": {"type": "keyword"},
            "sequence": {"type": "keyword"},
			"is_searchable": {"type": "boolean"},
			"is_deleted": {"type": "boolean"},
			"created_at":{"type":"date", },
			"updated_at":{"type":"date"},
            
            # Nested name object
            "names": {
                "type": "object",
                "properties": {
					# Arabic Fields
                    "first_name_ar": {"type": "text"},
                    "second_name_ar": {"type": "text"},
                    "third_name_ar": {"type": "text"},
                    "last_name_ar": {"type": "text"},
                    "full_name_ar": {"type": "text"},
                    "short_name_ar": {"type": "text"},
                    "mother_name_ar": {"type": "text"},
					
					# English Fields
                    "first_name_en": {"type": "text"},
                    "second_name_en": {"type": "text"},
                    "third_name_en": {"type": "text"},
                    "last_name_en": {"type": "text"},
                    "full_name_en": {"type": "text"},
                    "short_name_en": {"type": "text"},
                    "mother_name_en": {"type": "text"}
                }
            },
            
            # Nationalities as an array of objects
            "nationalities": {
                "type": "nested",
                "properties": {
                    "nationality": {"type": "keyword"},
                    "national_number": {"type": "text"},
                    "document_type": {"type": "text"},
                    "document_number": {"type": "text"}
                }
            },
            
            # Parties country as an object
            "parties_country": {
                "type": "object",
                "properties": {
					"date_of_birth": {"type": "text"},
                    "place_of_birth": {"type": "keyword"},
					"country_of_origin": {"type": "text"}
                }
            }
        }
    }
}

# Similar Individuals Index Schema and mappings
similar_individuals_schema = {
    "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 0
    },
    "mappings": {
        "properties": {
            "customer_id": {"type": "keyword"},
            "similarity_ratio": {"type": "float"},
            "created_at": {"type": "date", "format": "strict_date_optional_time||epoch_millis"},
            "updated_at": {"type": "date", "format": "strict_date_optional_time||epoch_millis"},
            
            # Similar object structure
            "similar_object": {
                "type": "object",
                "properties": {
                    "keys_customer_id_left": {
                        "type": "object",
                        "properties": {
                            "party_id": {"type": "keyword"},
                            "source_country": {"type": "keyword"},
                            "role": {"type": "keyword"},
                            "organization": {"type": "keyword"},
                            "sequence": {"type": "keyword"}
                        }
                    },
                    "keys_customer_id_right": {
                        "type": "object",
                        "properties": {
                            "party_id": {"type": "keyword"},
                            "source_country": {"type": "keyword"},
                            "role": {"type": "keyword"},
                            "organization": {"type": "keyword"},
                            "sequence": {"type": "keyword"}
                        }
                    },
                    "object": {
                        "type": "object",
                        "properties": {
                            # Name fields
                            "name": {
                                "type": "object",
                                "properties": {
                                    "first_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "second_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "third_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "last_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "full_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "short_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "mother_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "first_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "second_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "third_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "last_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "full_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "short_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "mother_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    }
                                }
                            },
                            # Nationalities as an array of objects
                            "nationalities": {
                                "type": "nested",
                                "properties": {
                                    "nationality": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "national_number": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "document_type": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "document_number": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    }
                                }
                            },
                            # Parties country fields
                            "parties_country": {
                                "type": "object",
                                "properties": {
                                    "date_of_birth": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "place_of_birth": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "country_of_origin": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

# corporate Index Schema and mappings
corporate_schema = {
    "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 0
    },
    "mappings": {
        "properties": {
            "customer_id": {"type": "keyword"},
            "party_id": {"type": "keyword"},
            "source_country": {"type": "keyword"},
            "role": {"type": "keyword"},
            "organization": {"type": "keyword"},
            "sequence": {"type": "keyword"},
			"company_type":{"type":"keyword"},
			"is_searchable": {"type": "boolean"},
			"is_deleted": {"type": "boolean"},
			"created_at":{"type":"date", },
			"updated_at":{"type":"date"},
            
            # Nested name object
            "name": {
                "type": "object",
                "properties": {
					# Arabic Fields

                    "full_name_ar": {"type": "text"},
					"cor_full_name_ar": {"type": "text"},
                    "short_name_ar": {"type": "text"},
					"commercial_name_ar": {"type": "text"},
					
					
					
					# English Fields

                    "full_name_en": {"type": "text"},
					"cor_full_name_en": {"type": "text"},
                    "short_name_en": {"type": "text"},
					"commercial_name_en": {"type": "text"},
					
                }
            },
            
            # Nationalities as an array of objects
            "nationalities": {
                "type": "nested",
                "properties": {
                    "nationality": {"type": "keyword"},
                    "national_number": {"type": "text"},
                }
            },
            
            # Parties country as an object
            "parties_country": {
                "type": "object",
                "properties": {
					"country_of_origin": {"type": "keyword"},
					"country_of_registration": {"type": "keyword"},
					"registration_number": {"type": "keyword"},
					"license_profession_number": {"type": "keyword"},
					"tax_identification_number": {"type": "keyword"}
                }
            }
        }
    }
}

# Similar corporate Index Schema and mappings
similar_corporate_schema = {
    "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 0
    },
    "mappings": {
        "properties": {
            "customer_id": {"type": "keyword"},
            "similarity_ratio": {"type": "float"},  # Changed from `decimal` to `float` for Elasticsearch compatibility
            "created_at": {"type": "date", "format": "strict_date_optional_time||epoch_millis"},
            "updated_at": {"type": "date", "format": "strict_date_optional_time||epoch_millis"},
            
            # Similar object structure
            "similar_object": {
                "type": "object",
                "properties": {
                    "keys_customer_id_left": {
                        "type": "object",
                        "properties": {
                            "party_id": {"type": "keyword"},
                            "source_country": {"type": "keyword"},
                            "role": {"type": "keyword"},
                            "organization": {"type": "keyword"},
                            "sequence": {"type": "keyword"}
                        }
                    },
                    "keys_customer_id_right": {
                        "type": "object",
                        "properties": {
                            "party_id": {"type": "keyword"},
                            "source_country": {"type": "keyword"},
                            "role": {"type": "keyword"},
                            "organization": {"type": "keyword"},
                            "sequence": {"type": "keyword"}
                        }
                    },
                    "object": {
                        "type": "object",
                        "properties": {
                            # Name fields
                            "name": {
                                "type": "object",
                                "properties": {
                                    "full_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "cor_full_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "short_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "commercial_name_ar": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "full_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "cor_full_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "short_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "commercial_name_en": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    }
                                }
                            },
                            # Nationalities as an array of objects
                            "nationalities": {
                                "type": "nested",
                                "properties": {
                                    "nationality": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "national_number": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    }
                                }
                            },
                            # Parties country fields
                            "parties_country": {
                                "type": "object",
                                "properties": {
                                    "country_of_origin": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "country_of_registration": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "registration_number": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "license_profession_number": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    },
                                    "tax_identification_number": {
                                        "type": "object",
                                        "properties": {
                                            "value": {"type": "keyword"},
                                            "ratio": {"type": "float"}
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

# Users Index Schema and mappings
users_schema={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "user_id":{"type":"keyword"},
            "name":{"type":"keyword"},
            "email":{"type":"keyword"},
            "password":{"type":"text"},
            "is_admin":{"type":"boolean",},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
        }
    }
}

# FeedBack Index Schema and mappings
log_schema={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "init_country":{"type":"keyword"},
            "channel_identifier":{"type":"keyword"},
            "unique_reference":{"type":"keyword"},
            "time_stamp":{"type":"text"},
            "system_type":{"type":"keyword"},
            "endpoint":{"type":"keyword"},
            "process_time":{"type":"float"},
            "user_id":{"type":"text"},
            "status":{"type":"integer"},
            "input":{"type":"text"},
            "output":{"type":"text"},
            "primary_id":{"type":"keyword"},
            "created_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
        }
    }
}

# Preprocessing Index settings and mappings
Preprocessing_schema={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "language":{"type":"keyword"},
            "character":{"type":"text"},
            "replace_to":{"type":"text"},
            "created_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"}
        }
    }
}

# Index settings and mappings
settings_schema={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "field":{"type":"keyword"},
            "index":{"type":"keyword"},
            "service_type":{"type":"keyword"},
            "language":{"type":"keyword"},
            "cor_local_weight":{"type":"float"},
            "cor_global_weight":{"type":"float"},
            "local_weight":{"type":"float"},
            "global_weight":{"type":"float"},
            "search_type":{"type":"keyword"},
            "preprocessing":{"type":"boolean"},
            "keys":{"type":"boolean"},
            "weight_calculation":{"type":"boolean"},
            "return_with_result":{"type":"boolean"},
            "created_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
        }
    }
}






















""" 

# Parties Index settings and mappings
parties_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text"},
            "party_type":{"type":"keyword"},
            "is_deleted":{"type":"boolean", },
            "is_searchable":{"type":"boolean", },
            "company_type":{"type":"text"},
            "created_at":{"type":"date", },
            "updated_at":{"type":"date"}
        }
    }
}

# Names Index settings and mappings
names_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text", },
            "party_type":{"type":"keyword", },
            "source_country":{"type":"keyword", },
            "role":{"type":"keyword", },
            "sequence":{"type":"keyword", },
            "organization":{"type":"keyword", },
            "party_type":{"type":"keyword"},
            "first_name_ar":{"type":"text"},
            "second_name_ar":{"type":"text"},
            "third_name_ar":{"type":"text"},
            "last_name_ar":{"type":"text"},
            "full_name_ar":{"type":"text"},
            "short_name_ar":{"type":"text"},
            "mother_name_ar":{"type":"text"},
            "first_name_en":{"type":"text"},
            "second_name_en":{"type":"text"},
            "third_name_en":{"type":"text"},
            "last_name_en":{"type":"text"},
            "full_name_en":{"type":"text"},
            "short_name_en":{"type":"text"},
            "mother_name_en":{"type":"text"},
            "commercial_name_ar":{"type":"text"},
            "commercial_name_en":{"type":"text"},
            "cor_full_name_en":{"type":"text"},
            "cor_full_name_ar":{"type":"text"},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"}
        }
    }
}

# Nationalities Index settings and mappings
nationalities_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text", },
            "source_country":{"type":"keyword", },
            "role":{"type":"keyword", },
            "sequence":{"type":"keyword", },
            "organization":{"type":"keyword", },
            "nationality":{"type":"keyword"},
            "national_number":{"type":"text"},
            "document_type":{"type":"text"},
            "document_number":{"type":"text"},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"}
        }
    }
}

# Nationalities Index settings and mappings
parties_country_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text", },
            "source_country":{"type":"keyword", },
            "role":{"type":"keyword", },
            "sequence":{"type":"keyword", },
            "organization":{"type":"keyword", },
            "place_of_birth":{"type":"keyword"},
            "date_of_birth":{"type":"text"},
            "country_of_origin":{"type":"text"},
            "country_of_incorporation":{"type":"text"},
            "registration_number":{"type":"text"},
            "tax_identification_number": {"type": "text"},
            "country_of_registration":{"type":"text"},
            "license_profession_number":{"type":"text"},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis" },
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"}
        }
    }
}




"""