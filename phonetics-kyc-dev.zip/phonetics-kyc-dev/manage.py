import multiprocessing
import uvicorn.config
from yaml import safe_load, YAMLError
import argparse
from src.managements import create_admin, run_test, build_project
from src.config import config

# Set the worker class to Uvicorn's worker
worker_class = "uvicorn.workers.UvicornWorker"

# Load the YAML configuration for logging 
def load_logging_config(path):
    try:
        with open(path, 'r') as file:
            config_text = file.read()
            config_text = config_text.replace("${LOGS_DATE_FORMAT}", config.APP_LOG_LEVEL)
            # Application.log
            config_text =config_text.replace("${APP_LOG_LEVEL}", config.APP_LOG_LEVEL)
            config_text = config_text.replace("${APP_LOG_FORMAT}", config.APP_LOG_FORMAT)
            config_text = config_text.replace("${APP_LOG_LOC}", config.APP_LOG_LOC)

            # Access.log
            config_text = config_text.replace("${ACCESS_LOG_LEVEL}", config.ACCESS_LOG_LEVEL)
            config_text = config_text.replace("${ACCESS_LOG_FORMAT}", config.ACCESS_LOG_FORMAT)
            config_text = config_text.replace("${ACCESS_LOG_LOC}", config.ACCESS_LOG_LOC)
            
            return safe_load(config_text)
        
    except FileNotFoundError:
        print(f"Logging configuration file {path} not found")
    except YAMLError as e:
        print(f"Error parsing YAML file {path}: {e}")
    return None

def main():

    # Create an argument parser
    parser = argparse.ArgumentParser(description="Run server tasks")

    # Define subcommands
    parser.add_argument(
        "command",
        choices=["create_admin", "build_project", "run_test", "run_server"],
        help="The command to run (run_server, create_admin, build_project, run_test)"
    )

    # Parse the command-line arguments
    args = parser.parse_args()

    if args.command == "create_admin":
        create_admin()

    elif args.command == "build_project":
        build_project()
    
    elif args.command == "run_test":
        run_test()

    elif args.command == "run_server":

        # Set the number of workers dynamically based on CPU count
        num_workers = multiprocessing.cpu_count() * 4 + 1
        config_path="/data/phonetics/kyc/src/config/log_config.yaml"
        logging_config = load_logging_config(config_path)
        print(f"Starting server with {num_workers} workers on port {config.PORT}.")
        uvicorn.run(
            "main:app", 
            host=config.HOST, 
            port=config.PORT, 
            workers=num_workers, 
            #lifespan="on",
            log_config=logging_config
        )


if __name__ == "__main__":
    main()
