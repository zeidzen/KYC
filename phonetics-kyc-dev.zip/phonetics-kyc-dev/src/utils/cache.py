from src.config import config
import io 
import redis
import pandas as pd

# Redis client step
redis_client = redis.Redis(host=config.REDIS_HOST, port=config.REDIS_PORT, db=0)

def get_cache(cache_key: str) -> pd.DataFrame:
    # Check if the DataFrame is cached
    cached_data = redis_client.get(cache_key)
    if cached_data:
        csv_buffer = io.StringIO(cached_data.decode('utf-8'))
        # Convert the cached CSV string back to DataFrame
        df = pd.read_csv(csv_buffer)
        return df
    return pd.DataFrame()

def update_cache(cache_key: str, data: pd.DataFrame):
   # Store the DataFrame as a CSV string in cache
   redis_client.set(cache_key, data.to_csv(index=False), ex=config.REDIS_TIME_TO_LIVE)
   return data

def remove_cache_keys(*cache_keys):
   """
   Function to remove one or more keys from the Redis cache.
   Args:
       cache_keys: One or more cache keys (strings) to be removed.
   Returns:
       Number of keys that were removed.
   """
   removed_count = redis_client.delete(*cache_keys)  # Can delete multiple keys at once
   return removed_count
