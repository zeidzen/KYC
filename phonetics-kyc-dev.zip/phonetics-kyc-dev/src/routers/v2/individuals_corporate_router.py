from fastapi import APIRouter, Request, Depends
from fastapi.responses import JSONResponse

from src.services.individuals_corporate_services import individuals_corporate_Operations
from src.utils import get_current_user
from src.schemas.individuals import DefaultResponse, MainKeys, Checksum

# Create an API router
Ind_Cor_Router=APIRouter(prefix="/api/v2/individuals_corporate", tags=["api_v2", "Individuals And Corporate"])
    
@Ind_Cor_Router.post('/checksum/', response_model=Checksum)
async def checksum(data:MainKeys, request:Request, current_user:str=Depends(get_current_user))-> JSONResponse:
        
    """This Endpoint for collect data related one object in database in calculate the checksum."""
    # Read Data and Create Connection
    obj_Operations=individuals_corporate_Operations(endpoint="checksum", public_id=current_user)
    # Apply CheckSum Procedure
    content, status_code=obj_Operations.checksum_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)


@Ind_Cor_Router.delete('/flag-delete/{party_id}', response_model=DefaultResponse)
async def set_delete_flag(party_id:str, request:Request, current_user:str=Depends(get_current_user))-> JSONResponse:
    
    """ This Endpoint for delete the objects as a Flag delete."""
    # Read Data and Create Connection
    obj_Operations=individuals_corporate_Operations(endpoint="flag delete", public_id=current_user)
    # Apply Delete Flag Procedure
    content, status_code=obj_Operations.delete_procedure(
                                                headers=dict(request.headers), 
                                                party_id=party_id)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

   
@Ind_Cor_Router.delete('/delete-flagged-deleted/{party_id}', response_model=DefaultResponse)
async def delete_flagged_deleted(party_id:str, request:Request, current_user:str=Depends(get_current_user))-> JSONResponse:

    """ This Endpoint for physical flagged delete based on party id."""
    # Read Data and Create Connection
    obj_Operations=individuals_corporate_Operations(endpoint="delete flagged deleted", public_id=current_user)
    # Apply Delete Flagged Physically Procedure
    content, status_code=obj_Operations.physical_flag_deleted_procedure(
                                                            headers=dict(request.headers), 
                                                            party_id=party_id)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)
   

@Ind_Cor_Router.delete('/physical-delete-by-keys/', response_model=DefaultResponse)
async def physical_delete_based_keys(data:MainKeys, request:Request, current_user:str=Depends(get_current_user))-> JSONResponse:
    
    """ This Endpoint for physical delete based on primary keys."""
    # Read Data and Create Connection
    obj_Operations=individuals_corporate_Operations(endpoint="physical delete by keys", public_id=current_user)
    # Apply Physical Delete Based Keys Procedure
    content, status_code=obj_Operations.physical_delete_by_keys_procedure(
                                                        headers=dict(request.headers), 
                                                        data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)
