from fastapi import APIRouter, Request, Depends
from fastapi.responses import JSONResponse
from src.database import get_db
from src.services.auth_services import Auth_Services
from src.utils import get_current_user
from src.schemas.authentication import Signup, Login, LoginResponse
from src.schemas.user import ChangePassword, UsersResponse, DefaultResponse


# Create an API router
AuthenticationRouter=APIRouter(prefix="/api/v2/auth", tags=["api_v2"])

@AuthenticationRouter.post('/signup/',response_model=DefaultResponse, tags=["Authentication"])
async def create_user(data:Signup, request:Request, es= Depends(get_db))-> JSONResponse:

    """ This Endpoint for Get All Users Have Access to phonetics system."""
    # Read Data and Create Connection
    service_obj=Auth_Services(endpoint="signup", es=es)
    # Apply Signup Procedure
    content, status_code=service_obj.signup_procedure(
                                                headers=dict(request.headers), 
                                                data=data.__dict__)
    # Create Response  
    return JSONResponse(status_code=status_code, content=content)


# route for login user in 
@AuthenticationRouter.post('/login', response_model=LoginResponse, tags=["Authentication"])
async def login(data:Login, request:Request, es= Depends(get_db))-> JSONResponse:
    
    # Read Data and Create Connection
    service_obj=Auth_Services(endpoint="login", es=es)
    # Apply Login Procedure
    content, status_code=service_obj.login_procedure(
                                            data=data.__dict__, 
                                            headers=dict(request.headers))

    # Create Response  
    return JSONResponse(status_code=status_code, content=content) 
   

@AuthenticationRouter.get('/users', tags=["User"], response_model=UsersResponse)
async def get_all_users(request:Request, es= Depends(get_db), current_user:str=Depends(get_current_user))-> JSONResponse:

    """ This Endpoint for Get All Users Have Access to phonetics system."""
    # 1.Read Data and Create Connection
    service_obj=Auth_Services(endpoint="users", es=es)
    # Apply Get All Users Procedure
    content, status_code=service_obj.get_all_users_procedure(
                                                    headers=dict(request.headers),
                                                    public_id=current_user)
    # Create Response
    return JSONResponse(content=content, status_code=status_code)
        

@AuthenticationRouter.post('/change_pass/', response_model=DefaultResponse, tags=["Authentication"])
async def change_password(data:ChangePassword, request:Request, es= Depends(get_db), current_user:str=Depends(get_current_user))-> JSONResponse:
    
    """ This Endpoint for Change Password to exists user have access to phonetics system."""
    # Read Data and Create Connection
    service_obj=Auth_Services(endpoint="change_pass", es=es)
    # Apply Change Password Procedure
    content, status_code=service_obj.change_password_procedure(
                                            headers=dict(request.headers),
                                            data=data.__dict__,current_user=current_user)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

