from fastapi import APIRouter, Request, Depends, Header
from fastapi.responses import JSONResponse
from src.database import get_db
from src.services import Individuals_Services
from src.utils import get_current_user
from src.schemas.individuals import (
                        IndividualAdd, 
                        DefaultResponse,
                        IndividualUpdate,
                        IndividualCompare,
                        IndSearch_by_object,
                        IndividualCompareResponse,
                        IndividualSearchResponse,
                        Search_by_keys
                    )

# Create an API router
IndividualsRouter=APIRouter(prefix="/api/v2/individuals", tags=["api_v2", "Individuals"])

@IndividualsRouter.post('/add/', response_model=DefaultResponse)
async def individuals_add(
                    data:IndividualAdd, 
                    request:Request, 
                    Init_Country:str=Header(None), 
                    current_user:str=Depends(get_current_user),
                    es= Depends(get_db)
                )-> JSONResponse:
    
    """ This Endpoint for add customer to elasticsearch database."""
    # Read Data and Create Connection
    service_obj=Individuals_Services(es=es, endpoint="add", public_id=current_user)
    # Apply Add Individual Procedure
    content, status_code=service_obj.add_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@IndividualsRouter.put('/update/{party_id}', response_model=DefaultResponse)
async def individuals_update(
                        party_id:str, 
                        data:IndividualUpdate, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db),
                    )-> JSONResponse:
        
    """ This Endpoint for add and update customer to elasticsearch database."""
    # Read Data and Create Connection
    service_obj=Individuals_Services(es=es, endpoint="update", public_id=current_user)
    # Apply Individual Update Procedure
    content, status_code=service_obj.update_procedure(
                                                headers=dict(request.headers), 
                                                data=data, party_id=party_id)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@IndividualsRouter.post('/compare/',response_model=IndividualCompareResponse)
async def individuals_compare (
                    data:IndividualCompare, 
                    request:Request, 
                    current_user:str=Depends(get_current_user),
                    es= Depends(get_db)
                    
                )-> JSONResponse:
    
    """ This Endpoint for compare between two objects Based on Business rules of individuals users."""
    # Read Data and Create Connection
    service_obj=Individuals_Services(es=es, endpoint="compare", public_id=current_user)
    # Apply Individual Compare Procedure
    content, status_code=service_obj.compare_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@IndividualsRouter.post('/search-keys/', response_model=IndividualSearchResponse)
async def individuals_search_by_keys(
                            data:Search_by_keys, 
                            request:Request, 
                            current_user:str=Depends(get_current_user),
                            es= Depends(get_db)
                        )-> JSONResponse: 
    
    """This Endpoint for Search about individuals objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only"""
    # Read Data and Create Connection
    service_obj=Individuals_Services(es=es, endpoint="search_keys", public_id=current_user)
    # Apply Individuals Search By Keys Procedure
    content, status_code=service_obj.search_by_keys_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)
    
@IndividualsRouter.post('/search-object/', response_model=IndividualSearchResponse)
async def individuals_search_by_object(
                                data:IndSearch_by_object, 
                                request:Request, 
                                current_user:str=Depends(get_current_user),
                                es= Depends(get_db)
                            )-> JSONResponse: 
    
    """This Endpoint for Search about individuals objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only"""
    # Read Data and Create Connection
    service_obj=Individuals_Services(es=es,endpoint="search_object", public_id=current_user)
    # Apply Individuals Search By Object Procedure
    content, status_code=service_obj.search_by_object_procedure(
                                                    headers=dict(request.headers), 
                                                    data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)
