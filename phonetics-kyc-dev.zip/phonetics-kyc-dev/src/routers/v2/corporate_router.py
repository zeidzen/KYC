from fastapi import APIRouter, Request, Depends, Header
from fastapi.responses import JSONResponse
from src.services import Corporate_Services
from src.database import get_db
from src.utils.helpers import get_current_user
from src.schemas.base import MyHeader
from src.schemas.corporate import (
                            CorporateAdd,
                            CorporateUpdate, 
                            CorporateSearchByKeys, 
                            DefaultResponse,
                            CorporateCompare,
                            CorporateCompareResponse,
                            CorporateSearchByKeysByObjects,
                            SearchResponse
                        )

# Create an API router
CorporateRouter=APIRouter(prefix="/api/v2/corporate", tags=["api_v2", "Corporate"])

@CorporateRouter.post('/add/', response_model=DefaultResponse)
async def add_corporate(
    data:CorporateAdd, 
    request:Request, 
    current_user:str=Depends(get_current_user),
    es= Depends(get_db)
    #headers:MyHeader=Depends(common_header_dependency)
    
    )-> JSONResponse:

    """ This Endpoint for Add a new corporate to the elasticsearch database. """
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="add", public_id=current_user)
    # Start add corporate procedure
    content, status_code =service_obj.add_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

@CorporateRouter.put('/update/{party_id}', response_model=DefaultResponse)
async def update_corporate(
                        party_id:str, 
                        data:CorporateUpdate, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db)
                        )-> JSONResponse:
     
    """This Endpoint for Add and Update a new corporate to the elasticsearch database."""

    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="update", public_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.update_procedure(headers=dict(request.headers), data=data, party_id=party_id)
    # Return Response  
    return JSONResponse(content=content, status_code=status_code)

@CorporateRouter.post('/search-keys/', response_model=SearchResponse)
async def search_by_keys_corporate(
                        data:CorporateSearchByKeys, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db)
                        )-> JSONResponse:
    
    """This Endpoint for Search about corporate objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only."""
    
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="search-by-object", public_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.search_by_keys_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content,status_code=status_code)
 
@CorporateRouter.post('/search-object/', response_model=SearchResponse)
async def search_by_object_corporate(
                        data:CorporateSearchByKeysByObjects, 
                        request:Request, 
                        current_user:str=Depends(get_current_user),
                        es= Depends(get_db)
                        )-> JSONResponse:
    
    """This Endpoint for Search about corporate objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only."""
    
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="search-by-keys", public_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.search_by_object_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content,status_code=status_code)

@CorporateRouter.post('/compare/', response_model=CorporateCompareResponse)
async def compare_corporate(
                    data:CorporateCompare, 
                    request:Request, 
                    current_user:str=Depends(get_current_user),
                    es= Depends(get_db)
                )-> JSONResponse:
    
    """ This Endpoint for compare between two objects Based on Business rules of corporate users."""
   
    # Read Data and Create Connection
    service_obj=Corporate_Services(es=es, endpoint="compare", public_id=current_user)
    # Start add corporate procedure
    content, status_code=service_obj.compare_procedure(headers=dict(request.headers), data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)

