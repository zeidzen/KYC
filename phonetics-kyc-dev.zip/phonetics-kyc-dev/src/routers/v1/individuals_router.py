from fastapi import APIRouter, Request, Depends, Header
from fastapi.responses import JSONResponse
from src.services import Individuals_Services
from src.utils import get_current_user
from src.schemas.individuals import IndividualV1SearchRequest, IndividualSearchResponse

# Create an API router
IndividualsRouter=APIRouter(prefix="/api/v1/individuals", tags=["api_v1", "Individuals"])


@IndividualsRouter.post('/search/', response_model=IndividualSearchResponse)
async def individuals_search(data:IndividualV1SearchRequest, request:Request, current_user:str=Depends(get_current_user))-> JSONResponse: 
    
    """This Endpoint for Search about individuals objects related source object in the elasticsearch database. 
        this function allow search based on primary keys only"""
    # Read Data and Create Connection
    obj_Operations=Individuals_Services(endpoint="individuals_object_search", public_id=current_user)
    # Apply Individuals Search By Object Procedure
    content, status_code=obj_Operations.search_procedure(
                                                    headers=dict(request.headers), 
                                                    data=data)
    # Create Response  
    return JSONResponse(content=content, status_code=status_code)