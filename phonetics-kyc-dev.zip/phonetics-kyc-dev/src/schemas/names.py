from pydantic import BaseModel, Field, field_validator
from src.schemas.base import CompResField, ResultsSearchField
from typing import Optional

class CorName(BaseModel):
    full_name_ar:Optional[str] 
    full_name_en:Optional[str] 
    commercial_name_ar:Optional[str] 
    commercial_name_en:Optional[str] 
    cor_full_name_en:Optional[str] 
    cor_full_name_ar:Optional[str] 
    short_name_ar:Optional[str] 
    short_name_en:Optional[str] 
    
    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value
    
class IndName(BaseModel):
    first_name_ar:Optional[str] 
    first_name_en:Optional[str] 
    second_name_ar:Optional[str] 
    second_name_en:Optional[str] 
    third_name_ar:Optional[str] 
    third_name_en:Optional[str] 
    last_name_ar:Optional[str] 
    last_name_en:Optional[str] 
    full_name_ar:Optional[str] 
    full_name_en:Optional[str] 
    short_name_ar:Optional[str] 
    short_name_en:Optional[str] 
    mother_name_ar:Optional[str] 
    mother_name_en:Optional[str] 

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value
    
# Individual Response Search Names Fields
class IndCompReqNameFields(BaseModel):
    first_name_ar:CompResField
    first_name_en:CompResField
    second_name_ar:CompResField
    second_name_en:CompResField
    third_name_ar:CompResField
    third_name_en:CompResField
    last_name_ar:CompResField
    last_name_en:CompResField
    full_name_ar:CompResField
    full_name_en:CompResField
    short_name_ar:CompResField
    short_name_en:CompResField
    mother_name_ar:CompResField
    mother_name_en:CompResField

# Individual Response Search Names Fields
class IndResSearchNamesFields(BaseModel):
    first_name_ar:ResultsSearchField
    first_name_en:ResultsSearchField
    second_name_ar:ResultsSearchField
    second_name_en:ResultsSearchField
    third_name_ar:ResultsSearchField
    third_name_en:ResultsSearchField
    last_name_ar:ResultsSearchField
    last_name_en:ResultsSearchField
    full_name_ar:ResultsSearchField
    full_name_en:ResultsSearchField
    short_name_ar:ResultsSearchField
    short_name_en:ResultsSearchField
    mother_name_ar:ResultsSearchField
    mother_name_en:ResultsSearchField
    
# CheckSum   
class ChecksumName(BaseModel):
    object:IndName
    checksum:str

class ChecksumNameObject(BaseModel):
    objects:ChecksumName
    checksum:str
    
# Corporate Response Name Fields

class CorResponseNameFields(BaseModel):
    commercial_name_ar:ResultsSearchField
    commercial_name_en:ResultsSearchField
    cor_full_name_ar:ResultsSearchField
    cor_full_name_en:ResultsSearchField
    full_name_ar:ResultsSearchField
    full_name_en:ResultsSearchField
    short_name_ar:ResultsSearchField
    short_name_en:ResultsSearchField


class CorCompResponseNameFields(BaseModel):
    commercial_name_ar:CompResField
    commercial_name_en:CompResField
    cor_full_name_ar:CompResField
    cor_full_name_en:CompResField
    full_name_ar:CompResField
    full_name_en:CompResField
    short_name_ar:CompResField
    short_name_en:CompResField