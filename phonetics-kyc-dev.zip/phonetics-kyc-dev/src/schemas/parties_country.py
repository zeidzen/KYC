from pydantic import BaseModel, Field, field_validator
from src.schemas.base import CompResField, ResultsSearchField
from typing import Optional

# Individual Parties Country Object
class IndPartiesCountry(BaseModel):
    place_of_birth:Optional[str] 
    date_of_birth:Optional[str] 
    country_of_origin:Optional[str] 

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value

# Individual Compare Parties Country Fields
class IndCompResPartiesCountryFields(BaseModel):
    place_of_birth:Optional[str] 
    date_of_birth:Optional[str] 
    country_of_origin:Optional[str] 

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value

# Individual Response Search Parties Country Fields
class IndResultsSearchPartiesCountryFields(BaseModel):
    place_of_birth:ResultsSearchField
    date_of_birth:ResultsSearchField
    country_of_origin:ResultsSearchField

# Checksum
class ChecksumPartiesCountry(BaseModel):
    object:IndPartiesCountry
    checksum:str
    
class ChecksumPartiesCountryObject(BaseModel):
    objects:list[ChecksumPartiesCountry]
    checksum:str
     
# Corporate Parties Country Object
class CorPartiesCountry(BaseModel):
    country_of_origin:Optional[str] 
    registration_number:Optional[str] 
    tax_identification_number:Optional[str] 
    country_of_registration:Optional[str] 
    license_profession_number:Optional[str]  

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value
    
# Corporate Response Parties Country Fields     
class CorCompResPartiesCountryFields(BaseModel):
    country_of_origin:CompResField
    registration_number:CompResField
    tax_identification_number:CompResField
    license_profession_number:CompResField
    country_of_registration:CompResField

class CorResPartiesCountryFields(BaseModel):
    country_of_origin:ResultsSearchField
    registration_number:ResultsSearchField
    tax_identification_number:ResultsSearchField
    license_profession_number:ResultsSearchField
    country_of_registration:ResultsSearchField