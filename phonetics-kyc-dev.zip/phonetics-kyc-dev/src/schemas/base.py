from pydantic import BaseModel, Field

class MyHeader(BaseModel):
    Init_Country:str
    Channel_Identifier:str
    Unique_Reference:str
    Time_Stamp:str


class CompResField(BaseModel):
    object_one:str
    object_two:str
    ratio:float
    
class ResultsSearchField(BaseModel):
    value:str
    ratio:int

class CompareParameters(BaseModel):
    pre_processing:bool
    
## Search by object
class Search_by_object_Parameters(BaseModel):
    source_country:str
    size:int
    pre_processing:bool
    party_id_not_in:list[str]