from pydantic import BaseModel, Field, field_validator
from src.schemas.base import CompResField, ResultsSearchField
from typing import Optional

# Individual Nationality Object     
class IndNationality(BaseModel):
    document_number:Optional[str] 
    document_type:Optional[str] 
    national_number:Optional[str] 
    nationality:Optional[str] 

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value
    
# Individual Compare Response Nationality Fields  
class IndCompResNationalityFields(BaseModel):
    document_number:CompResField
    document_type:CompResField
    national_number:CompResField
    nationality:CompResField

# Individual Search Response Nationality Fields      
class IndResultsSearchNationalityFields(BaseModel):
    document_number:ResultsSearchField
    document_type:ResultsSearchField
    national_number:ResultsSearchField
    nationality:ResultsSearchField
    
# Checksum    
class ChecksumNationality(BaseModel):
    object:IndNationality
    checksum:str
    
class ChecksumNationalitiesObject(BaseModel):
    objects:list[ChecksumNationality]
    checksum:str    
    
# Corporate Nationality Object     
class CorNationality(BaseModel):
    national_number:Optional[str] 
    nationality:Optional[str] 

    @field_validator("*",mode="before")
    def convert_empty_string_to_none(cls, value):
        if value  == None:
            return ""
        return value

# Corporate Response Nationality Fields     
class CorCompResponseNationalitiesFields(BaseModel):
    national_number:CompResField
    nationality:CompResField
    

class CorResponseNationalitiesFields(BaseModel):
    national_number:ResultsSearchField
    nationality:ResultsSearchField