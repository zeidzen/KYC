from pydantic import BaseModel, Field, EmailStr  

class User(BaseModel):
    public_id:str
    name:str
    email:EmailStr=Field(min_length=5, description="User's email address")
    
class ChangePassword(BaseModel):
    public_id:str
    password:str=Field(min_length=8)
    
class UsersResponse (BaseModel):
    users:list[User]
    
class DefaultResponse(BaseModel):
    detail:str