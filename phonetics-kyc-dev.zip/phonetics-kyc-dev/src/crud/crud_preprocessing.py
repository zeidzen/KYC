from elasticsearch import Elasticsearch ,NotFoundError
from datetime import datetime, timezone
from src.services import LogsService
from src.config import config

logger = LogsService.get_logger()

class CrudPreprocessing:

    @staticmethod
    def get_preprocessing(es:Elasticsearch):
        """
        Retrieve a user by ID.
        Args:
            user_id (str): The ID of the user to retrieve.
        Returns:
            dict: The user data.
        """
        func_name, path, endpoint="get_preprocessing", "crud/preprocessing", ""
        logger.debug(f"{func_name} function",extra={"path":path, "endpoint":endpoint})
        
        try:

            body={"query":{"match_all":{}}, "size":10000}
            response = es.search( index=config.PREPROCESSING_INDEX, body=body)
            total_users = response["hits"]["total"]["value"] 
            logger.info(f"Fetching {total_users} users from: {config.USERS_INDEX}")
            data=list()
            for doc in response['hits']['hits']:
                doc['_source']["Id"] =doc['_id']  
                data.append(doc['_source'])

            logger.debug(f"/{func_name} function",extra={"path":path, "endpoint":endpoint})
            return data
        except Exception as e:
            logger.error(f"Error reading users: {e}")
            raise