from fastapi import status, HTTPException
from datetime import datetime
from src.database import create_connection
from src.services import LogsService
from src.config import config

logger = LogsService.get_logger()
                           
class CrudBase:
        
    ################################################################################################################
    ######################################## Elasticsearch Operations  #############################################
    ################################################################################################################
    @staticmethod
    def generate_query_based_keys (index:str, fields:dict)-> dict:
        func_name, path="generate_query_based_keys","base_crud."+"generate_query_based_keys"
        logger.debug(f"{func_name} function",extra={"path":path,"endpoint":""})
        # lists
        deterministic_must_list, query =list(), dict()
        query['query']=dict()
        query['query']['bool']={"must":[],"filter":[],"should":[],"must_not":[]}
        for key, value in fields.items():
            if value=='' or value==[]:
                continue 
            term={"match":dict()} 
            term ["match"][key] ={'query':value} 
            deterministic_must_list.append(term)
        # Deterministic List
        if deterministic_must_list !=[]:
            query['query']['bool']['must'].append({"bool":{"must":deterministic_must_list}})
        logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
        return query

    @staticmethod
    def add_row (es, index:str, _object:dict, created_at=datetime.now().strftime(config.DATE_FORMAT))-> str:
        func_name, path="add_row", ""
        logger.debug(f"{func_name} function",extra={"path":path,"endpoint":""})
        _object["created_at"]=created_at
        output = es.index( index=index, body=_object)
        output={'detail':'the process of adding done successfully'}
        logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
        return output

    @staticmethod
    def update_row_using_elastic_id (es, index:str, Id:str, _object:dict):
        func_name="update_row_using_elastic_id"
        path="base_crud"+func_name
        logger.debug(f"{func_name} function",extra={"path":path,"endpoint":""})
        elastic_id=Id 
        es.update( index=index, id=elastic_id, body={ "doc":_object })            
        output={'status':True,'detail':'object is updated'}
        logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
        return output
    @staticmethod
    def update_row (es, index:str, keys:dict, _object:dict):
        
        """ Update record in the database based on Keys of the index. """
        func_name, path="update_row", "base_crud."+"update_row"
        logger.debug(f"{func_name} function",extra={"path":path,"endpoint":""})
        query=CrudBase.generate_query_based_keys ( index=index ,fields=keys)
        result_search=es.search( index=index, body=query)['hits']['hits']
        if result_search ==[]:
            CrudBase.add_row(index=index, _object=_object)
            logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
            return { "status":True, 'detail':'the process of adding done successfully'}

        elastic_id=result_search[0]['_id']
        _object["updated_at"]
        result=es.update(index=index, id=elastic_id, body={"doc":_object})            
        output={"status":True,'detail':f'{index}:object is updated'}
        logger.warning(output["detail"],extra={"path":path,"endpoint":""})
        logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
        return output

    def delete_row (es, index:str, Id:str ):
        func_name, path="delete_row","crud_base."+"delete_row"
        logger.debug(f"{func_name} function",extra={"path":path,"endpoint":""})
        elastic_id=Id 
        try:
            es.delete(index=index,id=elastic_id)
            output={ "status":True,'detail':'the process of deleting successfully'}
            return output
        except:
            output={ "status":False,'detail':'Id is not found.'}
            logger.warning(output["detail"],extra={"path":self.path+"delete_row","endpoint":""})
            logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
            return output
        
    @staticmethod
    def check_keys_is_found ( es, index, keys):
        """ This function will Check if the record is exists or not based on Primer Keys
      (Party ID, Organization, Role, Source Country, and Sequence)
        """  
        func_name, path="check_keys_is_found", "base_crud."+"check_keys_is_found"
        logger.debug(f"{func_name} function",extra={"path":path,"endpoint":""})
        query=CrudBase.generate_query_based_keys(index=index ,fields=keys)
        result_search = es.search( index=index, body=query)['hits']['hits']
        if result_search ==[]:
            output=False 
        else:
            output=True 
            created_at=result_search[0]["_source"]["created_at"]
        logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
        return output


    
    @staticmethod
    def Search_using_party_id (es, settings_file, parameters:dict, system_type ="")-> list:
        
            func_name, path="Search_using_party_id","crud_base"+"Search_using_party_id"
            logger.debug(f"{func_name} function",extra={"path":path,"endpoint":""})

            if system_type=="corporate":
                indexes_list=["parties",'names','parties_country','nationalities']
            else:
                indexes_list=['names','parties_country','nationalities'] 

            data=dict()
            for index in indexes_list:
                if index =="parties":
                    fields={"party_id":parameters['party_id']}
                else:
                    fields=parameters
                query=CrudBase.generate_query_based_keys (index=config.INDEX_MAP[index], fields=fields)
                result=es.search(index=config.INDEX_MAP[index], body=query)
                items=dict()
                settings=settings_file[ (settings_file['index'] ==config.INDEX_MAP[index])& ( settings_file['keys']==False)]
                if  result["hits"]["hits"] !=list()and index !="nationalities":
                    for ind ,  row in settings.iterrows():
                        if row['field'] in result["hits"]["hits"][0]['_source'].keys()and row['field'] !="party_id" :
                            items[row['field']]=result["hits"]["hits"][0]['_source'][row['field']]
                    data[index]=items
                elif index =="nationalities":
                    nal=list()
                    for obj in result["hits"]["hits"]:
                        items=dict()
                        for ind ,  row in settings.iterrows():
                            if row['field'] in obj['_source'].keys()and row['field'] !="party_id" :
                                items[row['field']]=obj['_source'][row['field']]
                        nal.append(items)
                    data[index]=nal
                else:
                    data[index]=dict()
                    continue
            if data['names'] ==dict():
                detail="party id is not found in names index."
                logger.warning(detail,extra={"path":path,"endpoint":""})
                logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
                return None 
            
            else:
                logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":""})
                return data 
    @staticmethod
    def get_source_data_based_on_parameters(es, settings_file, parameters):
        
        """
        Get Data from Elasticsearch if case the request has all parameters information (search by party id)
        if the party id is found this function will be return source_obj['object'] with data  
        else will be return source_obj['object'] with None
        """
        source_obj=dict()
        for key, value in parameters.items():
            if parameters[key]  ==None:
                parameters[key]=''
        source_obj['keys']=parameters.copy()
        # del source_obj['keys']['party_id_not_in']
        if ( 
            parameters['party_id'] !='' and 
            parameters['role'] !='' and 
            parameters['sequence'] !='' and 
            parameters['source_country'] !='' and 
            parameters['organization'] !='' ):

            _object=CrudBase.Search_using_party_id(es=es, settings_file=settings_file,parameters=parameters)

            if _object ==None:
                content ={'detail':"Party ID does not found."}
                logger.warning(content["detail"],extra={"path":"base_crud","endpoint":""})           
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
            
            source_obj['object']=_object
            output, status_code ={"status":True, 'data':source_obj}, status.HTTP_200_OK
        else:
            content ={'detail':'Party ID is not found in names.'}
            logger.warning(content["detail"],extra={"path":"base_crud","endpoint":""})           
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
        return output, status_code
    
    @staticmethod
    def search_by_primary_key(es, index_name, primary_key):
        """
        Search for a document by a custom primary key field using a term query.
        :param index_name: Name of the index to search
        :param field_value: Value of the field to search for
        :return: The first matching document if found, otherwise None
        """
        try:
            # Perform a term query to find the document by the custom primary key
            response = es.search(
                index=index_name,
                body={
                    "query": {
                        "term": {
                            "primary_id": primary_key
                        }
                    }
                }
            )
            return response['hits']['hits']
        except Exception as e:
            print(f"An error occurred: {e}")
            return None