from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    
    # ---------- Project Information ----------
    APP_NAME:str = "Phonetics-KYC"
    APP_DESCRIPTION:str
    APP_VERSION: str
    # ---------- Elastic-Search Config ----------
    ELASTICSEARCH_HOST:str
    ELASTICSEARCH_PORT:int = 9200
    ELASTICSEARCH_USERNAME:str = "elastic"
    ELASTICSEARCH_PASSWORD:str
    SCHEME:str = "https"

    # ---------- FastAPI Config ----------
    HOST:str = "0.0.0.0"
    PORT:int = "8889"
    DEBUG:bool = True
    VERSION:str = "2"

    # ------------- REDIS Config ----------------
    REDIS_HOST:str ="localhost"
    REDIS_PORT:int =6379
    REDIS_TIME_TO_LIVE:int =86400

    # ------------- Nexus Server ---------------------
    NEXUS_SERVER:str ="10.101.18.33"
    NEXUS_PORT:int =8081

    # ---------- Admin Config ----------
    ADMIN_NAME:str
    ADMIN_EMAIL:str
    ADMIN_PASSWORD:str
    IS_ADMIN:bool

    # ---------- Token Information ----------
    ALGORITHM:str = "HS256"
    ## ACCESS
    ACCESS_TOKEN_EXPIRE_MINUTES:int = 1
    ACCESS_TOKEN_EXPIRE_HOURS:int = 12
    ACCESS_SECRET_KEY:str
    ## REFRESH    
    REFRESH_TOKEN_EXPIRE_MINUTES:int
    REFRESH_TOKEN_EXPIRE_HOURS:int
    REFRESH_SECRET_KE:str

    # ---------- OVERALL THRESHOLDs ----------
    OVERALL_THRESHOLD:float = 70
    AUTO_MARGE_OVERALL_THRESHOLD:float = 95

    # ---------- LOG Settings ----------
    MAX_BYTES:int = 10000
    BACKUP_COUNT:int = 10
    LOGS_DATE_FORMAT:str

    ## Application Log 
    APP_LOG_FORMAT:str = "DEBUG"
    APP_LOG_LEVEL:str
    APP_LOG_LOC:str
    APP_HANDLERS:list[str]
    ## Access Log
    ACCESS_LOG_FORMAT:str
    ACCESS_LOG_LEVEL:str
    ACCESS_LOG_LOC:str
    ACCESS_HANDLERS:list[str]

    # ---------- Indexes ----------
    DATE_FORMAT:str = "%Y-%m-%d:%H:%M:%S"
    USERS_INDEX:str
    NAMES_INDEX:str
    NATIONALITIES_INDEX:str
    PARTIES_INDEX:str
    PARTIES_COUNTRY_INDEX:str
    FEEDBACK_INDEX:str
    PREPROCESSING_INDEX:str
    SETTINGS_INDEX:str
    LOG_INDEX:str


    class Config:
        env_file= Path(Path(__file__).resolve().parent) / "/data/phonetics/kyc/.env"

    @property
    def ADMIN(self):
        
        return {
                "name":self.ADMIN_NAME, 
                "email":self.ADMIN_EMAIL.lower().strip(),
                "password":self.ADMIN_PASSWORD,
                "is_admin":self.IS_ADMIN
            }

    @property
    def INDEX_MAP(self):
        
        return {
                'names':self.NAMES_INDEX,
                'nationalities':self.NATIONALITIES_INDEX,
                'parties':self.PARTIES_INDEX,
                'parties_country':self.PARTIES_COUNTRY_INDEX,
            }

config= Settings()

