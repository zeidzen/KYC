from fastapi import status, HTTPException
from datetime import datetime
import json
import pandas as pd
import operator
import uuid
from . import LogsService
from src.crud import CrudSettings, CrudBase, CrudPreprocessing, CrudUser
from src.utils import get_cache, update_cache
from src.config import config

class BaseService:#(CrudBase):

    def __init__(self,es ,service_type='system',endpoint="",path=""):
        
        # System Type
        self.es=es
        self.service_type=service_type
        self.endpoint=endpoint
        self.org_path="bs.BS."
        self.path=path + self.org_path
        self.logger = LogsService.get_logger()
        
        # Read Setting Information 
        self.settings_file= get_cache(cache_key=f"phonetics_settings_{self.service_type}")
        if self.settings_file.empty or True: 
            self.settings_file=self.read_setting_data(service_type=self.service_type)
            self.settings_file=pd.DataFrame(self.settings_file)
            update_cache(cache_key=f"phonetics_settings_{self.service_type}", data=self.settings_file)
            self.logger.debug(f"Phonetics settings updated in the cache",extra={"path":path,"endpoint":self.endpoint})

        # Read User 
        self.users=get_cache(cache_key="phonetics_users")
        if self.users.empty or True:
            self.users=CrudUser.get_users(es=self.es)
            self.users=pd.DataFrame(self.users)
            update_cache(cache_key=f"phonetics_users", data=self.users)
            self.logger.debug(f"Phonetics Users updated in the cache",extra={"path":path,"endpoint":self.endpoint})

        if self.endpoint=="update":
            self.add_type="add"
        
    ################################################################################################################
    ################################################ Basic Operations  #############################################
    ################################################################################################################
    
    def read_normalize_data(self,):
        # Read Normalize Data
        normalize_data = CrudPreprocessing.get_preprocessing(es=self.es)
        normalize_data=pd.DataFrame(normalize_data)
        normalize_data=normalize_data.fillna("")
        return normalize_data
    
    def read_setting_data (self, service_type):
        
        " Read Setting information from ElasticSearch index"

        func_name, path="read_setting_data", self.path+"read_setting_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Get Setting Information (index_settings)

        settings_file=CrudSettings.get_settings(es=self.es)
        settings_file=pd.DataFrame(settings_file)
        if service_type =="corporate":
            settings_file=settings_file[settings_file["service_type"]!="individuals"]
            settings_file["local_weight"]=settings_file["cor_local_weight"]
            settings_file["global_weight"]=settings_file["cor_global_weight"]
        elif service_type =="individuals":
            settings_file=settings_file[settings_file["service_type"]!="corporate"]

        cleanup={
            "pre_processing":{'TRUE':True, "FALSE":False},
            "keys":{'TRUE':True, "FALSE":False},
            "weight_calculation":{'TRUE':True, "FALSE":False},
            "status":{'TRUE':True, "FALSE":False},
            "return_with_result":{'TRUE':True, "FALSE":False},
        }
        settings_file=settings_file.replace(cleanup)
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return settings_file

    def read_user_data(self,):
        
        """ Read User Information for check authentication """
        
        func_name="read_user_data"
        path=self.path+func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Read Users 
        users=pd.DataFrame( self.get_all_data_from_index(config.USERS_INDEX))
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return users

    def get_parties_data(self, party_id, party_type="corporate"):

        """ Get Party ID Data form Parties Index and check if Party Id is deleted or searchable."""

        func_name, path="get_parties_data", self.path+"get_parties_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        _, _object="parties",{"party_id":party_id}        
        settings=self.settings_file[self.settings_file['index']==config.PARTIES_INDEX] 
        
        query= CrudBase.generate_query_based_keys(index=config.PARTIES_INDEX, fields=_object)
        result_index =self.es.search(index=config.PARTIES_INDEX, body=query)
        if result_index["hits"]["hits"] !=[]:
            data=result_index["hits"]["hits"][0]['_source']
            for ind ,  row  in settings.iterrows():
                    if row['field'] not in data.keys():
                        data[row['field']] =''
            if data["is_searchable"] and not data["is_deleted"] and (
                data["party_type"]==self.service_type or self.endpoint=="checksum"):
                output={"status":True, "data":data}
            else:
                output={"status":False, "detail":f"party id:{party_id} is deleted or unsearchable.", "status_code":400}
                self.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
        else:
            output={"status":False, "detail":f"parties Id:{party_id} is not found.", "status_code":400}
            self.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output

    
    ################################################################################################################
    ######################################### Add and Update Operations  ###########################################
    ################################################################################################################

    def prepare_parties_data (self, objects, party_type):
        
        """ This function will prepare parties data for parties index""" 
        func_name, path="prepare_parties_data", self.path+"prepare_parties_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        parties_data =dict()
        print(objects)
        parties_data['party_id']=objects['party_id']
        parties_data['party_type']=party_type
        parties_data['is_searchable']=objects['is_searchable']
        parties_data['is_deleted']=objects['is_deleted']
        if party_type =="corporate":
            parties_data['company_type']=objects['company_type']
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return parties_data

    def prepare_keys (self, objects):

        """ This function will prepare Keys (parameters)"""
        
        func_name="prepare_keys"
        path=self.path+func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        keys=dict()
        keys['party_id']=objects["party_id"]
        keys['organization']=objects['organization']
        keys['role']=objects['role']
        keys['source_country']=objects['source_country']
        keys['sequence']=objects['sequence']
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return keys       
        
    def prepare_names_data (self, names_object, keys):
        
        """ This Function prepare names data """
        func_name, path="prepare_names_data", self.path+"prepare_names_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        index, names_data="names", dict()
        fields=self.settings_file[self.settings_file['index']==config.NAMES_INDEX]
        if names_object !={}:
            for index_row, row in fields.iterrows():
                if row['field'] in names_object.keys():
                    try:
                        names_data[row['field']]=names_object[row['field']].strip()
                    except:
                        names_data[row['field']]=""
            names_data.update(keys)
            output={"status":True,"data":names_data,"status_code":200 }
        else:
            output={"status":False,"detail":f"{index} object is empty","status_code":400 }
            self.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
            
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output
        
    def prepare_nationality_data (self, nationalities_object, keys):
        
        """ This Function Prepare Nationality Data """
        func_name, path="prepare_nationality_data", self.path+"prepare_nationality_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        index, list_of_nationalities="nationalities", list()
        fields=self.settings_file[self.settings_file['index']==config.NATIONALITIES_INDEX]
        if nationalities_object not in [{}, [], None, "" ] and type (nationalities_object)==list:
            
            for obj in nationalities_object:
                nationalities_data=dict()
                for index_row, row in fields.iterrows():
                    if row['field'] in obj.keys():
                        try:
                            nationalities_data[row['field']]=obj[row['field']].strip()
                        except:
                             nationalities_data[row['field']]=""
                nationalities_data.update(keys)        
                list_of_nationalities.append(nationalities_data)
            output={"status":True,"data":list_of_nationalities,"status_code":200 }
        else:
            output={"status":False,"detail":f"{index} object is empty","status_code":400 }
            self.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output 

    def prepare_parties_country_data (self, parties_country_object, keys):
    
        """ This Function Prepare parties_country Data """
        
        func_name, path="prepare_parties_country_data", self.path+"prepare_parties_country_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        

        index, parties_country_data="parties_country", dict()
        fields=self.settings_file[self.settings_file['index']==config.PARTIES_COUNTRY_INDEX]
        if parties_country_object not in [ {},"", None, [] ] :
            
            for index_row, row in fields.iterrows():

                if row['field'] in parties_country_object.keys():
                    try:
                        parties_country_data[row['field']]=parties_country_object[row['field']].strip()
                    except:
                        parties_country_data[row['field']]=""
            parties_country_data.update(keys)
            output={"status":True,"data":parties_country_data,"status_code":200 }
        else:
            output={"status":False,"detail":f"{index} object is empty","status_code":400 }
            self.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
            
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output 
    
    def prepare_objects_data (self, objects:dict):

        """ Prepare Object Data parties, names, nationalities, and parties country."""
        func_name, path, data="prepare_objects_data", self.path+"prepare_objects_data", dict()
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Prepare Parties 
        data["parties"]=self.prepare_parties_data(objects, party_type=self.service_type)
        # Prepare Keys
        keys=self.prepare_keys(objects=objects)
        if CrudBase.check_keys_is_found(es=self.es, index=config.NAMES_INDEX, keys=keys):

            if self.endpoint =="update":
                self.add_type="update"
            else:            
                content={"detail":"The parties keys already exist"}
                self.logger.warning(content["detail"], extra={"path":path, "endpoint":self.endpoint})
                raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=content["detail"])
                
        # Prepare Names 
        output=self.prepare_names_data(names_object=objects["names"], keys=keys)
        if output["status"]:
            data["names"]=output["data"]
        else:
            content={"detail":"Names object is empty"}
            self.logger.warning(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])

        # Prepare Nationalities
        output=self.prepare_nationality_data(nationalities_object=objects["nationalities"], keys=keys)
        if output["status"]:
            data["nationalities"]=output["data"]
        else:
            content={"detail":"Nationalities object is empty"}
            self.logger.warning(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
        
        # Prepare Parties Country
        output=self.prepare_parties_country_data(parties_country_object=objects["parties_country"], keys=keys)
        if output["status"]:
            data["parties_country"]=output["data"]
        else:
            content={"detail":"Parties Country object is empty"}
            self.logger.warning(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=content["detail"])
        
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        output={"status":True, "data":data}
        return output
            
    def add_objects_to_database(self,data):
        
        """ Add objects to database"""
        func_name, path="add_objects_to_database", self.path+"add_objects_to_database"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        primary_id=str(uuid.uuid4())
        # Add Data to DataBase
        self.logger.info(data["parties"], extra={"path":self.path, "endpoint":self.endpoint})
        for index in data.keys():
            if index =="nationalities":
                for obj_nationalities in data[index]:
                    obj_nationalities["primary_id"] = primary_id
                    CrudBase.add_row(es=self.es, index=config.NATIONALITIES_INDEX,_object=obj_nationalities)
            elif index =="names":
                data[index]["primary_id"] = primary_id
                CrudBase.add_row(es=self.es, index=config.NAMES_INDEX, _object=data[index])
            elif index =="parties_country":
                data[index]["primary_id"] = primary_id
                CrudBase.add_row(es=self.es, index=config.PARTIES_COUNTRY_INDEX, _object=data[index])
            elif index =="parties":
                data[index]["primary_id"] = primary_id
                CrudBase.add_row(es=self.es, index=config.PARTIES_INDEX, _object=data[index])
                
        output={"detail":"Objects added successfully"}
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output 
     
    def update_object_in_database (self,data):
        
        """ Update objects to database"""
        func_name, path="update_object_in_database", self.path+"update_object_in_database"
        keys=self.prepare_keys(data["names"])
        current_datetime = datetime.now().strftime(config.DATE_FORMAT)
        data["parties"]["updated_at"]=current_datetime
        data["names"]["updated_at"]=current_datetime
        data["parties_country"]["updated_at"]=current_datetime
        CrudBase.update_row(es=self.es, index=config.PARTIES_INDEX,_object=data["parties"], keys={"party_id":keys["party_id"]})
        CrudBase.update_row(es=self.es, index=config.NAMES_INDEX, _object=data["names"], keys=keys)
        CrudBase.update_row(es=self.es, index=config.PARTIES_COUNTRY_INDEX, _object=data["parties_country"], keys=keys)
        for  obj_nationality in data["nationalities"]:
            if self.service_type == "corporate":
                query =self.generate_query_for_corporate_search(index=config.NATIONALITIES_INDEX, _object=None,  parameters=keys, size=50)
            else:
                query =self.generate_query_for_search(index=config.NATIONALITIES_INDEX, _object=None,  parameters=keys, size=50)
            result_index =self.es.search(index=config.NATIONALITIES_INDEX, body=query)
            
            if len (result_index["hits"]["hits"])> 0:
                for obj_result in result_index["hits"]["hits"]:
                    CrudBase.delete_row(es=self.es, index=config.NATIONALITIES_INDEX, Id=obj_result['_id'])
            obj_nationality["updated_at"]=current_datetime
            obj_nationality.update(keys)
            CrudBase.add_row(es=self.es, index=config.NATIONALITIES_INDEX,_object=obj_nationality, created_at=None)
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        output={"detail":"Objects Updated successfully."}
        return output
    
    ################################################################################################################
    ################################################ Search Functions ##############################################
    ################################################################################################################    

    def get_primary_keys(self, data):
    
        """ This function for select the primary keys and return them. """
        
        primary_keys_list=["party_id","role","sequence","source_country","organization"]
        primary_keys=dict()
        for key, value in data.items():
            
            if key in primary_keys_list:
                primary_keys[key]=value 
        return primary_keys
    
    def Select_Keys_name_data_for_result_object(self, obj_data):

        """
        Select Keys and object data for result object of name index
        this function will return two dictionaries:keys and object data 
        """
        index, obj_keys="names", dict()
        settings=self.settings_file[ (self.settings_file['index'] ==config.NAMES_INDEX)& ( self.settings_file['keys']==True)] 
        obj_data={index:obj_data}
        for ind, row in settings.iterrows():
            if row['field'] in obj_data[index].keys():
                obj_keys[row['field']]=obj_data[index][row['field']]
                del obj_data[index][row['field']]
            else:
                continue 
        return obj_keys, obj_data

    def select_keys_and_source_for_index_settings(self, index, obj_keys):
        """
        this function will return _source and keys for index 
        """
        settings=self.settings_file[self.settings_file['index']==config.INDEX_MAP[index] ]
        keys, _source=dict(), list()
        for ind, row  in settings.iterrows():
            if  row['keys'] ==True:
                if row['field'] in obj_keys.keys():
                        keys[row['field']]=obj_keys[row['field']]
                else:_source.append(row['field'])
            else:_source.append(row['field'])
        return keys, _source

    def Check_attribute_permission_return(self,obj_data):
          
        """ Check attributes have permission to return in results or not. """
        
        for index in ["names","parties_country","nationalities"]:
            if index !="nationalities":
                for ind ,  row in self.settings_file.loc[self.settings_file["index"]==config.INDEX_MAP[index] ].iterrows():
                    if row["field"] in obj_data[index]:
                        if row["return_with_result"] ==True:continue
                        else:del obj_data[index][row["field"]]
            else:
                for i in range(len(obj_data[index])):
                    for ind ,  row in self.settings_file.loc[self.settings_file["index"]==config.INDEX_MAP[index] ].iterrows():
                        if row["field"] in obj_data[index][i]:
                            if row["return_with_result"] ==True:continue
                            else:del obj_data[index][i][row["field"]]
        return obj_data    
          
    def prepare_results(self,data,source_obj):
        data_after_prepare=list()
        # step 6:Check Similarity between two Objects
        for ind, obj_data in enumerate(data):

            # 6.1  Prepare Objects results  structure
            over_all_ratio=obj_data["data_with_weights"]['over_all_ratio']
            auto_marge=obj_data["data_with_weights"]['auto_marge']
            del obj_data["data_with_weights"]['over_all_ratio']
            del obj_data["data_with_weights"]['auto_marge']
            del obj_data["data_with_weights"]['keys']

            if  obj_data["data_with_weights"]['nationalities'] in [dict(),list(), None ]:
                obj_data["data_with_weights"]['nationalities']=list()
                for obj in obj_data["object"]['nationalities']:
                    obj_nat=dict()
                    for key, value in obj.items():
                        obj_nat[key]={"ratio":0, "value":value }
                    obj_nat['section_match_ratio']=0 
                    obj_data["data_with_weights"]['nationalities'].append(obj_nat)
            
            # 6.2  Check attributes have permission to return
            #obj_data["data_with_weights"]=self.Check_attribute_permission_return(obj_data["data_with_weights"])
            obj_data={"keys":obj_data["keys"],"object":obj_data["data_with_weights"], "over_all_ratio":over_all_ratio,'auto_marge':auto_marge}
            data_after_prepare.append(obj_data)

        # 6.3 Sort Results Based on Over All Ratio
        data_after_prepare.sort(key=operator.itemgetter("over_all_ratio"), reverse=True)
        data_after_prepare={"source":source_obj, "result_search":data_after_prepare}
        return data_after_prepare
    