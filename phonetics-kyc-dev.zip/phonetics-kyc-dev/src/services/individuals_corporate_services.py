from fastapi import status
from src.services.base_services import BaseService
from src.utils import model_to_dict
from src.database import close_connection
from src.config import config
import time
import hashlib
import json

######################################################################################################################
######################################################################################################################
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                        <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> individuals corporate Operations <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                        <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
######################################################################################################################
######################################################################################################################

class individuals_corporate_Operations (BaseService):
    
    def __init__(self, endpoint, public_id=""):
        self.system_type='individuals'
        self.endpoint=endpoint  
        self.public_id=public_id
        self.path=f"p.c.iv.io.{self.endpoint[0]}.IO."
        super().__init__(system_type=self.system_type, endpoint=self.endpoint, path=self.path)

        
    #######################################################################################################################
    ##############################################   procedures   #########################################################
    #######################################################################################################################

    def checksum_procedure(self, headers, data):
        
        """ This Function will apply procedure for checksum and Return Results """
        start_time=time.perf_counter()
        func_name, path="checksum_procedure", self.path +"checksum_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            data=model_to_dict(data)
            # Compare Between Two Objects
            output, status_code=self.checksum(primary_keys=data),  status.HTTP_200_OK
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            process_time=time.perf_counter() - start_time
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=process_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # End procedure and close Connection
            close_connection(self.es)
            return output, status_code
        except:
            content={ "detail":f"error in {self.endpoint} endpoint."}
            self.logger.error(content["detail"],extra={"path":path,"endpoint":content})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT
          
    def delete_procedure(self, headers, party_id):
        
        """ This Function will apply procedure for delete and Return Results """
        start_time=time.perf_counter()
        func_name, path="delete_procedure", self.path +"delete_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            output, status_code=self.Flag_Delete(party_id=party_id)
            process_time=time.perf_counter() - start_time
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=process_time,
                public_id=self.public_id, 
                inputs=party_id, 
                output=output
            )
            # Return Results
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
        except:
            content={ "detail":f"error in {self.endpoint} endpoint."}
            self.logger.error(content["detail"],extra={"path":path,"endpoint":content})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT
    
    def physical_flag_deleted_procedure(self, headers, party_id):
        
        """ This Function will apply procedure for delete and Return Results """
        start_time=time.perf_counter()
        func_name, path="physical_flag_deleted_procedure", self.path+"physical_flag_deleted_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            output, status_code=self.Physical_Flag_Deleted(party_id=party_id)
            # Return Results
            process_time=time.perf_counter() - start_time
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type,
                process_time=process_time,
                public_id=self.public_id, 
                inputs=party_id, 
                output=output
            )
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
        except:
            content={ "detail":f"error in {self.endpoint} endpoint."}
            self.logger.error(content["detail"],extra={"path":path,"endpoint":content})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT
        
    def physical_delete_by_keys_procedure(self, headers, data):
        
        """ This Function will apply procedure for delete and Return Results """
        start_time=time.perf_counter()
        func_name, path="physical_delete_procedure", self.path+"physical_delete_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            data=model_to_dict(data)  
            output, status_code=self.Physical_Delete_based_keys(keys=data)
            process_time=time.perf_counter() - start_time
            self.add_to_log (
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint+"/"+self.system_type, 
                process_time=process_time,
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            # Return Results
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
        except:
            content={ "detail":f"error in {self.endpoint} endpoint."}
            self.logger.error(content["detail"],extra={"path":path,"endpoint":content})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT
    
    ################################################################################################################
    ############################################## Checksum Functions  #############################################
    ################################################################################################################
    

    def md5_hash (self, obj):
        """
        Hash function for return object with hash code in Checksum endpoint
        """
        func_name="md5_hash"
        path=self.path+func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        word='''{}'''.format(obj)
        word=word.strip()
        word=word.replace(', ',',')
        word=word.replace(',',',')
        word=word.replace(':',':')
        word=word.replace(':',':')
        checksum=hashlib.md5(word.encode()).hexdigest()
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return checksum
    
    def parties_collect_data(self,primary_keys):

        """ This function is a part of the Checksum function to collect Parties object-related keys."""
        func_name, path="parties_collect_data", self.path+"parties_collect_data"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Get Parties data
        output=self.get_parties_data(primary_keys["party_id"], self.system_type)
        if  not output["status"]:
            detail="The Customer with party id:{}, role:{}, sequence:{}, source_country:{}, and organization:{} is not found, deleted or unsearchable.".format(primary_keys["party_id"],
            primary_keys["role"],primary_keys["sequence"],primary_keys["source_country"],primary_keys["organization"])
            output={"status":False, "detail":detail}
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output
        
    def nationalities_collect_data(self,primary_keys):

        """ This function is a part of the Checksum function to collect nationalities object-related keys."""
        func_name="nationalities_collect_data"
        path=self.path+func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Get Data from Nationalities Tables 
        index, checksums="nationalities",""
        query=self.generate_query_based_keys(index=config.NATIONALITIES_INDEX,fields=primary_keys)
        nationalities_info=self.es.search(index=config.NATIONALITIES_INDEX, body=query)["hits"]["hits"]
        if  nationalities_info ==[]:
            output=dict(),False
            detail="Nationalities object is empty."
            self.logger.warning(detail,extra={"path":path,"endpoint":self.endpoint})
        else:
            nationalities_list=list()
            for obj in nationalities_info:
                obj["_source"]={key:obj["_source"][key] for key in obj["_source"] if key not in primary_keys}
                nationalities_list.append({"object":obj["_source"], "checksum":self.md5_hash(obj["_source"])})
                checksums=checksums + self.md5_hash(obj["_source"])
            data={"objects":nationalities_list, "checksum":self.md5_hash(checksums)}
            output=data, True
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output

    def names_collect_data(self,primary_keys):

        """ This function is a part of the Checksum function to collect names object-related keys."""
        func_name="names_collect_data"
        path=self.path+func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        index, checksums="names", ""
        query=self.generate_query_based_keys (index=config.NAMES_INDEX,fields=primary_keys)
        party_id_info=self.es.search(index=config.NAMES_INDEX, body=query)
        party_id_info=party_id_info["hits"]["hits"]
        if  party_id_info==[]:
            data={}
            detail=f"object collected by keys:{str(primary_keys)} is not found in the names index."
            self.logger.warning(detail,extra={"path":self.path+"names_collect_data","endpoint":self.endpoint})
            return data, False 
        else:
            names_list=list()
            for obj in party_id_info:
                obj["_source"]={key:obj["_source"][key] for key in obj["_source"] if key not in primary_keys}
                obj_names=json.dumps(obj["_source"]).encode("utf-8")
                obj_checksum=hashlib.md5(obj_names).hexdigest()
                checksums=checksums + obj_checksum
                names_list.append ({"object":obj["_source"], "checksum":obj_checksum  })

            over_all_checksum=self.md5_hash(checksums) 
            data={"objects":names_list, "checksum":over_all_checksum }
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return data, True 
    
    def parties_country_collect_data(self,primary_keys):

        """ This function is a part of the Checksum function to collect parties country object-related keys. """
        
        func_name="parties_country_collect_data"
        path=self.path+func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        index="parties_country"
        query=self.generate_query_based_keys (index=config.PARTIES_COUNTRY_INDEX,fields=primary_keys)
        party_id_info=self.es.search(index=config.PARTIES_COUNTRY_INDEX, body=query)
        party_id_info=party_id_info["hits"]["hits"]
        if  party_id_info ==[]:
            data={}
            detail=f"object collected by keys:{str(primary_keys)} is not found in the parties country index."
            self.logger.warning(detail,extra={"path":self.path+"parties_country_collect_data","endpoint":self.endpoint})
            return data,False
        else:
            parties_country_list =list()
            checksums =""
            for obj in party_id_info:
                obj["_source"]={key:obj["_source"][key] for key in obj["_source"] if key not in primary_keys}
                obj_checksum=self.md5_hash(obj["_source"])
                checksums=checksums + obj_checksum
                parties_country_list.append ({"object":obj["_source"], "checksum":obj_checksum  })

            over_all_checksum=self.md5_hash(checksums)
            data={"objects":parties_country_list, "checksum":over_all_checksum }
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return data,True

    def checksum(self, primary_keys:dict)-> dict:

        """ This function will get data related to primary keys (party_id, role, sequence, source_country, organization)
            from all indexes (names, parties, parties country, and nationalities)and calculate checksum by MD5 hash"""
        func_name, path, data="checksum", self.path+"checksum", dict()
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Collect Parties Data and Calculate Checksum 
        output=self.parties_collect_data(primary_keys)
        if not output["status"]:
            return output
        data=output["data"]
        obj_checksums=self.md5_hash(data)
        # Collect Nationalities Data and Calculate Checksum 
        data["nationalities"], status=self.nationalities_collect_data(primary_keys)
        # Collect Names Data and Calculate Checksum 
        data["names"], status=self.names_collect_data(primary_keys)
        # Collect Parties Country Data and Calculate Checksum 
        data["parties_country"], status=self.parties_country_collect_data(primary_keys)
        # global checksum for all data 
        data['global_checksum']=self.md5_hash(data)
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return data


    ################################################################################################################
    ################################################ Delete Functions ##############################################
    ################################################################################################################

    def check_party_id_is_found(self, party_id, index, query=False):

        """
        This Function will Check If the Party ID is exists or not
        """
        
        func_name="check_party_id_is_found"
        path=self.path+func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            
        query, query['query']=dict(), dict()
        query['query']['match']={ "party_id":{ "query":party_id, "operator":"and" } } 
        if query ==True:
            return query, status.HTTP_200_OK
        result_search =self.es.search( index=index, body=query)['hits']['hits']
        if result_search ==[]:
            detail="party id is not found."
            self.logger.warning(detail,extra={"path":self.path+"check_party_id_is_found","endpoint":self.endpoint})
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return False
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return result_search, status.HTTP_200_OK 

    def Physical_Delete_based_keys(self, keys):

        """This Function Make physical Delete for all objects (rows)related Keys in 
        four indexes (names, parties, parties country, and nationalities)."""
        func_name, path="Physical_Delete_based_keys", self.path+"Physical_Delete_based_keys"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Check party id found in table parties 
        result_search=self.check_keys_is_found (index=config.NAMES_INDEX, keys=keys)
        if result_search ==False:
            detail=f"Keys:{str(keys)} are not found."
            self.logger.warning(detail,extra={"path":path,"endpoint":self.endpoint})
            output, status_code ={'detail':detail}, status.HTTP_404_NOT_FOUND
        else:
            for index in ["parties","names","nationalities","parties_country"]:
                if index=="parties":
                    fields={"party_id":keys["party_id"]}
                else:
                    fields=keys.copy()
                query=self.generate_query_based_keys (fields=fields, index=config.INDEX_MAP[index])
                result_search =self.es.search(index=config.INDEX_MAP[index], body=query)["hits"]["hits"][0]
                _=self.delete_row(index=index, Id=result_search["_id"])
            output, status_code={'detail':'object is physical deleted.'}, status.HTTP_200_OK
        self.logger.debug(f"/{func_name} function", extra={"path":path, "endpoint":self.endpoint})
        return output, status_code

    def Flag_Delete(self, party_id):

        """
        This Function Make Flag Delete based on party id in parties index and 
        physical delete in three indexes (names, parties country, and nationalities)
        """
        func_name, path="Flag_Delete", self.path+"Flag_Delete"
        self.logger.debug(f"{func_name} function", extra={"path":path, "endpoint":self.endpoint})
        # Check party id found in table parties 
        result_search=self.check_party_id_is_found (party_id=party_id, index=config.PARTIES_INDEX, query=False)
        if result_search ==False:
            detail=f"Party id:{party_id} is not found."
            self.logger.warning(detail,extra={"path":path,"endpoint":self.endpoint})
            output, status_code={'detail':'Party id is not found.'}, status.HTTP_404_NOT_FOUND
        else:
            # get elastic id from object 
            elastic_id=result_search[0][0]['_id']
            # Update parties table 
            self.es.update( index=config.PARTIES_INDEX, id=elastic_id, body={ "doc":{"is_deleted":True} })
            # physical delete for tables (names, nationalities, parties_country)
            for index in ["names","nationalities","parties_country"]:
                # Check party id found
                result_search=self.check_party_id_is_found (party_id=party_id, index=config.INDEX_MAP[index], query=False)
                if result_search !=False:
                    for obj in result_search[0]:
                        # Get elastic id  
                        elastic_id =obj['_id']
                        # Delete row 
                        self.delete_row(config.INDEX_MAP[index], elastic_id)
            # Return result 
            output, status_code={'detail':'object is flag deleted.'}, status.HTTP_200_OK
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output, status_code

    def Physical_Flag_Deleted(self, party_id):

        """ This Function Makes physical delete for party id is deleted as a flag delete. """
        func_name, path="Physical_Flag_Deleted", self.path+"Physical_Flag_Deleted"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Check party id found in table parties 
        result_search=self.check_party_id_is_found (party_id=party_id, index=config.PARTIES_INDEX, query=False)
        if result_search ==False:
            detail=f"Party id:{party_id} is not found."
            self.logger.warning(detail,extra={"path":path,"endpoint":self.endpoint})
            output, status_code ={'detail':'Party id is not found.'}, status.HTTP_404_NOT_FOUND
        elif result_search[0][0]["_source"]["is_deleted"]==True:
          # Get elastic id  
            elastic_id =result_search[0][0]['_id']
            # Delete row 
            self.delete_row(config.PARTIES_INDEX, elastic_id)
            output, status_code={'detail':'The object is physically deleted.'}, status.HTTP_202_ACCEPTED
        else:
           output, status_code={'detail':'Party id is not flagged delete.'}, status.HTTP_404_NOT_FOUND
           
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output, status_code

