######################################################################################################################
######################################################################################################################
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                           <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Authentication Operations <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                           <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
######################################################################################################################
######################################################################################################################

from fastapi import status, HTTPException
from elasticsearch import Elasticsearch
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime, timedelta, timezone
import uuid 
import jwt
import time

from src.database import close_connection
from src.crud import CrudLogs, CrudUser
from src.services import BaseService
from src.config import config


class Auth_Services (BaseService):

    def __init__(self, endpoint:str, es:Elasticsearch):

        self.service_type='auth'
        self.endpoint=endpoint
        self.es=es
        super().__init__(
            es=self.es,
            service_type=self.service_type, 
            endpoint=self.endpoint,
            path=f"p.c.av.ao.{self.endpoint[0]}.AO."
        )
        self.path=f"service.auth"
        self.public_id=""
        

    #######################################################################################################################
    ##############################################   procedures   #########################################################
    #######################################################################################################################

    def login_procedure(self,data,headers):
        """ """
        start_time= time.perf_counter()
        func_name, path="login_procedure", self.path+"login_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        self.logger.info(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Check User Credential
            output=self.check_user_Credential(email=data["email"], password=data["password"])
            if output["status"]:
                #create token 
                output, status_code=self.create_token(), status.HTTP_201_CREATED
            else:
                output, status_code={"detail":"The user is not exists."}, status.HTTP_404_NOT_FOUND
            # Add to Log
            data['password']='*'*8
            process_time= time.perf_counter() - start_time 
            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint, 
                process_time=process_time, 
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )
            close_connection(self.es)
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            return output, status_code
        except HTTPException as http_exc:
            close_connection(self.es)
            self.logger.error(http_exc.detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=http_exc.status_code, detail=http_exc.detail)
            
    def signup_procedure (self, data:dict, headers:dict)-> dict:
        
        """ This Function will apply procedure for Sign UP and Return Results """
        start_time= time.perf_counter()
        func_name, path="signup_procedure", self.path+"signup_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Check User Exists

            user_exists = CrudUser.check_user_exists_by_email(es=self.es, email=data["email"])
            if user_exists:
                output, status_code={"detail":"User already exists."}, status.HTTP_409_CONFLICT
                self.logger.warning("Validation Error",extra={"path":path,"endpoint":self.endpoint})
            else:

                data['is_admin']=False
                data['email']=data['email'].strip().lower()
                data['name']=data['name'].strip()
                data["password"]=generate_password_hash(str(data["password"]))
                data["public_id"]=str(uuid.uuid4())
                CrudUser.create_user(es=self.es, user_id=data["public_id"], user_data=data)
                output, status_code={'detail':'Successfully registered.'}, status.HTTP_201_CREATED
            # Add to Log   
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            process_time= time.perf_counter() - start_time 
            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status_code, 
                endpoint=self.endpoint, 
                process_time=process_time, 
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )

            close_connection(self.es)
            return output, status_code
        except Exception as e:
            content={"detail":f"Error creating user: {e}."}
            self.logger.error(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            raise HTTPException(detail="Internal server error", status_code=status.HTTP_409_CONFLICT)
        
    def get_all_users_procedure(self,headers:dict, public_id:str)-> dict:
        
        """ This Function will apply procedure for Get All User and Return Results """
        start_time= time.perf_counter()
        self.public_id, func_name, path=public_id, ".get_all_users_procedure",self.path+"get_all_users_procedure" 
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            # Get Data
            users=CrudUser.get_users(es=self.es)
            print(users)
            print("==="*20)
            # Add log
            process_time= time.perf_counter() - start_time 
            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status.HTTP_202_ACCEPTED,
                endpoint=self.endpoint, 
                process_time=process_time, 
                public_id=self.public_id, 
                inputs=None, 
                output=None
            )
            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return users, status.HTTP_202_ACCEPTED
        except:
            content={"detail":"Internal server error occurred in the {} endpoint.".format(self.endpoint)}
            self.logger.error(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT
    
    def change_password_procedure (self,data:dict, headers:dict, current_user:str)-> dict:
        
        """ This Function will apply procedure for Change Password and Return Results """
        start_time= time.perf_counter()
        func_name, path="change_password_procedure", self.path+"change_password_procedure"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        
        try:
            if not self.check_is_admin(public_id=current_user):
                output, status_code={'detail':'Only the administrator has the permission to Update.'}, status.HTTP_403_FORBIDDEN
                self.logger.critical(output["detail"],extra={"path":path,"endpoint":self.endpoint})
                
            elif self.check_user_exists(public_id=current_user):
                result=self.update_password(data['public_id'].strip(), data["password"].strip())
                if result['status']:
                    self.logger.warning(f"Password for {current_user} is updated",extra={"path":path,"endpoint":self.endpoint})
                    output, status_code ={'detail':'Password Updated Successfully.'}, status.HTTP_201_CREATED
                else:
                    output, status_code={'detail':'Error when update the new password'}, status.HTTP_400_BAD_REQUEST
            else:
                output, status_code={"detail":"The user is not exists."}, status.HTTP_404_NOT_FOUND
                self.logger.warning(output["detail"],extra={"path":path,"endpoint":self.endpoint})
            
            process_time= time.perf_counter() - start_time 
            CrudLogs.add_to_log (
                es=self.es,
                service_type=self.service_type,
                headers=headers, 
                status_code=status.HTTP_202_ACCEPTED,
                endpoint=self.endpoint, 
                process_time=process_time, 
                public_id=self.public_id, 
                inputs=data, 
                output=output
            )

            self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return output, status_code
        except:
            content={"detail":"Internal server error occurred in the {} endpoint.".format(self.endpoint)}
            self.logger.error(content["detail"],extra={"path":path,"endpoint":self.endpoint})
            close_connection(self.es)
            return content, status.HTTP_409_CONFLICT

    #######################################################################################################################
    #######################################################################################################################
    #######################################################################################################################
    
    def create_token(self):
        """Create Login Token."""
        func_name="create_token"
        path=self.path +func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # generates the JWT Token 
        exp = datetime.now(timezone.utc)+timedelta(
                                            hours=config.ACCESS_TOKEN_EXPIRE_HOURS,
                                            minutes=config.ACCESS_TOKEN_EXPIRE_MINUTES)
        token=jwt.encode({
                        'public_id':self.public_id, 
                        'exp':exp}, 
                        config.ACCESS_SECRET_KEY,
                        algorithm=config.ALGORITHM
                       )
        #.decode("utf-8")
        output={'token':token,}
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output

    def check_user_Credential(self,email:str, password:str)-> dict:
        
        """ This Function will check in the database if the user credential is correct or not """
        func_name, path="check_user_Credential", self.path+"check_user_Credential"
        path=self.path +func_name
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Check user 
        user=CrudUser.get_by_email(es=self.es, email=email)
        print(user)
        if user == list():
            self.logger.debug("the credential could not verify",extra={"path":path,"endpoint":self.endpoint})           
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Could not verify')
             
        elif check_password_hash(user[0]["_source"]['password'], password):
            # generates the JWT Token 
            user = user[0]["_source"]
            self.public_id=user['public_id']
            output={'status':True, 'detail':"User credential is correct." }
        else:
            detail='Email or password is incorrect.'
            self.logger.warning(detail,extra={"path":path,"endpoint":self.endpoint})
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail)
        
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output    
     
    def check_is_admin(self, public_id:str)-> bool:
        # Check user 
        users=self.users.loc[(self.users['public_id']==public_id)& (self.users['is_admin']==True),:]
        if users.empty:
           output=False
        else:
            output=True
        return output
    
    def check_user_exists (self,email:str=None,public_id:str=None)-> bool:
        
        """ this function check if user exists by check email or public id in users index """
        
        
        func_name, path, self.public_id="check_user_exists", self.path +"check_user_exists", public_id
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        # Check user 
        users=self.users.loc[(self.users['email'] ==email)| (self.users['public_id']==public_id),:]
        if users.empty:
           output=False
        else:
            output=True
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return output
    


    def update_password(self,public_id, new_password):
        
        func_name, path="update_password", self.path +"update_password"
        self.logger.debug(f"{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        user=self.users.loc[self.users['public_id']==public_id,:]
        new_object=dict()
        new_object['password']=generate_password_hash(str(new_password))
        new_object['email']=user.loc[:,'email'].values[0]
        new_object['name']=user.loc[:,'name'].values[0]
        new_object['public_id']=user.loc[:,'public_id'].values[0]
        new_object['is_admin']=user.loc[:,'is_admin'].values[0]
        result=self.update_row_using_elastic_id(index=config.USERS_INDEX,Id=user.loc[:,'Id'].values[0], _object=new_object)
        self.logger.debug(f"/{func_name} function",extra={"path":path,"endpoint":self.endpoint})
        return result
        
