import re
import uuid
from datetime import datetime
from werkzeug.security import generate_password_hash
from termcolor import colored
from src.services import LogsService
from src.database import create_connection, close_connection
from src.crud import CrudUser
from src.config import config

# Initialize logger
logger = LogsService.get_logger()

# Get current timestamp
current_datetime = datetime.now().strftime(config.DATE_FORMAT)

def is_valid_password(password: str) -> bool:
   """Validate if the password meets the minimum length requirement."""
   return len(password) >= 8

def is_valid_email(email: str) -> bool:
   """Validate email format using a regex pattern."""
   regex = re.compile(r'([A-Za-z0-9]+[._-])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
   return bool(re.fullmatch(regex, email))

def is_valid_name(name: str) -> bool:
   """Validate if the name meets the minimum length requirement."""
   return len(name) >= 2

def get_user_input(prompt: str, validation_fn, error_message: str) -> str:
   """
   Repeatedly prompt the user for input until valid input is provided.
   Args:
       prompt (str): The input prompt for the user.
       validation_fn (callable): A function to validate the input.
       error_message (str): Error message displayed for invalid input.
   Returns:
       str: Validated user input.
   """
   while True:
       user_input = input(prompt).strip()
       if validation_fn(user_input):
           return user_input
       logger.error(error_message)
       print(error_message)

def get_admin_information() -> dict:
   """
   Collect and validate admin user information from the console.
   Returns:
       dict: Admin user information.
   """
   logger.info("Starting to collect admin information.")
   name = get_user_input("Enter your Name: ", is_valid_name, "Name must be at least 2 characters long.")
   email = get_user_input("Enter your Email: ", is_valid_email, "Invalid email format.")
   password = get_user_input("Enter your Password: ", is_valid_password, "Password must be at least 8 characters long.")
   user_obj = {
       'name': name,
       'email': email,
       'password': generate_password_hash(password),
       'public_id': str(uuid.uuid4()),
       'is_admin': True,
       'created_at': current_datetime,
   }
   logger.info(f"Admin information collected successfully for: {email}")
   return user_obj

def create_admin():
   """
   Create a new admin user after collecting valid information and confirming the action.
   """
   logger.info("Starting admin creation process.")
   try:
       user_data = get_admin_information()
       # Confirm admin creation
       status = input("Are you sure you want to create a new Admin? (y/n): ").strip().lower()
       if status not in ["y", "yes", "1"]:
           logger.warning("Admin creation cancelled by user.")
           print(colored("Admin creation cancelled. Try again if needed.", 'red'))
           return
       # Check if the admin already exists
       es = create_connection()
       user_exists = CrudUser.check_user_exists_by_email(es=es, email=user_data['email'] )
       if not user_exists:
            logger.warning(f"User with email {user_data['email']} already exists.")
            print(colored("User already exists.", 'red'))
       else:
           CrudUser.create_user(es=es, user_id=user_data["public_id"] , user_data=user_data)
           logger.info(f"Admin created successfully: {user_data['email']}")
           print(colored("Admin created successfully.", 'green'))
   except Exception as e:
       logger.error(f"Error occurred during admin creation: {e}")
       print(colored("An error occurred. Please try again later.", 'red'))
   finally:
        close_connection(es=es)
        logger.info("Database connection closed.")