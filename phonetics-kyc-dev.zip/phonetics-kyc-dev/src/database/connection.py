from elasticsearch import Elasticsearch
from src.config import config
#from src.services import LogsService

#logger = LogsService.get_logger()
endpoint =""

def create_connection():
    """ Create a connection with Elasticsearch based on the environment and credentials. """
    func_name = "create_connection"
    path = f".{func_name}"

    #logger.debug(f"{func_name} function", extra={"path": path,"endpoint":endpoint})

    try:

        elastic_url = f"{config.SCHEME}://{config.ELASTICSEARCH_HOST}:{config.ELASTICSEARCH_PORT}"
        es = Elasticsearch(
            [elastic_url],
            http_auth=(config.ELASTICSEARCH_USERNAME, config.ELASTICSEARCH_PASSWORD)
        )
        if es.ping():
            #logger.debug(f"Connection established in {func_name}", extra={"path": path,"endpoint":endpoint})
            #logger.debug(f"/{func_name} function", extra={"path": path,"endpoint":endpoint})
            return es
        else:
            #logger.critical("Elasticsearch connection failed", extra={"path": path,"endpoint":endpoint})
            raise Exception("ElasticSearch connection failed")
    except Exception as e:
        #logger.critical("Failed to create Elasticsearch connection", extra={"path": path,"endpoint":endpoint})
        raise Exception(f"ElasticSearch connection failed: {e}")

def close_connection(es):
    """ Close the Elasticsearch connection. """
    func_name = "close_connection"
    path = f"Path_to_{func_name}"

    #logger.debug(f"Calling {func_name} function", extra={"path": path,"endpoint":endpoint})

    try:
        es.close()
        #logger.debug(f"Connection closed in {func_name}", extra={"path": path,"endpoint":endpoint})
    except Exception as e:
        #logger.critical("Failed to close Elasticsearch connection", extra={"path": path,"endpoint":endpoint})
        raise Exception(f"Connection close failed: {e}")


def get_db():
    es = create_connection()
    return es