# Users `Index settings and mappings
users_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "public_id":{"type":"text"},
            "name":{"type":"text"},
            "email":{"type":"keyword"},
            "password":{"type":"text"},
            "is_admin":{"type":"boolean",},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
        }
    }
}

# Parties Index settings and mappings
parties_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text"},
            "party_type":{"type":"keyword"},
            "is_deleted":{"type":"boolean", },
            "is_searchable":{"type":"boolean", },
            "company_type":{"type":"text"},
            "created_at":{"type":"date", },
            "updated_at":{"type":"date"}
        }
    }
}

# Names Index settings and mappings
names_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text", },
            "party_type":{"type":"keyword", },
            "source_country":{"type":"keyword", },
            "role":{"type":"keyword", },
            "sequence":{"type":"keyword", },
            "organization":{"type":"keyword", },
            "party_type":{"type":"keyword"},
            "first_name_ar":{"type":"text"},
            "second_name_ar":{"type":"text"},
            "third_name_ar":{"type":"text"},
            "last_name_ar":{"type":"text"},
            "full_name_ar":{"type":"text"},
            "short_name_ar":{"type":"text"},
            "mother_name_ar":{"type":"text"},
            "first_name_en":{"type":"text"},
            "second_name_en":{"type":"text"},
            "third_name_en":{"type":"text"},
            "last_name_en":{"type":"text"},
            "full_name_en":{"type":"text"},
            "short_name_en":{"type":"text"},
            "mother_name_en":{"type":"text"},
            "commercial_name_ar":{"type":"text"},
            "commercial_name_en":{"type":"text"},
            "cor_full_name_en":{"type":"text"},
            "cor_full_name_ar":{"type":"text"},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"}
        }
    }
}

# Nationalities Index settings and mappings
nationalities_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text", },
            "source_country":{"type":"keyword", },
            "role":{"type":"keyword", },
            "sequence":{"type":"keyword", },
            "organization":{"type":"keyword", },
            "nationality":{"type":"keyword"},
            "national_number":{"type":"text"},
            "document_type":{"type":"text"},
            "document_number":{"type":"text"},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"}
        }
    }
}

# Nationalities Index settings and mappings
parties_country_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "primary_id":{"type":"keyword"},
            "party_id":{"type":"text", },
            "source_country":{"type":"keyword", },
            "role":{"type":"keyword", },
            "sequence":{"type":"keyword", },
            "organization":{"type":"keyword", },
            "place_of_birth":{"type":"keyword"},
            "date_of_birth":{"type":"text"},
            "country_of_origin":{"type":"text"},
            "country_of_incorporation":{"type":"text"},
            "registration_number":{"type":"text"},
            "tax_identification_number": {"type": "text"},
            "country_of_registration":{"type":"text"},
            "license_profession_number":{"type":"text"},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis" },
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"}
        }
    }
}

# FeedBack Index settings and mappings
feedback_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "word":{"type":"text"},
            "similar_status":{"type":"boolean"},
            "similar_word":{"type":"text"},
            "created_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format":"strict_date_optional_time||epoch_millis"}
        }
    }
}

# FeedBack Index settings and mappings
log_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "init_country":{"type":"keyword"},
            "channel_identifier":{"type":"keyword"},
            "unique_reference":{"type":"keyword"},
            "time_stamp":{"type":"text"},
            "system_type":{"type":"keyword"},
            "endpoint":{"type":"keyword"},
            "process_time":{"type":"float"},
            "user_id":{"type":"text"},
            "status":{"type":"integer"},
            "input":{"type":"text"},
            "output":{"type":"text"},
            "primary_id":{"type":"keyword"},
            "created_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
        }
    }
}

# Preprocessing Index settings and mappings
Preprocessing_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "language":{"type":"keyword"},
            "character":{"type":"text"},
            "replace_to":{"type":"text"},
            "created_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"}
        }
    }
}

# Index settings and mappings
settings_index_settings={
    "settings":{
        "number_of_shards":1,
        "number_of_replicas":0
    },
    "mappings":{
        "properties":{
            "field":{"type":"keyword"},
            "index":{"type":"keyword"},
            "service_type":{"type":"keyword"},
            "language":{"type":"keyword"},
            "cor_local_weight":{"type":"float"},
            "cor_global_weight":{"type":"float"},
            "local_weight":{"type":"float"},
            "global_weight":{"type":"float"},
            "search_type":{"type":"keyword"},
            "preprocessing":{"type":"boolean"},
            "keys":{"type":"boolean"},
            "weight_calculation":{"type":"boolean"},
            "return_with_result":{"type":"boolean"},
            "created_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
            "updated_at":{"type":"date","format": "strict_date_optional_time||epoch_millis"},
        }
    }
}

