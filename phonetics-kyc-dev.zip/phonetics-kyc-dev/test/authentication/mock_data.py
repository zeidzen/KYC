from src.config import config

# Mock user data
mock_user = {
   "email": config.ADMIN["email"],
   "password": config.ADMIN["password"]
}