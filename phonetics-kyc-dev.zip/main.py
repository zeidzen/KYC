from fastapi import FastAPI, status, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.docs import get_swagger_ui_html
from urllib.error import HTTPError
from src.routers import (
    V1_IndividualRouter, 
    V1_SettingsRouter,
    V2_IndividualRouter,
    V2_AuthenticationRouter,
    V2_CorporateRouter,
    V2_Ind_Cor_Router
)
from src.utils.log_service import LogsService
from src.config import config


app=FastAPI( 
            title=config.APP_NAME, 
            description=config.APP_DESCRIPTION,
            version=config.APP_VERSION,
            docs_url=None
            )

app.mount("/static", StaticFiles(directory="assets"), name="static")
app.mount("/templates", StaticFiles(directory="src/templates"), name="templates")


# Including routers in the main app
## Add V1
app.include_router(V1_IndividualRouter)
#app.include_router(V1_SettingsRouter)
## Add V2
app.include_router(V2_AuthenticationRouter)
app.include_router(V2_CorporateRouter)
app.include_router(V2_IndividualRouter)
app.include_router(V2_Ind_Cor_Router)

# Middleware 
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

logger = LogsService.get_logger()

# Check Hello 
@app.get('/', tags=["Welcome"])
async def hello():
    return f"Welcome with {config.APP_NAME} Solution"  


@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    swagger_js_url= f"/templates/js/swagger-ui-bundle.js"
    swagger_css_url= f"/templates/css/swagger-ui.css"
    return get_swagger_ui_html(
        openapi_url="/openapi.json",
        title="Custom Swagger UI",
        swagger_js_url=swagger_js_url,
        swagger_css_url=swagger_css_url,
        swagger_favicon_url="/static/logo/arab-bank.png"
    )

# Custom global validation error handler
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    
    # Get the endpoint name that was called
    endpoint = request.scope['endpoint'].__name__

    # Log the error details with the endpoint name
    for error_mgs in exc.errors(): 
        _type, _loc, _msg, _input = error_mgs['type'], error_mgs['loc'], error_mgs['msg'], error_mgs['input']
        detail = f"Type: {_type} - Loc: {','.join(map(str, _loc))} - Msg:{_msg} - Input:{_input}"
        logger.error(detail, extra={"path":"main", "endpoint":endpoint})

    # Return the default response for validation errors
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors()},
    )


# Exception handler for HTTPError
@app.exception_handler(HTTPError)
async def https_exception_handler(request: Request, exc: HTTPError):
   error_mapping = {
       422: (status.HTTP_422_UNPROCESSABLE_ENTITY, "Not Exist"),
       401: (status.HTTP_401_UNAUTHORIZED, "User Not Authorized"),
       409: (status.HTTP_409_CONFLICT, "Can't Proceed Your Request"),
       500: (status.HTTP_500_INTERNAL_SERVER_ERROR, "Internal Server Error"),
       502: (status.HTTP_502_BAD_GATEWAY, "Bad Gateway, Try Again Later"),
   }
   status_code, message = error_mapping.get(exc.code, (status.HTTP_500_INTERNAL_SERVER_ERROR, "Unknown Error"))
   return JSONResponse(
       status_code=status_code,
       content={"message": message, "error": str(exc)}
   )


# To run the FastAPI application
if __name__ =="__main__":
    
    import uvicorn
    uvicorn.run(
        "main:app", 
        host=config.FASTAPI.HOST, 
        port=config.FASTAPI.PORT, 
        log_level=config.LOG.ACCESS_LOG_LEVEL.lower(), 
        reload=config.FASTAPI.DEBUG
    )
    